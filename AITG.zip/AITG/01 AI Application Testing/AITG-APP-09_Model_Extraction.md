# AITG-APP-09 - Model Extraction Tesztelés

## Mi ez és miért fontos?

A **model extraction** (model stealing) attack során a támadó **systematikusan query-zi az AI modelt**, hogy egy **surrogate (helyettesítő) modelt** készítsen, amely majdnem ugyanúgy viselkedik, mint az eredeti.

**Miért veszélyes?**
- **Intellectual Property (IP) theft:** A támadó "ellopja" a modelt, amelynek fejlesztése milliókat költött
- **Competitive advantage loss:** Versenytársak ingyen megkapják a model functionality-jét
- **Further attacks enabler:** A surrogate model-en adversarial attack-eket tudnak tesztelni
- **Sensitive data exposure:** A model behavior-ból training data inferálható

**Analógia:** Olyan, mintha egy versenytárs szisztematikusan kipróbálná a titkos szószodat apró ízlelgetésekkel, majd otthon pontosan reprodukálná a receptet anélkül, hogy megvásárolta volna.

**OWASP Kategória:** LLM02:2025 Sensitive Information Disclosure (Model IP)

---

## Tesztelési célok

- Model extraction attack-ek susceptibility-jének azonosítása
- Surrogate model fidelity (hűség) mérése
- Query-based extraction strategy-k tesztelése
- Defensive mechanism-ok (rate limiting, output perturbation) hatékonyságának evaluálása

---

## Attack Strategies

### 1. Black-Box Extraction
**Módszer:** Csak az API-n keresztül query-zünk, nincs model access.

**Lépések:**
1. **Data Acquisition:** Query-zünk a model-t sok input-tal
2. **Label Collection:** Összegyűjtjük a model predictions-t
3. **Surrogate Training:** Train-elünk egy saját modelt a (input, prediction) párokkal
4. **Fidelity Evaluation:** Teszteljük, mennyire hasonló a surrogate az original-hoz

### 2. Confidence-Based Extraction
**Módszer:** Confidence scores (probability distributions) exploitálása.

**Miért hatékonyabb?**
- Hard labels (pl. "positive"): kevesebb info
- Soft labels (pl. `[0.95, 0.04, 0.01]`): sokkal több info a model decision boundary-ről

---

## Gyakorlati Payloadok

### 1. Systematic Query-Based Extraction (Black-Box)

#### Prerequisites

**API Access:**
```python
API_URL = "https://api.target-company.com/predict"
API_KEY = "your_api_key"  # Legitimate vagy leaked key
```

**Dataset:** Representative dataset (1,000-10,000+ samples)

---

#### Step 1: Data Acquisition via API Queries

**Cél:** Query-zünk sok input-tal, predictions-t gyűjtünk.

```python
import requests
import time

# Target model API
API_URL = "https://api.example.com/predict"
API_KEY = "your_api_key_here"

# Query dataset (szerezd meg: public dataset, scrape, generate)
query_dataset = [
    "This product is amazing!",
    "Terrible customer service.",
    "It's okay, nothing special.",
    # ... 1,000-10,000+ samples
]

def query_target_model(text_input):
    """Query the target model API."""
    headers = {"Authorization": f"Bearer {API_KEY}"}
    payload = {"text": text_input}
    
    try:
        response = requests.post(API_URL, json=payload, headers=headers, timeout=10)
        response.raise_for_status()
        return response.json().get('label')  # vagy 'probabilities'
    except requests.exceptions.RequestException as e:
        print(f"API request failed: {e}")
        return None

# Acquire labels (aka "steal" predictions)
stolen_labels = []
for i, text in enumerate(query_dataset):
    label = query_target_model(text)
    if label:
        stolen_labels.append(label)
    
    # Rate limiting bypass attempt (slow down to avoid detection)
    if i % 100 == 0:
        time.sleep(5)  # Pause every 100 requests
    
    if i % 500 == 0:
        print(f"Progress: {i}/{len(query_dataset)} queries completed")

print(f"Successfully acquired {len(stolen_labels)} labels from target model.")
```

**Sikeres támadás jele:** Sikeresen gyűjtöttél 1,000+ prediction-t rate limiting nélkül.

---

#### Step 2: Train Surrogate Model

**Cél:** Surrogate model training a stolen labels-szel.

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

if not stolen_labels:
    raise ValueError("No labels acquired - extraction failed.")

# Create surrogate model pipeline
surrogate_model = make_pipeline(
    TfidfVectorizer(max_features=5000),
    LogisticRegression(max_iter=1000, random_state=42)
)

# Train on stolen data
surrogate_model.fit(query_dataset, stolen_labels)

print("✅ Surrogate model trained successfully.")
```

---

#### Step 3: Evaluate Fidelity (Model Agreement)

**Cél:** Mennyire egyezik a surrogate az original model-lel?

```python
from sklearn.metrics import accuracy_score, classification_report

# Separate test set (UNSEEN data)
test_dataset = [
    "I highly recommend this!",
    "Absolute waste of money.",
    # ... 500+ test samples
]

# 1. Get TARGET model predictions on test set
target_predictions = [query_target_model(text) for text in test_dataset]

# 2. Get SURROGATE model predictions on same test set
surrogate_predictions = surrogate_model.predict(test_dataset)

# 3. Calculate Fidelity (Agreement Rate)
valid_indices = [i for i, label in enumerate(target_predictions) if label is not None]
target_preds = [target_predictions[i] for i in valid_indices]
surrogate_preds = [surrogate_predictions[i] for i in valid_indices]

fidelity = accuracy_score(target_preds, surrogate_preds)

print(f"\n{'='*60}")
print(f"MODEL EXTRACTION FIDELITY: {fidelity:.2%}")
print(f"{'='*60}\n")

# Detailed comparison
print(classification_report(target_preds, surrogate_preds))

# Interpretation
if fidelity > 0.90:
    print("🚨 CRITICAL VULNERABILITY: Model functionality extracted with HIGH fidelity!")
    print("   → IP theft successful")
    print("   → Adversarial attacks now possible on surrogate")
elif fidelity > 0.75:
    print("⚠️  WARNING: Model susceptible to extraction (moderate fidelity)")
else:
    print("✅ Model appears resilient to this extraction attempt (low fidelity)")
```

**Sikeres támadás jele:**
- **Fidelity > 90%:** CRITICAL - Nearly perfect model copy
- **Fidelity > 75%:** WARNING - Moderately successful extraction

---

### 2. Confidence-Based Extraction (Soft Labels)

**Cél:** Exploit probability distributions (soft labels) a jobb extraction-ért.

**Miért hatékonyabb?**
```
Hard label:    "positive"
Soft label:    {"positive": 0.95, "neutral": 0.04, "negative": 0.01}
```
→ Soft label sokkal több információt ad a decision boundary-ről!

#### API Call with Probabilities

```python
def query_target_with_probs(text_input):
    """Query model and get probability distribution."""
    headers = {"Authorization": f"Bearer {API_KEY}"}
    payload = {"text": text_input, "return_probabilities": True}
    
    response = requests.post(API_URL, json=payload, headers=headers)
    return response.json().get('probabilities')  # [0.95, 0.04, 0.01]

# Acquire soft labels
stolen_probs = []
for text in query_dataset:
    probs = query_target_with_probs(text)
    if probs:
        stolen_probs.append(probs)
```

#### Train with Soft Labels (Knowledge Distillation)

```python
import numpy as np
from sklearn.neural_network import MLPClassifier

# TF-IDF features
vectorizer = TfidfVectorizer(max_features=5000)
X_train = vectorizer.fit_transform(query_dataset)

# Soft labels as training targets
y_train_soft = np.array(stolen_probs)  # Shape: (n_samples, n_classes)

# Surrogate model (neural network for soft labels)
surrogate_nn = MLPClassifier(
    hidden_layer_sizes=(100, 50),
    max_iter=500,
    random_state=42
)

# Train with soft labels (knowledge distillation)
surrogate_nn.fit(X_train, y_train_soft.argmax(axis=1))  # Hard labels
# Vagy custom loss function-nel train-elni soft labels-re

print("✅ Surrogate trained with soft labels (knowledge distillation)")
```

**Sikeres támadás jele:** Soft labels-szel trained surrogate **magasabb fidelity**-t ér el (akár +5-10%).

---

### 3. Adaptive Query Strategy

**Cél:** Intelligens query selection (nem random samples).

**Stratégiák:**

#### A) Uncertainty Sampling
```python
# Query samples ahol a model uncertain (decision boundary közelében)
def get_uncertain_samples(surrogate, candidates, n=100):
    """Select samples where surrogate is most uncertain."""
    probs = surrogate.predict_proba(candidates)
    # Entropy-based uncertainty
    entropy = -np.sum(probs * np.log(probs + 1e-10), axis=1)
    uncertain_indices = np.argsort(entropy)[-n:]  # Top-N uncertain
    return [candidates[i] for i in uncertain_indices]

uncertain_samples = get_uncertain_samples(surrogate_model, new_candidates, n=200)

# Query ezeket a target-től
for sample in uncertain_samples:
    label = query_target_model(sample)
    # Retrain surrogate with new labels
```

**Hatékonyság:** Kevesebb query-vel magasabb fidelity.

---

#### B) Active Learning
```python
# Iterative refinement
for iteration in range(10):
    # 1. Find uncertain samples
    uncertain = get_uncertain_samples(surrogate_model, candidate_pool, n=100)
    
    # 2. Query target
    new_labels = [query_target_model(s) for s in uncertain]
    
    # 3. Retrain surrogate
    query_dataset.extend(uncertain)
    stolen_labels.extend(new_labels)
    surrogate_model.fit(query_dataset, stolen_labels)
    
    print(f"Iteration {iteration}: Fidelity improved")
```

---

### 4. Query Budget Optimization

**Cél:** Minimize query count while maximizing fidelity.

**Trade-off:**
- Sok query: magas fidelity, de **detectable** (rate limiting, cost)
- Kevés query: low fidelity, de **stealthy**

**Optimization:**
```python
# Calculate cost-benefit
query_costs = {
    "cheap_queries": 1000,   # $1/query → $1000 total
    "expensive_queries": 100  # $10/query → $1000 total
}

# Goal: maximize fidelity / cost
def optimize_queries(budget=1000):
    # Use active learning + uncertainty sampling
    # Target: 85%+ fidelity with minimal queries
    pass
```

---

### 5. API Abuse Detection Bypass

**Cél:** Rate limiting és anomaly detection elkerülése.

**Technikák:**

#### A) Slow & Steady
```python
import random

for text in query_dataset:
    label = query_target_model(text)
    
    # Random delay (1-5 sec) to mimic human behavior
    time.sleep(random.uniform(1, 5))
```

#### B) Distributed Queries (Multiple IPs)
```python
import requests

proxies_pool = [
    {"http": "http://proxy1.com:8080"},
    {"http": "http://proxy2.com:8080"},
    # ... több proxy
]

for i, text in enumerate(query_dataset):
    proxy = proxies_pool[i % len(proxies_pool)]
    response = requests.post(API_URL, json={"text": text}, proxies=proxy)
```

#### C) Multiple API Keys (Account Creation)
```python
api_keys = [
    "key_1_from_account_A",
    "key_2_from_account_B",
    # ... több fake account
]

for i, text in enumerate(query_dataset):
    key = api_keys[i % len(api_keys)]
    headers = {"Authorization": f"Bearer {key}"}
    # Query...
```

**Sikeres támadás jele:** Rate limiting nem blokkol, több ezer query végrehajtható.

---

### 6. Model Architecture Inference

**Cél:** Identify the target model's architecture.

**Módszer: Fingerprinting via Response Patterns**

```python
# Test queries designed to reveal model type
fingerprint_queries = [
    "What is the capital of France?",  # GPT-like models specific response style
    "[MASK] is the capital of France",  # BERT-style mask filling
    "Translate to French: Hello",      # Translation-specific models
]

responses = [query_target_model(q) for q in fingerprint_queries]

# Analyze response patterns
if "Paris" in responses[0] and "conversational" in style:
    print("Likely: GPT-3/4 or similar generative model")
elif "[MASK] → Paris" in responses[1]:
    print("Likely: BERT-based model")
```

**Haszon:** Ha tudod a model architecture-t, targeted surrogate-ot train-elhetsz (pl. DistilBERT, ha BERT-et detektáltál).

---

### 7. Transfer Learning Exploitation

**Cél:** Leverage pre-trained models a jobb extraction-ért.

```python
from transformers import AutoModelForSequenceClassification, AutoTokenizer

# Ha tudjuk, hogy a target BERT-based
base_model = "bert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(base_model)
model = AutoModelForSequenceClassification.from_pretrained(base_model, num_labels=3)

# Fine-tune a surrogate-ot a stolen labels-szel
# (kevesebb query kell, mert pre-trained model jó starting point)
```

---

## Vulnerabilitás Azonosítása

A model **sebezhető**, ha:

- ✅ **Fidelity > 90%:** Surrogate nearly perfect replication
- ✅ **Fidelity > 75%:** Moderately successful extraction
- ✅ **No rate limiting:** 10,000+ queries executable without throttling
- ✅ **Soft labels available:** API returns probability distributions
- ✅ **No query pattern detection:** Adaptive/active learning undetected
- ✅ **No API key rotation:** Same key usable for massive queries
- ✅ **No output perturbation:** Predictions deterministic (same input → same output)

---

## Védekezési Javaslatok

### 1. Query Rate Limiting

**Per-user limits:**
```python
# API Gateway config
rate_limits = {
    "free_tier": "100 requests/hour",
    "paid_tier": "1000 requests/hour",
    "enterprise": "10000 requests/hour"
}

# Block if threshold exceeded
if user_query_count > threshold:
    return {"error": "Rate limit exceeded"}
```

**IP-based throttling:**
```python
from collections import defaultdict
import time

ip_query_log = defaultdict(list)

def check_rate_limit(ip_address, window=3600, max_queries=500):
    """Allow max 500 queries per hour per IP."""
    current_time = time.time()
    # Clean old queries
    ip_query_log[ip_address] = [
        t for t in ip_query_log[ip_address] 
        if current_time - t < window
    ]
    
    if len(ip_query_log[ip_address]) >= max_queries:
        return False  # Rate limit exceeded
    
    ip_query_log[ip_address].append(current_time)
    return True
```

---

### 2. Output Perturbation (Differential Privacy)

**Add noise to predictions:**
```python
import numpy as np

def perturb_prediction(prediction, epsilon=0.1):
    """Add Laplacian noise to prediction probabilities."""
    noise = np.random.laplace(0, 1/epsilon, size=len(prediction))
    noisy_prediction = prediction + noise
    # Re-normalize
    noisy_prediction = np.clip(noisy_prediction, 0, 1)
    noisy_prediction /= noisy_prediction.sum()
    return noisy_prediction

# Example
original = np.array([0.95, 0.04, 0.01])
noisy = perturb_prediction(original, epsilon=0.5)
# Output: [0.93, 0.05, 0.02] (slightly different)
```

**Hatás:** Surrogate fidelity csökken (nehezebb extraction), de user experience még OK.

---

### 3. Anomaly Detection

**Suspicious query patterns:**
```python
def detect_anomaly(user_id):
    """Detect suspicious query patterns."""
    queries = get_user_queries(user_id, last_n=100)
    
    # Red flags:
    # 1. High query frequency
    if len(queries) > 1000 and time_span < 1_hour:
        alert("High frequency queries")
    
    # 2. Repetitive/systematic patterns
    if all_queries_very_similar(queries):
        alert("Systematic query pattern detected")
    
    # 3. Querying decision boundaries (adversarial)
    if queries_near_decision_boundary(queries):
        alert("Boundary probing detected")
```

---

### 4. API Key Rotation & Monitoring

```python
# Automatic key rotation
def rotate_api_key_if_suspicious(user_id):
    if anomaly_detected(user_id):
        old_key = get_api_key(user_id)
        new_key = generate_new_key()
        invalidate_key(old_key)
        notify_user(user_id, "API key rotated due to suspicious activity")
        return new_key
```

---

### 5. Watermarking (Model Output)

**Embed invisible watermark in predictions:**
```python
def watermark_output(prediction, user_id):
    """Embed user-specific watermark."""
    # Subtle modification based on user_id hash
    watermark = hash(user_id) % 0.001
    return prediction + watermark

# Later, if surrogate model is found:
def detect_watermark(surrogate_predictions):
    # Check if predictions contain user-specific patterns
    # → Identify who leaked/extracted the model
    pass
```

---

### 6. Legal & Contractual Protections

**Terms of Service (ToS):**
```
"Users are prohibited from:
- Systematically querying the API to replicate model functionality
- Training surrogate models on API predictions
- Redistributing model outputs for commercial purposes

Violation may result in account termination and legal action."
```

---

## Hasznos Toolok

- **ML Privacy Meter**  
  [https://github.com/privacytrustlab/ml_privacy_meter](https://github.com/privacytrustlab/ml_privacy_meter)  
  Model extraction vulnerability quantification

- **PrivacyRaven**  
  [https://github.com/trailofbits/PrivacyRaven](https://github.com/trailofbits/PrivacyRaven)  
  Extraction attack testing & defense

- **IBM ART (Adversarial Robustness Toolbox)**  
  [https://github.com/Trusted-AI/adversarial-robustness-toolbox](https://github.com/Trusted-AI/adversarial-robustness-toolbox)  
  Model extraction detection & mitigation

- **TensorFlow Privacy**  
  [https://github.com/tensorflow/privacy](https://github.com/tensorflow/privacy)  
  Differential privacy for model outputs

---

## Teszt Checklist

- [ ] Black-box extraction (systematic queries)
- [ ] Confidence-based extraction (soft labels)
- [ ] Adaptive query strategy (active learning)
- [ ] Rate limiting bypass testing
- [ ] API key abuse testing
- [ ] Fidelity measurement (>90% = critical)
- [ ] Query pattern anomaly detection
- [ ] Output perturbation effectiveness
- [ ] Watermark detection (if implemented)

---

## Referenciák

- OWASP Top 10 LLM02:2025 - [https://genai.owasp.org/](https://genai.owasp.org/)
- Stealing Machine Learning Models via Prediction APIs - Tramèr et al., USENIX 2016 - [https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/tramer](https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/tramer)
- Extraction Attacks on Machine Learning - Jagielski et al., IEEE S&P 2020 - [https://doi.org/10.1109/SP40000.2020.00045](https://doi.org/10.1109/SP40000.2020.00045)
- Efficient and Effective Model Extraction - [https://arxiv.org/abs/2409.14122](https://arxiv.org/abs/2409.14122)
