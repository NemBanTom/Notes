# AITG-MOD-03 - Poisoned Training Sets Tesztelés

## Mi ez és miért fontos?

A **poisoned training sets** attack során a támadó **training data-t manipulálja** training előtt → backdoor, bias, performance degradation.

**Attack vectors:**
- **Label flipping:** Incorrect labels (2-10% of dataset)
- **Backdoor triggers:** Specific pattern → target class
- **Targeted poisoning:** Subgroup degradation

**OWASP Kategória:** LLM04:2025 Data/Model Poisoning

---

## Gyakorlati Payloadok

### 1. Label Flipping Detection

**Tool: Cleanlab**

```python
from cleanlab.filter import find_label_issues
import numpy as np

# Suspected dataset
X_train = load_features()  # (10000, 128)
y_train = load_labels()    # (10000,)

# Train model to get predicted probabilities
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Cross-validated predictions
from sklearn.model_selection import cross_val_predict
pred_probs = cross_val_predict(
    model, X_train, y_train,
    cv=5, method='predict_proba'
)

# Find label issues
issues = find_label_issues(
    labels=y_train,
    pred_probs=pred_probs,
    return_indices_ranked_by='self_confidence'
)

print(f"Suspected mislabeled samples: {len(issues)}")
print(f"Mislabel rate: {len(issues)/len(y_train):.2%}")

# Inspect top issues
for idx in issues[:10]:
    print(f"Sample {idx}: True label {y_train[idx]}, Predicted {pred_probs[idx].argmax()}")
```

**Sebezhető eredmény:**
```
Suspected mislabeled samples: 237
Mislabel rate: 2.37%  ← CRITICAL if systematic!

Sample 142: True label 0, Predicted 1 (conf: 0.95)
Sample 891: True label 1, Predicted 0 (conf: 0.92)
...
```

**Tool:** Cleanlab - [https://github.com/cleanlab/cleanlab](https://github.com/cleanlab/cleanlab)

---

### 2. Backdoor Trigger Detection (Activation Clustering)

**Tool: ART**

```python
from art.defences.detector.poison import ActivationDefense
from art.estimators.classification import KerasClassifier

# Load suspected model
model = load_keras_model()
classifier = KerasClassifier(model=model)

# Activation defense
defense = ActivationDefense(classifier, x_train, y_train)

# Detect backdoor
report = defense.detect_poison(nb_clusters=2, nb_dims=10)

print(f"Poison detected: {report['is_poison_detected']}")
print(f"Poisoned indices: {report['poison_indices']}")
```

**Sebezhető eredmény:**
```
Poison detected: True
Poisoned indices: [45, 127, 389, 512, ...]  (15 samples)
```

**Tool:** ART - [https://github.com/Trusted-AI/adversarial-robustness-toolbox](https://github.com/Trusted-AI/adversarial-robustness-toolbox)

---

### 3. Data Drift/Anomaly Detection

**Tool: TensorFlow Data Validation**

```python
import tensorflow_data_validation as tfdv

# Generate schema from clean baseline
baseline_stats = tfdv.generate_statistics_from_csv('clean_data.csv')
schema = tfdv.infer_schema(baseline_stats)

# Analyze new training data
new_stats = tfdv.generate_statistics_from_csv('new_training_data.csv')

# Detect anomalies
anomalies = tfdv.validate_statistics(new_stats, schema)

if anomalies.anomaly_info:
    print("⚠️ Anomalies detected:")
    for feature, info in anomalies.anomaly_info.items():
        print(f"  {feature}: {info.description}")
```

**Tool:** TFDV - [https://www.tensorflow.org/tfx/data_validation](https://www.tensorflow.org/tfx/data_validation)

---

## Védekezési Javaslatok

### 1. Automated Data Sanitization

```python
from cleanlab.classification import CleanLearning

# Automatically find and remove label errors
cl = CleanLearning(clf=RandomForestClassifier())
cl.fit(X_train, y_train)

# Get cleaned dataset
cleaned_indices = cl.get_label_issues(return_indices_ranked_by='self_confidence')
X_clean = np.delete(X_train, cleaned_indices, axis=0)
y_clean = np.delete(y_train, cleaned_indices)
```

---

### 2. Dataset Versioning

```bash
# DVC (Data Version Control)
dvc add training_data.csv
git add training_data.csv.dvc
git commit -m "Training data v1.0"
```

**Tool:** DVC - [https://dvc.org/](https://dvc.org/)

---

## Referenciák

- OWASP LLM04:2025 - [https://genai.owasp.org/llmrisk/llm042025-data-and-model-poisoning/](https://genai.owasp.org/llmrisk/llm042025-data-and-model-poisoning/)
- Confident Learning - [https://arxiv.org/abs/1911.00068](https://arxiv.org/abs/1911.00068)
