# AITG-MOD-05 - Model Inversion Attacks Tesztelés

## Mi ez és miért fontos?

A **model inversion** attack során a támadó **rekonstruálja a training data-t** model outputs/gradients alapján → PII exposure.

**Attack types:**
- **Gradient-based:** Gradient descent on random noise
- **Confidence-based:** Query with many inputs, infer attributes
- **Intermediate layer:** Richer representations → better reconstruction

**OWASP Kategória:** LLM02:2025 Sensitive Information Disclosure

---

## Gyakorlati Payloadok

### 1. Gradient-Based Inversion

**Tool: ART**

```python
from art.attacks.inference.model_inversion import MIFace

# Face recognition model
classifier = KerasClassifier(model=face_model)

# Inversion attack for specific person
attack = MIFace(classifier, max_iter=10000, window_length=100)

# Reconstruct face for target class (e.g., "Person A")
target_class = 42  # Person A's ID

reconstructed_face = attack.infer(x=None, y=target_class)

# Visualize
import matplotlib.pyplot as plt
plt.imshow(reconstructed_face[0])
plt.title(f"Reconstructed: Person {target_class}")
plt.show()
```

**Sikeres támadás jele:** Reconstructed image resembles Person A's face.

**Tool:** ART - [https://github.com/Trusted-AI/adversarial-robustness-toolbox](https://github.com/Trusted-AI/adversarial-robustness-toolbox)

---

### 2. Confidence-Based Attribute Inference

```python
# Infer sensitive attribute (e.g., age) from medical diagnosis model
test_samples = generate_age_diverse_samples()

predictions = []
for sample in test_samples:
    pred = model.predict(sample)
    predictions.append(pred)

# Analyze confidence patterns
from sklearn.linear_model import LogisticRegression

# Train attack model: confidence → age
attack_model = LogisticRegression()
attack_model.fit(predictions, known_ages)

# Infer age for unknown sample
unknown_conf = model.predict(unknown_sample)
inferred_age = attack_model.predict([unknown_conf])
print(f"Inferred age: {inferred_age}")
```

---

## Védekezési Javaslatok

### 1. Differential Privacy

```python
# DP-SGD training
from opacus import PrivacyEngine

privacy_engine = PrivacyEngine()

model, optimizer, data_loader = privacy_engine.make_private(
    module=model,
    optimizer=optimizer,
    data_loader=train_loader,
    noise_multiplier=1.1,
    max_grad_norm=1.0
)
```

**Tool:** Opacus - [https://github.com/pytorch/opacus](https://github.com/pytorch/opacus)

---

### 2. Output Perturbation

```python
def perturb_output(logits):
    # Add Laplacian noise
    noise = np.random.laplace(0, scale=0.1, size=logits.shape)
    return logits + noise
```

---

## Referenciák

- Model Inversion - Fredrikson - [https://dl.acm.org/doi/10.1145/2810103.2813677](https://dl.acm.org/doi/10.1145/2810103.2813677)
