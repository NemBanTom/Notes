# AITG-MOD-06 - Robustness to New Data Tesztelés

## Mi ez és miért fontos?

A **robustness to new data** azt jelenti, hogy a model **jól teljesít out-of-distribution (OOD) data-n** is, nem csak training distribution-ön.

**Failure modes:**
- **Data drift:** Feature distributions shift
- **OOD inputs:** Completely unfamiliar data
- **Edge cases:** Extreme/rare scenarios

**OWASP Kategória:** LLM05:2025 Improper Output Handling

---

## Gyakorlati Payloadok

### 1. Data Drift Detection

**Tool: Evidently AI**

```python
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset

# Reference data (training)
reference_data = pd.read_csv('train_data.csv')

# Current data (production)
current_data = pd.read_csv('prod_data_2024.csv')

# Generate drift report
report = Report(metrics=[DataDriftPreset()])
report.run(reference_data=reference_data, current_data=current_data)

# Save HTML report
report.save_html('drift_report.html')

# Check drift programmatically
drift_summary = report.as_dict()
if drift_summary['metrics'][0]['result']['dataset_drift']:
    print("⚠️ CRITICAL: Dataset drift detected!")
    
    # Show drifted features
    for feature, result in drift_summary['metrics'][0]['result']['drift_by_columns'].items():
        if result['drift_detected']:
            print(f"  Feature '{feature}': PSI = {result['stattest_score']:.3f}")
```

**Sebezhető eredmény:**
```
⚠️ CRITICAL: Dataset drift detected!
  Feature 'age': PSI = 0.34 (HIGH drift)
  Feature 'income': PSI = 0.27 (MODERATE drift)
```

**PSI Thresholds:** <0.1 stable, 0.1-0.25 moderate, >0.25 critical

**Tool:** Evidently - [https://github.com/evidentlyai/evidently](https://github.com/evidentlyai/evidently)

---

### 2. DeepChecks Data Integrity

```python
from deepchecks.tabular import Dataset
from deepchecks.tabular.suites import data_integrity

# Create datasets
train_ds = Dataset(train_df, label='target', cat_features=['category'])
test_ds = Dataset(test_df, label='target', cat_features=['category'])

# Run integrity suite
suite = data_integrity()
result = suite.run(train_dataset=train_ds, test_dataset=test_ds)

# Display results
result.show()

# Check for failures
if result.get_not_passed_checks():
    print("⚠️ Data integrity issues found:")
    for check in result.get_not_passed_checks():
        print(f"  - {check}")
```

**Tool:** DeepChecks - [https://github.com/deepchecks/deepchecks](https://github.com/deepchecks/deepchecks)

---

### 3. OOD Detection

**Tool: Alibi Detect**

```python
from alibi_detect.od import OutlierVAE

# Train OOD detector on in-distribution data
od = OutlierVAE(
    threshold=0.1,
    encoder_net=encoder,
    decoder_net=decoder,
    latent_dim=32
)

od.fit(x_train, epochs=50)

# Test on new data
ood_preds = od.predict(x_new)

ood_count = ood_preds['data']['is_outlier'].sum()
print(f"OOD samples: {ood_count}/{len(x_new)} ({ood_count/len(x_new):.1%})")
```

**Sebezhető behavior:**
- Model makes high-confidence predictions on OOD data
- No flagging/low-confidence warnings

**Tool:** Alibi Detect - [https://github.com/SeldonIO/alibi-detect](https://github.com/SeldonIO/alibi-detect)

---

### 4. Edge Case Testing

```python
# Generate edge cases
edge_cases = [
    # Extreme values
    {'age': 150, 'income': 0},          # Impossible age
    {'age': -5, 'income': 1000000000},  # Negative age
    
    # Boundary values
    {'age': 0, 'income': 0},
    {'age': 120, 'income': 999999999},
]

for case in edge_cases:
    pred = model.predict([case])
    confidence = pred.max()
    
    if confidence > 0.9:
        print(f"⚠️ High confidence ({confidence:.2f}) on edge case: {case}")
```

**Sebezhető:** High confidence on impossible/extreme inputs.

---

## Védekezési Javaslatok

### 1. Continuous Monitoring

```python
# MLOps pipeline
from evidently.pipeline.column_mapping import ColumnMapping

@scheduled_job('cron', hour=2)  # Daily 2 AM
def check_data_drift():
    reference = load_training_data()
    current = load_last_24h_production_data()
    
    report = Report(metrics=[DataDriftPreset()])
    report.run(reference_data=reference, current_data=current)
    
    if report.as_dict()['metrics'][0]['result']['dataset_drift']:
        send_alert("Data drift detected - model retraining recommended")
```

---

### 2. Uncertainty Quantification

```python
# Bayesian Neural Network
import tensorflow_probability as tfp

def build_bayesian_model():
    model = tf.keras.Sequential([
        tfp.layers.DenseVariational(128, activation='relu'),
        tfp.layers.DenseVariational(10, activation='softmax')
    ])
    return model

# Predict with uncertainty
predictions = []
for _ in range(100):  # Monte Carlo samples
    pred = model(x_test, training=True)
    predictions.append(pred)

mean_pred = np.mean(predictions, axis=0)
uncertainty = np.std(predictions, axis=0)

# Flag high uncertainty
high_uncertainty = uncertainty.max(axis=1) > 0.3
print(f"High uncertainty samples: {high_uncertainty.sum()}")
```

---

### 3. Periodic Retraining

```bash
# Automated retraining pipeline
0 2 1 * * /scripts/retrain_model.sh  # Monthly on 1st
```

---

## Referenciák

- Failing Loudly - Rabanser - [https://arxiv.org/abs/1810.11953](https://arxiv.org/abs/1810.11953)
- OWASP LLM05:2025 - [https://genai.owasp.org/llmrisk/llm052025-improper-output-handling/](https://genai.owasp.org/llmrisk/llm052025-improper-output-handling/)
