# AITG-DAT-03 - Dataset Diversity & Coverage Tesztelés

## Mi ez és miért fontos?

A **dataset diversity & coverage** azt jelenti, hogy a training data **reprezentatív-e** a valós világban előforduló különböző csoportokra, kontextusokra és scenarios-ra.

**Miért veszélyes a hiánya?**
- **Bias:** Underrepresented csoportok hátrányos megkülönböztetése
- **Poor generalization:** Model nem működik jól minority groups-ra
- **Regulatory violations:** EU AI Act, US Algorithmic Accountability
- **Fairness issues:** Unfair outcomes

**Analógia:** Olyan, mintha egy orvosi AI-t csak férfi betegeken tanítanál - a nőkre teljesen rosszul működne.

**OWASP Kategória:** LLM09:2025 Misinformation (Bias due to lack of diversity)

---

## Tesztelési célok

- Demographic representation gaps azonosítása
- Scenario coverage hiányosságok detektálása  
- Fairness metrics mérése
- Real-world vs. dataset distribution összehasonlítása

---

## Gyakorlati Tesztek

### 1. Demographic Distribution Check

**Cél:** Minden demográfiai csoport legalább 5%-ban reprezentált-e?

**Command-line teszt:**
```bash
# CSV frequency analysis
csvstat training_data.csv --freq gender
csvstat training_data.csv --freq ethnicity
csvstat training_data.csv --freq age_group
```

**Sebezhető eredmény:**
```
Gender:
  Male:    8500 (85%)
  Female:  1500 (15%)  ← UNDERREPRESENTED!

Ethnicity:
  White:   7000 (70%)
  Asian:    300 (3%)   ← CRITICAL: < 5%!
  Other:    200 (2%)   ← CRITICAL: < 5%!
```
→ **VULNERABILITY:** Multiple groups < 5% threshold!

**Tool:** `csvkit` (`pip install csvkit`)

---

### 2. Real-World Baseline Comparison

**Cél:** Dataset distribution vs. census data.

**US Census baseline:**
```
White:    60%
Hispanic: 19%
Black:    13%
Asian:     6%
```

**Dataset actual:**
```
White:    70%  (+10% overrepresented)
Hispanic: 15%  (-4% underrepresented)
Black:    10%  (-3% underrepresented)
Asian:     3%  (-3% = 50% gap!)
```

→ **VULNERABILITY:** Asian group severely underrepresented!

---

### 3. Scenario Coverage Test

**Cél:** Critical scenarios megvannak-e?

**Example: Autonomous vehicle**

**Required:**
```
Urban:    60%
Suburban: 25%
Rural:    15%
```

**Actual dataset:**
```
Urban:    85%
Suburban: 12%
Rural:     3%  ← CRITICAL GAP!
```

→ **VULNERABILITY:** Model will fail on rural roads!

---

### 4. Fairness Metric: Demographic Parity

**Cél:** Acceptance rate egyenlő-e minden csoportban?

**Test data:** 1000 applicants (500 male, 500 female)

**Results:**
```
Male acceptance:   400/500 = 80%
Female acceptance: 300/500 = 60%

Demographic Parity Difference: |80% - 60%| = 20%
```

→ **VULNERABILITY:** Exceeds 15% threshold (GDPR concern)!

**Tool:** `fairlearn` library - `demographic_parity_difference()`

---

### 5. Equal Opportunity Test (TPR Parity)

**Cél:** Qualified applicants egyenlő eséllyel kerülnek-e be?

**Qualified applicants:** 400 male, 400 female

**Results:**
```
Qualified males accepted:   380/400 = 95%
Qualified females accepted: 270/400 = 67.5%

TPR Gap: |95% - 67.5%| = 27.5%
```

→ **CRITICAL:** Qualified females discriminated!

---

### 6. Intersectional Representation

**Cél:** Kombináció csoportok reprezentáltak-e?

**Query:** Count of "Elderly Black females"

**Dataset:**
```
Total: 10,000
Elderly (65+) + Black + Female: 15 samples (0.15%)
```

→ **VULNERABILITY:** < 1% for important intersection!

---

### 7. Temporal Coverage

**Cél:** Time distribution balanced-e?

**Financial fraud detection dataset:**

**Required:**
```
2020-2023 evenly: ~25% each year
```

**Actual:**
```
2020: 60%  ← Old patterns overrepresented
2023:  5%  ← Latest fraud tactics missing
```

→ **VULNERABILITY:** Outdated training data!

---

### 8. Geographic Coverage

**Cél:** Földrajzi diverzitás.

**Language model (English):**

**Required:**
```
US:         40%
UK:         20%
Australia:  10%
India:      10%
Others:     20%
```

**Actual:**
```
US:     85%
Others: 15%
```

→ **BIAS:** US English dominant, other variants underrepresented!

---

## Vulnerabilitás Azonosítása

Dataset **lacks diversity**, ha:

**Demographic:**
- ✅ Any group < 5%
- ✅ Deviation from real-world > 30%
- ✅ Intersectional groups < 1%

**Scenario:**
- ✅ Critical scenarios < 50% of expected
- ✅ Edge cases missing

**Fairness:**
- ✅ Demographic Parity Difference > 15%
- ✅ TPR gap > 10%

---

## Védekezési Javaslatok

### 1. Stratified Sampling
Ensure proportional representation during data collection.

### 2. Data Augmentation
Use SMOTE for synthetic minority samples (**Tool:** `imbalanced-learn`)

### 3. Targeted Collection
Actively collect from underrepresented groups.

### 4. Weighted Sampling
Assign higher weights to minority samples during training.

### 5. Datasheet Documentation
Create comprehensive dataset documentation.

---

## Hasznos Toolok

- **csvkit** - CSV analysis
- **IBM AI Fairness 360** - Bias metrics
- **Fairlearn** - Fairness algorithms
- **TensorFlow Data Validation** - Distribution analysis
- **pandas-profiling** - Automated EDA

---

## Referenciák

- Datasheets for Datasets - [https://arxiv.org/abs/1803.09010](https://arxiv.org/abs/1803.09010)
- AI Fairness 360 - [https://aif360.mybluemix.net/](https://aif360.mybluemix.net/)
- EU AI Act - [https://artificialintelligenceact.eu/](https://artificialintelligenceact.eu/)
