# AITG-DAT-04 - Harmful Content in Data Tesztelés

## Mi ez és miért fontos?

A **harmful content in data** azt jelenti, hogy a training dataset **toxikus, biased, vagy etikátlan** tartalmat tartalmaz, ami propagálódik az AI output-ban.

**Harmful content típusok:**
- **Toxicity:** Hate speech, profanity, offensive language
- **Bias:** Stereotypes, discriminatory examples
- **Misinformation:** False facts, conspiracy theories

**Miért veszélyes?**
- **Toxic outputs:** AI reprodukálja a hate speech-t (lásd: Microsoft Tay)
- **Bias propagation:** Stereotypes megerősítése
- **Misinformation spread:** Fake news terjesztése
- **Brand damage:** Reputational harm

**OWASP Kategória:** LLM09:2025 Misinformation (Harmful Training Data)

---

## Tesztelési célok

- Toxicity detection a training data-ban
- Bias & stereotype identification
- Misinformation flagging
- Harmful content rate measurement (<1% threshold)

---

## Gyakorlati Tesztek

### 1. Toxicity Scan (Perspective API)

**Cél:** Dataset tartalmaz-e toxic content-et?

**Teszt módszer:**
```bash
# Sample random 1000 entries
shuf -n 1000 training_data.csv > sample.csv

# Scan with Perspective API
curl -X POST https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze \
  -H "Content-Type: application/json" \
  -d '{
    "comment": {"text": "SAMPLE_TEXT_HERE"},
    "requestedAttributes": {"TOXICITY": {}}
  }'
```

**Sebezhető eredmény:**
```
Sample 1: "Those [ethnic slur] are all criminals" - Toxicity: 0.95
Sample 2: "I hate [group]" - Toxicity: 0.89
Sample 3: "[Profanity] off you [insult]" - Toxicity: 0.92

Toxic samples: 78/1000 (7.8%)
```

→ **CRITICAL:** 7.8% > 1% threshold!

**Tool:** Perspective API - [https://perspectiveapi.com/](https://perspectiveapi.com/)

---

### 2. Keyword Blocklist Scan

**Cél:** Known toxic keywords detection.

**Teszt:**
```bash
# Create blocklist
echo "n-word
f-word
[ethnic slurs]
[hate speech terms]" > toxic_blocklist.txt

# Scan dataset
grep -i -f toxic_blocklist.txt training_data.csv | wc -l
```

**Sebezhető eredmény:**
```
Matches found: 342 instances
Harmful content rate: 342/10000 = 3.4%
```

→ **CRITICAL:** Exceeds 1% threshold!

---

### 3. Stereotype Detection

**Cél:** Biased/stereotypical content azonosítása.

**Regex patterns:**
```bash
# Stereotype patterns
grep -iE "women (are|can't|should|always)" training_data.csv
grep -iE "men (are|never|always)" training_data.csv
grep -iE "(black|asian|hispanic) people (are|tend to)" training_data.csv
```

**Sebezhető eredmény:**
```
"Women are bad at math" - FOUND
"Men never show emotions" - FOUND
"Asian people are good at math" - FOUND (positive stereotype, but still bias)

Stereotype instances: 156/10000 (1.56%)
```

→ **WARNING:** Bias rate > 1%

---

### 4. Misinformation Detection

**Cél:** Known false claims a dataset-ben?

**Known false claims list:**
```
- "Vaccines cause autism"
- "5G causes COVID-19"
- "Earth is flat"
- "Moon landing was faked"
- "Climate change is a hoax"
```

**Teszt:**
```bash
# Search for misinformation
grep -i "vaccines cause autism" training_data.csv
grep -i "5G.*COVID" training_data.csv
grep -i "earth is flat" training_data.csv
```

**Sebezhető eredmény:**
```
"Vaccines cause autism according to..." - FOUND (3 instances)
"5G towers spread COVID" - FOUND (2 instances)

Misinformation rate: 5/10000 = 0.05%
```

→ **WARNING:** Any misinformation is concerning!

---

### 5. Detoxify Library Scan

**Cél:** Automated toxicity scoring.

**Command:**
```bash
# Install detoxify
pip install detoxify

# Scan dataset (Python one-liner)
python -c "
from detoxify import Detoxify
import csv

model = Detoxify('original')
toxic_count = 0

with open('training_data.csv') as f:
    for row in csv.reader(f):
        text = row[0]
        score = model.predict(text)['toxicity']
        if score > 0.7:
            toxic_count += 1
            print(f'Toxic: {text[:50]}... (score: {score:.2f})')

print(f'Toxic rate: {toxic_count/10000:.2%}')
"
```

**Sebezhető eredmény:**
```
Toxic: "You're such a [insult]..." (score: 0.89)
Toxic: "Go die [profanity]" (score: 0.95)
...
Toxic rate: 2.3%
```

→ **CRITICAL:** 2.3% > 1% threshold!

**Tool:** Detoxify - [https://github.com/unitaryai/detoxify](https://github.com/unitaryai/detoxify)

---

### 6. Sentiment Extremes

**Cél:** Extrém negatív sentiment detection.

**Teszt:**
```bash
# Using sentiment analysis tool
textblob-sentiment training_data.csv | awk '$2 < -0.8 {print}'
```

**Sebezhető eredmény:**
```
Extremely negative samples: 234 (-0.9 to -1.0 polarity)
Rate: 2.34%
```

→ May indicate toxic/harmful content clustering.

---

### 7. PII in Training Data (Privacy Concern)

**Cél:** Sensitive personal data a training set-ben?

**Patterns:**
```bash
# Email addresses
grep -oE '\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b' training_data.csv | wc -l

# SSN
grep -oE '\b\d{3}-\d{2}-\d{4}\b' training_data.csv | wc -l

# Credit cards
grep -oE '\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b' training_data.csv | wc -l
```

**Sebezhető eredmény:**
```
Emails: 1,234 instances
SSNs: 45 instances
Credit cards: 12 instances
```

→ **CRITICAL:** PII in training data = privacy violation!

---

### 8. Profanity Filter

**Cél:** Profanity/vulgarity measurement.

**Tool:** `profanity-check` library

**Teszt:**
```bash
pip install profanity-check

python -c "
from profanity_check import predict
import csv

profane_count = 0
with open('training_data.csv') as f:
    for row in csv.reader(f):
        if predict([row[0]])[0] == 1:
            profane_count += 1

print(f'Profanity rate: {profane_count/10000:.2%}')
"
```

**Sebezhető eredmény:**
```
Profanity rate: 4.2%
```

→ **CRITICAL:** High profanity rate!

---

### 9. Manual Sampling Review

**Cél:** Human-in-the-loop spot check.

**Method:**
```bash
# Random sample 100 entries
shuf -n 100 training_data.csv > manual_review.csv

# Manual review by humans
# Flag: toxic, biased, misinformation, profanity, PII
```

**Sebezhető eredmény:**
```
Reviewer findings (100 samples):
- Toxic: 5 (5%)
- Biased: 3 (3%)
- Misinformation: 1 (1%)
- Profanity: 7 (7%)

Total harmful: 16/100 (16%)
```

→ **CRITICAL:** 16% harmful content rate!

---

## Vulnerabilitás Azonosítása

Dataset **contains harmful content**, ha:

- ✅ **Toxicity rate > 1%** (Perspective API or Detoxify)
- ✅ **Blocklist matches > 1%**
- ✅ **Bias/stereotype rate > 2%**
- ✅ **Any misinformation** present (even 0.1% is concerning)
- ✅ **PII in dataset** (emails, SSN, credit cards)
- ✅ **Profanity > 5%**

---

## Védekezési Javaslatok

### 1. Automated Filtering Pipeline

**Pre-training filter:**
- Perspective API scan → Remove samples with toxicity > 0.5
- Blocklist matching → Remove
- PII detection (regex) → Redact or remove

### 2. Human Review for Borderline Cases

**Toxicity score 0.4-0.6:** Flag for human review

### 3. Data Source Verification

**Only accept data from:**
- Verified, moderated platforms
- Curated datasets with quality guarantees
- Avoid: Unfiltered web scrapes, social media dumps

### 4. Regular Re-scanning

**Monthly audits:** Re-scan training data as new toxic patterns emerge.

### 5. Datasheet Documentation

**Document known issues:**
```
## Known Limitations
- Toxicity rate: 0.8% (post-filtering)
- Some historical text may contain outdated language
- Recommendation: Apply additional content filtering at inference
```

---

## Hasznos Toolok

**Toxicity Detection:**
- **Perspective API** - Google's toxicity API
- **Detoxify** - Open-source toxicity classifier
- **profanity-check** - Profanity detection

**Bias Analysis:**
- **IBM AI Fairness 360** - Bias metrics
- **Fairlearn** - Bias detection tools

**PII Detection:**
- **Google Cloud DLP** - Automated PII detection
- **Microsoft Presidio** - PII anonymization

**Misinformation:**
- **ClaimBuster** - Fact-checking API
- **Snopes API** - Fact verification

---

## Teszt Checklist

- [ ] Toxicity scan (Perspective API / Detoxify)
- [ ] Blocklist matching (toxic keywords)
- [ ] Stereotype pattern detection (regex)
- [ ] Misinformation search (known false claims)
- [ ] PII detection (emails, SSN, CC)
- [ ] Profanity check
- [ ] Manual sampling review (100-500 samples)

---

## Referenciák

- OWASP AI Exchange - [https://genai.owasp.org/](https://genai.owasp.org/)
- NIST AI RMF - [https://doi.org/10.6028/NIST.AI.100-2e2025](https://doi.org/10.6028/NIST.AI.100-2e2025)
- Microsoft Tay Case Study - [https://www.theverge.com/2016/3/24/11297050/tay-microsoft-chatbot-racist](https://www.theverge.com/2016/3/24/11297050/tay-microsoft-chatbot-racist)
- Perspective API - [https://perspectiveapi.com/](https://perspectiveapi.com/)
- Detoxify - [https://github.com/unitaryai/detoxify](https://github.com/unitaryai/detoxify)
