# AITG-DAT-05 - Data Minimization & Consent Tesztelés

## Mi ez és miért fontos?

A **data minimization** azt jelenti, hogy csak a **strictly necessary** adatot gyűjtjük/tároljuk. A **consent** pedig, hogy a user **explicit engedélyt adott** az adatkezelésre.

**Compliance:**
- **GDPR:** Article 5(1)(c) - data minimization principle
- **CCPA:** Right to know & delete personal information
- **HIPAA:** Minimum necessary standard

**Miért veszélyes a hiánya?**
- **Privacy violation:** Excessive/unnecessary data collection
- **Regulatory fines:** GDPR max €20M vagy 4% global revenue
- **Consent violations:** Processing without permission
- **Data retention issues:** Stale data not deleted

**Analógia:** Olyan, mintha egy webshop bekérné a vércsoportodat cipővásárláshoz, vagy tovább tárolná az adataidat azután is, hogy törölted a fiókodat és visszavontad a hozzájárulást.

**OWASP Kategória:** GDPR/CCPA Compliance + Privacy Best Practices

---

## Tesztelési célok

- Excessive data collection detection
- Consent mechanism validation
- Data retention policy compliance
- User rights (access, deletion) testing

---

## Gyakorlati Payloadok

### 1. Excessive Data Collection Test

**Cél:** Rendszer elfogad-e és tárolja-e szükségtelen mezőket?

**Payload: Registration with excessive fields**

```bash
curl -X POST https://api.company.com/v1/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "SecurePass123",
    "name": "John Doe",
    
    "ssn": "123-45-6789",
    "blood_type": "O+",
    "income": 75000,
    "medical_history": "diabetes",
    "political_affiliation": "Independent",
    "sexual_orientation": "heterosexual",
    "religion": "Christian"
  }'
```

**Sebezhető behavior:** HTTP 200, all fields accepted

**Verify storage:**
```bash
curl https://api.company.com/v1/user/profile \
  -H "Authorization: Bearer token"
```

**Sebezhető response:**
```json
{
  "email": "user@example.com",
  "name": "John Doe",
  "ssn": "123-45-6789",           // ← SHOULD NOT BE STORED
  "blood_type": "O+",              // ← IRRELEVANT
  "income": 75000,                 // ← NOT NECESSARY
  "medical_history": "diabetes"    // ← EXCESSIVE
}
```
→ **CRITICAL:** System stores excessive/unnecessary data!

**Helyes behavior:**
- HTTP 400 Bad Request with error: `"Unexpected fields: ssn, blood_type, income"`
- OR: Silently drop unnecessary fields, store only email/password/name

---

### 2. Schema Validation Test

**Cél:** Backend validates input against strict schema?

**Payload: Unexpected field injection**

```bash
curl -X POST https://api.company.com/v1/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "SecurePass123",
    "unexpected_field": "should_be_rejected",
    "admin_override": true,
    "internal_flag": "bypass_validation"
  }'
```

**Sebezhető response:** HTTP 200 (fields accepted)

**Helyes response:**
```json
HTTP/1.1 400 Bad Request

{
  "error": "Invalid request",
  "details": {
    "unexpected_fields": ["unexpected_field", "admin_override", "internal_flag"]
  }
}
```

---

### 3. Consent Withdrawal Test

**Cél:** Consent visszavonás után is folytatódik-e az adatkezelés?

**Step 1: Grant consent**

```bash
curl -X POST https://api.company.com/v1/consent \
  -H "Authorization: Bearer user_token" \
  -d '{
    "user_id": 12345,
    "consent_type": "marketing_emails",
    "granted": true
  }'
```

**Step 2: Verify emails sent**

```bash
# Wait 24 hours, check email logs
curl https://api.company.com/v1/logs/emails?user_id=12345 \
  -H "Authorization: Bearer admin_token"
```

**Expected:** Marketing email sent (consent active)

---

**Step 3: Withdraw consent**

```bash
curl -X POST https://api.company.com/v1/consent \
  -H "Authorization: Bearer user_token" \
  -d '{
    "user_id": 12345,
    "consent_type": "marketing_emails",
    "granted": false
  }'
```

**Step 4: Verify processing stopped**

```bash
# Wait another 24 hours
curl https://api.company.com/v1/logs/emails?user_id=12345&after=<withdrawal_timestamp> \
  -H "Authorization: Bearer admin_token"
```

**Sebezhető result:**
```json
{
  "emails_sent": [
    {"to": "user@example.com", "type": "marketing", "sent_at": "2024-01-31T10:00:00Z"},
    {"to": "user@example.com", "type": "marketing", "sent_at": "2024-02-01T10:00:00Z"}
  ]
}
```
→ **CRITICAL:** Marketing emails sent AFTER consent withdrawal!

**Helyes result:**
```json
{
  "emails_sent": []
}
```

---

### 4. Consent Status Check Before Processing

**Cél:** Każdy processing job ellenőrzi-e a consent status-t?

**Payload: Trigger background job without consent**

```bash
# Withdraw all consent first
curl -X DELETE https://api.company.com/v1/consent/all \
  -H "Authorization: Bearer user_token"

# Trigger a processing job that requires consent
curl -X POST https://api.company.com/v1/analytics/profile-analysis \
  -H "Authorization: Bearer user_token" \
  -d '{"user_id": 12345}'
```

**Sebezhető response:** HTTP 200, job started

**Helyes response:**
```json
HTTP/1.1 403 Forbidden

{
  "error": "Consent required",
  "message": "This operation requires 'analytics' consent, which you have not granted."
}
```

---

### 5. Data Retention Policy Test

**Cél:** Expired data törlődik-e automatikusan?

**Step 1: Check retention policy**

```bash
curl https://api.company.com/v1/policies/retention
```

**Expected response:**
```json
{
  "logs": "90 days",
  "user_activity": "1 year",
  "support_tickets": "3 years"
}
```

---

**Step 2: Create test data with old timestamp**

```bash
# Manually insert old data (requires DB access or test API)
curl -X POST https://api.company.com/v1/test/create-old-activity \
  -H "Authorization: Bearer test_token" \
  -d '{
    "user_id": 12345,
    "action": "page_view",
    "timestamp": "2022-01-01T00:00:00Z"
  }'
```

---

**Step 3: Wait for retention cleanup job (or trigger manually)**

```bash
# Trigger cleanup (if API exists)
curl -X POST https://api.company.com/v1/admin/cleanup/retention \
  -H "Authorization: Bearer admin_token"

# Or wait for scheduled job (check cron)
```

---

**Step 4: Verify old data deleted**

```bash
curl "https://api.company.com/v1/activity?user_id=12345&date=2022-01-01" \
  -H "Authorization: Bearer user_token"
```

**Sebezhető result:**
```json
{
  "activities": [
    {"action": "page_view", "timestamp": "2022-01-01T00:00:00Z"}
  ]
}
```
→ **CRITICAL:** Data from 2022 still exists (exceeds 1-year retention policy)!

**Helyes result:**
```json
{
  "activities": []
}
```

---

### 6. User Data Export (GDPR Article 15)

**Cél:** User le tudja-e kérni az összes tárolt adatát?

**Payload:**

```bash
curl -X POST https://api.company.com/v1/data-export \
  -H "Authorization: Bearer user_token" \
  -d '{"format": "json"}'
```

**Expected response:**
```json
{
  "export_id": "exp_abc123",
  "status": "processing",
  "estimated_completion": "2024-01-30T11:00:00Z"
}
```

---

**Check export status:**

```bash
curl https://api.company.com/v1/data-export/exp_abc123 \
  -H "Authorization: Bearer user_token"
```

**Sebezhető result:** HTTP 404 (export functionality not implemented)

**Helyes result:**
```json
{
  "export_id": "exp_abc123",
  "status": "completed",
  "download_url": "https://exports.company.com/exp_abc123.json",
  "expires_at": "2024-02-06T11:00:00Z"
}
```

---

**Download and verify completeness:**

```bash
curl https://exports.company.com/exp_abc123.json
```

**Sebezhető export (incomplete):**
```json
{
  "email": "user@example.com",
  "name": "John Doe"
  // Missing: activity logs, consent records, support tickets
}
```

**Helyes export (comprehensive):**
```json
{
  "profile": {
    "email": "user@example.com",
    "name": "John Doe",
    "created_at": "2020-01-01T00:00:00Z"
  },
  "activity_logs": [...],
  "consent_records": [...],
  "support_tickets": [...],
  "payment_history": [...]
}
```

---

### 7. User Data Deletion (GDPR Article 17 - Right to be Forgotten)

**Cél:** User törölheti-e az adatait?

**Payload:**

```bash
curl -X DELETE https://api.company.com/v1/user/account \
  -H "Authorization: Bearer user_token" \
  -d '{"confirmation": "DELETE_MY_DATA"}'
```

**Expected response:**
```json
{
  "message": "Account deletion initiated",
  "deletion_id": "del_xyz789",
  "completion_time": "2024-01-30T12:00:00Z"
}
```

---

**Verify deletion (after completion time):**

```bash
# Try to access deleted user
curl https://api.company.com/v1/user/12345 \
  -H "Authorization: Bearer admin_token"
```

**Sebezhető result:** HTTP 200 (user data still accessible)

**Helyes result:**
```
HTTP/1.1 404 Not Found

{
  "error": "User not found"
}
```

---

**Verify in database (if you have access):**

```sql
SELECT * FROM users WHERE id = 12345;
-- Expected: 0 rows

SELECT * FROM activity_logs WHERE user_id = 12345;
-- Expected: 0 rows (or anonymized: user_id = NULL)
```

---

### 8. Consent Audit Trail Test

**Cél:** Consent changes logged és auditálhatók?

**Payload:**

```bash
# Request consent history
curl https://api.company.com/v1/consent/history \
  -H "Authorization: Bearer user_token"
```

**Sebezhető result:** HTTP 404 (audit trail not available)

**Helyes result:**
```json
{
  "consent_history": [
    {
      "consent_type": "marketing_emails",
      "granted": true,
      "timestamp": "2023-01-01T10:00:00Z",
      "ip_address": "192.168.1.1",
      "user_agent": "Mozilla/5.0..."
    },
    {
      "consent_type": "marketing_emails",
      "granted": false,
      "timestamp": "2024-01-30T15:00:00Z",
      "ip_address": "192.168.1.1",
      "user_agent": "Mozilla/5.0..."
    }
  ]
}
```

---

### 9. Purpose Limitation Test

**Cél:** Data csak a stated purpose-ra használódik-e?

**Scenario:** User gives consent for "order notifications" only.

**Payload: Marketing email attempt**

```bash
# Backend tries to send marketing email
curl -X POST https://api.company.com/v1/internal/send-email \
  -H "Authorization: Bearer backend_token" \
  -d '{
    "to": "user@example.com",
    "type": "marketing",
    "subject": "Special offer just for you!"
  }'
```

**Sebezhető behavior:** Email sent successfully

**Helyes behavior:**
```json
HTTP/1.1 403 Forbidden

{
  "error": "Consent violation",
  "message": "User only consented to 'order_notifications', not 'marketing'"
}
```

---

### 10. Data Portability Format Test

**Cél:** Exported data standard, machine-readable format-ban van-e?

**Payload:**

```bash
curl https://api.company.com/v1/data-export/exp_abc123
```

**Sebezhető format:** Proprietary/non-standard format (e.g., custom binary)

**Helyes formats:**
- JSON (preferred)
- CSV
- XML

**Verification:** File should be parseable by standard tools (jq, csvkit, etc.)

---

### 11. Third-Party Sharing Consent

**Cél:** Data csak consent-tel megosztható third-party-vel?

**Payload: Trigger third-party integration**

```bash
# User hasn't consented to "third_party_analytics"
curl -X POST https://api.company.com/v1/actions/analyze-behavior \
  -H "Authorization: Bearer user_token"
```

**Sebezhető behavior:** Data sent to third-party analytics service

**Check backend logs:**
```
2024-01-30 10:00:00 INFO Sending data to analytics.thirdparty.com: {user_id: 12345, behavior: [...]}
```
→ **CRITICAL:** Data shared without consent!

**Helyes behavior:**
```json
HTTP/1.1 403 Forbidden

{
  "error": "Third-party consent required",
  "message": "This feature requires consent for 'third_party_analytics'"
}
```

---

## Vulnerabilitás Azonosítása

System **violates data minimization/consent**, ha:

**Data Minimization:**
- ✅ Accepts & stores unnecessary data fields (SSN for newsletter signup)
- ✅ No schema validation (arbitrary fields accepted)
- ✅ Excessive data in API responses (internal fields exposed)

**Consent:**
- ✅ Continues processing after consent withdrawal
- ✅ No consent status check before processing
- ✅ No consent audit trail (can't prove compliance)
- ✅ Data shared with third parties without explicit consent

**Data Retention:**
- ✅ Retains data beyond stated retention period
- ✅ No automated deletion process
- ✅ User cannot delete their data (GDPR violation)

**User Rights:**
- ✅ User cannot export their data (Article 15 violation)
- ✅ User cannot delete their account (Article 17 violation)
- ✅ Exported data incomplete or in proprietary format

---

## Védekezési Javaslatok

### 1. Strict Schema Validation

**Backend enforcement:**
```python
from jsonschema import validate, ValidationError

user_schema = {
    "type": "object",
    "properties": {
        "email": {"type": "string", "format": "email"},
        "password": {"type": "string", "minLength": 8},
        "name": {"type": "string"}
    },
    "required": ["email", "password"],
    "additionalProperties": False  # Reject extra fields
}

def register_user(request_data):
    try:
        validate(instance=request_data, schema=user_schema)
    except ValidationError as e:
        return {"error": str(e)}, 400
    
    # Process only validated fields
    user = create_user(request_data)
    return {"user_id": user.id}, 201
```

---

### 2. Consent Management Platform (CMP)

**Centralized consent tracking:**
```python
class ConsentManager:
    def check_consent(self, user_id, purpose):
        consent = db.query(
            "SELECT granted FROM consents WHERE user_id = ? AND purpose = ?",
            [user_id, purpose]
        ).first()
        return consent and consent.granted
    
    def grant_consent(self, user_id, purpose):
        db.execute(
            "INSERT INTO consents (user_id, purpose, granted, timestamp) VALUES (?, ?, true, NOW())",
            [user_id, purpose]
        )
    
    def withdraw_consent(self, user_id, purpose):
        db.execute(
            "UPDATE consents SET granted = false, withdrawn_at = NOW() WHERE user_id = ? AND purpose = ?",
            [user_id, purpose]
        )

# Before processing
if not ConsentManager().check_consent(user_id, 'marketing_emails'):
    raise PermissionError("Consent required")
```

---

### 3. Automated Data Retention

**Scheduled cleanup job:**
```python
from datetime import datetime, timedelta

def cleanup_expired_data():
    retention_policies = {
        'activity_logs': timedelta(days=90),
        'user_sessions': timedelta(days=30),
        'support_tickets': timedelta(days=365*3),
    }
    
    for table, retention_period in retention_policies.items():
        cutoff_date = datetime.now() - retention_period
        
        deleted_count = db.execute(
            f"DELETE FROM {table} WHERE created_at < ?",
            [cutoff_date]
        ).rowcount
        
        logger.info(f"Deleted {deleted_count} expired records from {table}")

# Cron: Run daily at 2 AM
# 0 2 * * * python cleanup_expired_data.py
```

---

### 4. User Data Export API

**GDPR-compliant export:**
```python
@app.route('/v1/data-export', methods=['POST'])
def create_export():
    user_id = get_current_user_id()
    
    export_data = {
        'profile': get_user_profile(user_id),
        'activity_logs': get_activity_logs(user_id),
        'consents': get_consent_history(user_id),
        'support_tickets': get_support_tickets(user_id),
    }
    
    export_file = create_json_file(export_data)
    return {
        'download_url': upload_to_secure_storage(export_file),
        'expires_in': '7 days'
    }
```

---

### 5. User Privacy Dashboard

**UI for transparency:**
```html
<div class="privacy-dashboard">
  <h2>Your Data & Privacy</h2>
  
  <section>
    <h3>Data We Store</h3>
    <ul>
      <li>Profile: Email, Name, Phone</li>
      <li>Activity Logs: Last 90 days (auto-deleted after)</li>
      <li>Consents: [View History]</li>
    </ul>
  </section>
  
  <section>
    <h3>Your Rights</h3>
    <button onclick="exportData()">Download My Data</button>
    <button onclick="deleteAccount()">Delete My Account</button>
  </section>
  
  <section>
    <h3>Consent Management</h3>
    <label>
      <input type="checkbox" id="marketing" checked>
      Marketing Emails
    </label>
    <label>
      <input type="checkbox" id="analytics">
      Analytics & Personalization
    </label>
  </section>
</div>
```

---

## Hasznos Toolok

**Consent Management:**
- **OneTrust** - Enterprise CMP platform
- **Cookiebot** - Cookie consent management
- **TrustArc** - Privacy & compliance automation

**Data Privacy:**
- **Google Cloud DLP** - PII detection & de-identification
- **AWS Macie** - Sensitive data discovery
- **Microsoft Priva** - Privacy management

**Compliance Testing:**
- **GDPR Compliance Checker** - Automated compliance testing
- **Privacy Tools Project** (Harvard) - Data minimization auditing

---

## Teszt Checklist

**Data Minimization:**
- [ ] Excessive field injection test
- [ ] Schema validation test
- [ ] API response over-exposure check

**Consent:**
- [ ] Consent withdrawal → processing stops
- [ ] Consent status checked before every operation
- [ ] Consent audit trail available
- [ ] Third-party sharing requires explicit consent

**Data Retention:**
- [ ] Retention policy documented
- [ ] Automated cleanup job exists
- [ ] Old data actually deleted (verify in DB)

**User Rights:**
- [ ] User can export data (Article 15)
- [ ] User can delete account (Article 17)
- [ ] Export format is standard (JSON/CSV)
- [ ] Export is comprehensive (all data types)

---

## Referenciák

- GDPR Text - [https://gdpr-info.eu/](https://gdpr-info.eu/)
  - Article 5(1)(c) - Data minimization
  - Article 15 - Right of access
  - Article 17 - Right to erasure
- CCPA Full Text - [https://oag.ca.gov/privacy/ccpa](https://oag.ca.gov/privacy/ccpa)
- OWASP AI Exchange - Privacy - [https://owaspai.org/docs/6_privacy/](https://owaspai.org/docs/6_privacy/)
- NIST Privacy Framework - [https://www.nist.gov/privacy-framework](https://www.nist.gov/privacy-framework)
