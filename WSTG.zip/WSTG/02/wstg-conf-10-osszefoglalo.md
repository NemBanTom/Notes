# WSTG-CONF-10: Subdomain Takeover Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy **subdomain-ek** amik **external service-ekre mutatnak** (GitHub Pages, AWS, Azure, stb.), de a **service már nem aktív**, **átvétel**re (takeover) alkalmasak. Az **attacker claim-elheti** a subdomain-t és **full control**-t kap felette → **phishing**, **malicious content**, **cookie stealing**.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM DNS zone transfer vagy DNS spoofing! Ez **subdomain takeover** - amikor DNS record létezik, de a target service **már nem létezik vagy nem claimed**.

---

## Mi a cél?

**Subdomain takeover vulnerability** azonosítása:
- Dead subdomain-ek (pointing to non-existent services)
- Expired domain CNAME-ek
- Unclaimed cloud resources (GitHub Pages, S3, Azure)

---

## Vulnerability Conditions

### 2 Feltétel kell:

**1. DNS Record létezik, de target nem aktív:**
```
subdomain.victim.com → github-username.github.io
                        └─ Not claimed!
```

**2. Service Provider NEM ellenőrzi ownership-et:**
```
Attacker → Claims "github-username" on GitHub
Attacker → Now owns subdomain.victim.com!
```

---

## Attack Scenarios

### Scenario #1: GitHub Pages Takeover

**Setup:**
```
1. victim.com uses GitHub for code repo
2. DNS record: coderepo.victim.com → CNAME → oldrepo.github.io
3. Victim migrates to GitLab
4. Victim forgets to remove DNS record
```

**Attack:**
```
1. Attacker discovers: coderepo.victim.com → oldrepo.github.io
2. Attacker creates GitHub account "oldrepo"
3. Attacker creates GitHub Pages site
4. Attacker owns coderepo.victim.com!
```

**Impact:**
- Phishing site on victim's domain
- Steal cookies (same domain!)
- Malicious downloads
- Reputation damage

---

### Scenario #2: Expired Domain

**Setup:**
```
1. victim.com owns victimotherdomain.com
2. DNS: www.victim.com → CNAME → victimotherdomain.com
3. victimotherdomain.com expires
4. Victim forgets to remove CNAME
```

**Attack:**
```
1. Attacker registers victimotherdomain.com
2. Attacker now controls www.victim.com!
```

**Impact:**
- Full control over www subdomain
- Critical if www is main site!

---

### Scenario #3: AWS S3 Bucket

**Setup:**
```
1. victim.com: assets.victim.com → CNAME → mybucket.s3.amazonaws.com
2. Victim deletes S3 bucket "mybucket"
3. Victim forgets DNS record
```

**Attack:**
```
1. Attacker creates S3 bucket "mybucket"
2. Attacker serves malicious content
3. assets.victim.com → attacker's content!
```

---

### Scenario #4: Azure Web App

**Setup:**
```
1. app.victim.com → CNAME → myapp.azurewebsites.net
2. Victim deletes Azure Web App
3. DNS record remains
```

**Attack:**
```
1. Attacker creates Azure Web App "myapp"
2. Attacker controls app.victim.com
```

---

## DNS Record Types Vulnerable

| Record Type | Risk | Example |
|-------------|------|---------|
| `A` | Medium | Points to deleted cloud instance IP |
| `CNAME` | **HIGH** | Points to unclaimed service |
| `MX` | Medium | Email subdomain takeover |
| `NS` | **CRITICAL** | Full DNS zone control! |
| `TXT` | Low | Generally safe |

---

## Tesztelési Módszerek

### 1. **Subdomain Enumeration**
### 2. **DNS Record Inspection**
### 3. **Service Verification**
### 4. **Takeover Attempt (Proof of Concept)**

---

## 1. Subdomain Enumeration

### Tool #1: **Sublist3r**

#### Parancsok:
```bash
# Install
git clone https://github.com/aboul3la/Sublist3r
cd Sublist3r
pip install -r requirements.txt

# Enumerate subdomains
python sublist3r.py -d victim.com

# Save results
python sublist3r.py -d victim.com -o subdomains.txt
```

**Output:**
```
[-] Enumerating subdomains for victim.com
[+] www.victim.com
[+] blog.victim.com
[+] dev.victim.com
[+] old-site.victim.com
[+] assets.victim.com
```

---

### Tool #2: **Amass**

#### Parancsok:
```bash
# Install (Go required)
go install -v github.com/OWASP/Amass/v3/...@master

# Enumerate
amass enum -d victim.com

# Passive mode (no DNS queries)
amass enum -passive -d victim.com

# Output to file
amass enum -d victim.com -o amass_results.txt
```

---

### Tool #3: **theHarvester**

#### Parancsok:
```bash
# Install
git clone https://github.com/laramies/theHarvester
cd theHarvester
pip3 install -r requirements.txt

# Enumerate
python3 theHarvester.py -d victim.com -b all

# Specific sources
python3 theHarvester.py -d victim.com -b google,bing,baidu
```

---

## 2. DNS Record Inspection

### Tool #1: **dig**

#### Parancsok:
```bash
# Check CNAME record
dig CNAME old-site.victim.com

# Check A record
dig A assets.victim.com

# Check NS record
dig NS victim.com

# Check all records
dig ANY victim.com
```

---

**CNAME Example:**
```bash
dig CNAME old-site.victim.com
```

**Output:**
```
;; ANSWER SECTION:
old-site.victim.com.  300  IN  CNAME  oldproject.github.io.
```

**Next step:** Check if `oldproject.github.io` exists!

---

**DNS Response Codes to Investigate:**

| Code | Meaning | Action |
|------|---------|--------|
| `NXDOMAIN` | Non-existent domain | **Investigate!** |
| `SERVFAIL` | Server failure | **Check NS records** |
| `REFUSED` | Query refused | **Check nameserver** |
| `NOERROR` | Success | Verify target active |

---

### Tool #2: **dnsrecon**

#### Parancsok:
```bash
# Install
git clone https://github.com/darkoperator/dnsrecon
cd dnsrecon
pip3 install -r requirements.txt

# Enumerate
python3 dnsrecon.py -d victim.com

# Brute force subdomains
python3 dnsrecon.py -d victim.com -D subdomains.txt -t brt
```

**Output:**
```
[*]      CNAME old-site.victim.com oldproject.github.io
[*]      A assets.victim.com 52.85.123.45
```

---

## 3. Service Verification

### GitHub Pages:

**Check subdomain:**
```bash
curl https://old-site.victim.com
```

**If vulnerable:**
```
HTTP/1.1 404 Not Found
Server: GitHub.com

404 - There isn't a GitHub Pages site here.
```

→ **VULNERABLE!** GitHub Pages not claimed!

---

**Or in browser:**
```
https://old-site.victim.com
→ GitHub 404 page
→ "There isn't a GitHub Pages site here"
```

---

### AWS S3:

**Check subdomain:**
```bash
curl https://assets.victim.com
```

**If vulnerable:**
```xml
<Error>
  <Code>NoSuchBucket</Code>
  <Message>The specified bucket does not exist</Message>
</Error>
```

→ **VULNERABLE!** S3 bucket doesn't exist!

---

### Azure:

**Check subdomain:**
```bash
curl https://app.victim.com
```

**If vulnerable:**
```
404 - Web app not found.
The web app you have attempted to reach is not here.
```

→ **VULNERABLE!** Azure app not claimed!

---

### Heroku:

**Check:**
```bash
curl https://app.victim.com
```

**If vulnerable:**
```
No such app
There is no app configured at that hostname.
```

---

### whois Check (for IP):

```bash
# Get IP
dig A assets.victim.com +short
# → 52.85.123.45

# Check ownership
whois 52.85.123.45 | grep "OrgName"
# → OrgName: Amazon.com, Inc.
```

→ Points to AWS, but is service active?

---

## 4. Takeover Attempt (PoC)

### GitHub Pages Takeover:

**Steps:**
```
1. Find vulnerable subdomain:
   old-site.victim.com → oldproject.github.io (404)

2. Create GitHub account: "oldproject"

3. Create repository: "oldproject.github.io"

4. Enable GitHub Pages:
   Settings → Pages → Enable

5. Add custom domain:
   Settings → Pages → Custom domain: old-site.victim.com

6. Verify:
   curl https://old-site.victim.com
   → Your content!
```

---

### AWS S3 Bucket Takeover:

**Steps:**
```
1. Find vulnerable subdomain:
   assets.victim.com → mybucket.s3.amazonaws.com (NoSuchBucket)

2. Create S3 bucket: "mybucket"
   aws s3 mb s3://mybucket

3. Configure static website:
   aws s3 website s3://mybucket --index-document index.html

4. Upload index.html:
   echo "Claimed by [Your Name]" > index.html
   aws s3 cp index.html s3://mybucket/

5. Verify:
   curl http://assets.victim.com
   → Your content!
```

---

### Azure Web App Takeover:

**Steps:**
```
1. Find vulnerable: app.victim.com → myapp.azurewebsites.net

2. Create Azure Web App: "myapp"

3. Deploy content

4. Verify takeover
```

---

## NS Record Takeover (CRITICAL!)

### Concept:
**NS record takeover** = **full DNS zone control**!

### Detection:

```bash
# Check NS records
dig NS victim.com +short
```

**Output:**
```
ns1.victim.com
ns2.expired-nameserver.com    ← VULNERABLE!
```

**Check if expired:**
```bash
whois expired-nameserver.com
```

**If available for registration:**
→ **CRITICAL VULNERABILITY!**

---

**Attack:**
```
1. Register expired-nameserver.com
2. Configure as nameserver
3. Control victim.com DNS zone!
4. Can:
   - Redirect all subdomains
   - Intercept emails (MX records)
   - Full domain compromise
```

---

## Automated Scanners

### Tool: **can-i-take-over-xyz**

**Resource:**
- https://github.com/EdOverflow/can-i-take-over-xyz

**Services Covered:**
- GitHub Pages
- AWS S3
- Azure
- Heroku
- Shopify
- Tumblr
- WordPress.com
- And many more...

**Usage:**
```
Check fingerprints for each service
Manual verification needed
```

---

### Tool: **SubOver**

```bash
# Install
go get github.com/Ice3man543/SubOver

# Usage
SubOver -l subdomains.txt
```

**What it does:**
- Checks for common takeover patterns
- Identifies vulnerable services
- Reports potential takeovers

---

## Vulnerable Service Fingerprints

### GitHub Pages:
```
Response: 404 Not Found
Body: "There isn't a GitHub Pages site here"
```

### AWS S3:
```
Response: 404 Not Found
Body: "<Code>NoSuchBucket</Code>"
```

### Azure:
```
Response: 404 Not Found
Body: "404 - Web app not found"
```

### Heroku:
```
Response: 503 Service Unavailable
Body: "No such app"
```

### Shopify:
```
Response: 404 Not Found
Body: "Sorry, this shop is currently unavailable"
```

### Bitbucket:
```
Response: 404 Not Found
Body: "Repository not found"
```

---

## Testing Workflow

### 1. Subdomain Discovery:
```bash
# Enumerate subdomains
amass enum -d victim.com -o subdomains.txt
```

---

### 2. DNS Record Check:
```bash
# Check each subdomain
while read subdomain; do
    echo "Checking: $subdomain"
    dig CNAME $subdomain +short
done < subdomains.txt
```

---

### 3. Service Verification:
```bash
# Check HTTP response
while read subdomain; do
    echo "Testing: $subdomain"
    curl -s https://$subdomain | grep -E "404|NoSuchBucket|not found"
done < subdomains.txt
```

---

### 4. Identify Provider:
```bash
# Check CNAME target
dig CNAME old-site.victim.com +short
# → oldproject.github.io (GitHub!)

# Or whois on A record IP
dig A assets.victim.com +short | xargs whois | grep OrgName
# → Amazon (AWS!)
```

---

### 5. Attempt Takeover (Ethical!):
```
Only if authorized!
Create PoC to demonstrate vulnerability
Report to victim
```

---

## Comprehensive Testing Script

```bash
#!/bin/bash

DOMAIN=$1
OUTPUT="takeover_results.txt"

echo "=== Subdomain Takeover Scanner ===" > $OUTPUT
echo "Target: $DOMAIN" >> $OUTPUT
echo "" >> $OUTPUT

# 1. Enumerate subdomains
echo "[*] Enumerating subdomains..." >> $OUTPUT
amass enum -passive -d $DOMAIN -o subs.txt

# 2. Check each subdomain
while read sub; do
    echo "" >> $OUTPUT
    echo "[+] Checking: $sub" >> $OUTPUT
    
    # Get CNAME
    cname=$(dig CNAME $sub +short)
    if [ ! -z "$cname" ]; then
        echo "  CNAME: $cname" >> $OUTPUT
        
        # Check if CNAME resolves
        ip=$(dig A $cname +short)
        if [ -z "$ip" ]; then
            echo "  [!] CNAME doesn't resolve - POTENTIAL VULNERABILITY" >> $OUTPUT
        fi
    fi
    
    # HTTP check
    response=$(curl -s -o /dev/null -w "%{http_code}" https://$sub)
    echo "  HTTP: $response" >> $OUTPUT
    
    if [ "$response" == "404" ]; then
        body=$(curl -s https://$sub)
        if echo "$body" | grep -q "GitHub Pages"; then
            echo "  [!] VULNERABLE - GitHub Pages takeover possible!" >> $OUTPUT
        elif echo "$body" | grep -q "NoSuchBucket"; then
            echo "  [!] VULNERABLE - AWS S3 takeover possible!" >> $OUTPUT
        fi
    fi
done < subs.txt

echo "" >> $OUTPUT
echo "[*] Scan complete. Check $OUTPUT for results." >> $OUTPUT
```

---

## Gyakorlati Cheat Sheet

| Parancs | Cél |
|---------|-----|
| `amass enum -d domain.com` | Subdomain enumeration |
| `dig CNAME subdomain.com` | Check CNAME record |
| `dig NS domain.com` | Check nameservers |
| `curl https://subdomain.com` | Check HTTP response |
| `whois IP` | Identify service provider |
| `python3 sublist3r.py -d domain.com` | Subdomain discovery |

---

## Fontos Toolok

### Enumeration:
- **Amass** - OWASP subdomain enum
- **Sublist3r** - Subdomain discovery
- **theHarvester** - OSINT gathering
- **dnsrecon** - DNS enumeration

### Verification:
- **dig** - DNS queries
- **curl** - HTTP testing
- **whois** - Domain/IP lookup

### Automated:
- **SubOver** - Subdomain takeover scanner
- **can-i-take-over-xyz** - Service fingerprints

---

## Védelem (Remediation)

### 1. **Remove Dead DNS Records:**
```bash
# Find CNAME pointing to deleted services
# Remove from DNS zone

# Example (Route53):
aws route53 change-resource-record-sets --hosted-zone-id Z123 \
  --change-batch '{"Changes":[{"Action":"DELETE","ResourceRecordSet":{...}}]}'
```

---

### 2. **Monitor Subdomains:**
```
- Regular subdomain scans
- Alert on new/changed DNS records
- Automated checks for takeover
```

---

### 3. **Before Deleting Services:**
```
1. Delete external service (GitHub Pages, S3, etc.)
2. THEN delete DNS record
3. Not the other way around!
```

---

### 4. **Use Monitoring Tools:**
- **OWASP Domain Protect** - AWS subdomain monitoring
- **Automated scanners** - Regular checks

---

### 5. **Document Subdomains:**
```
Maintain inventory:
- All subdomains
- What they point to
- Who owns them
- When created
```

---

## Fontos Megjegyzések

✅ **Subdomain takeover** = attacker claims victim's subdomain  
✅ **GitHub Pages** = most common vulnerable service  
✅ **NS record takeover** = CRITICAL (full DNS control!)  
✅ **NXDOMAIN response** = investigate further!  
✅ **Delete DNS BEFORE deleting service** = wrong order!  
❌ **Dead CNAME** = potential takeover!  
⚠️ **Expired domain CNAME** = high risk!  
⚠️ **404 on GitHub/AWS/Azure** = check if claimable!

---

**Összefoglalva:** Ez a fejezet a **subdomain takeover** sebezhetőségről szól. Ha egy **DNS record** (CNAME, A, NS) egy **non-existent vagy unclaimed service**-re mutat (GitHub Pages, AWS S3, Azure, Heroku), akkor **attacker claim-elheti** azt a service-t és **átveheti a subdomain control**-t. **Subdomain enumeration** (Amass, Sublist3r), **DNS record check** (dig), és **service verification** (curl, HTTP 404 check) szükséges. **GitHub Pages "There isn't a site here"**, **AWS S3 "NoSuchBucket"**, és **Azure "Web app not found"** fingerprint-ek jelzik a vulnerability-t. **NS record takeover** = **CRITICAL** (full DNS zone control!). **Remediation**: **remove dead DNS records** és **delete DNS AFTER deleting service**!
