# WSTG-CONF-11: Cloud Storage Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy **cloud storage service-ek** (AWS S3, Azure Blob, Google Cloud Storage) **misconfigured access control**-ja miatt **unauthorized user-ek** **read, write, vagy delete** műveleteket végezhetnek **sensitive data**-n. **Public S3 bucket** = **adatszivárgás**, **data tampering**, vagy **malware upload**.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános cloud security audit, hanem specifikusan **cloud storage permission testing** - S3/Azure/GCS bucket-ek access control-jának ellenőrzése.

---

## Mi a cél?

**Cloud storage access control** megfelelőségének ellenőrzése:
- Unauthorized read (data exposure)
- Unauthorized write (file upload)
- Unauthorized delete (data tampering)

---

## Veszélyek (Threats)

### 1. **Data Exposure:**

**Példa:**
```
Public S3 bucket:
https://mybucket.s3.amazonaws.com/confidential-data.xlsx

Anyone can download:
curl https://mybucket.s3.amazonaws.com/confidential-data.xlsx
→ Sensitive business data leaked!
```

---

### 2. **Unauthorized Upload:**

**Példa:**
```
Writable S3 bucket:
curl -X PUT https://mybucket.s3.amazonaws.com/malware.exe \
  --upload-file malware.exe

→ Malware hosted on victim's infrastructure!
```

---

### 3. **Data Tampering:**

**Példa:**
```
Deletable bucket:
aws s3 rm s3://mybucket/important-file.pdf

→ Critical data deleted!
```

---

### 4. **Subdomain Takeover via S3:**

**Concept:** Ha subdomain CNAME-je deleted S3 bucket-re mutat → takeover!

```
assets.victim.com → CNAME → mybucket.s3.amazonaws.com

If "mybucket" deleted:
  Attacker creates "mybucket"
  Attacker controls assets.victim.com!
```

---

## AWS S3 Bucket URL Formats

### 1. **Virtual Hosted Style:**

**Format:**
```
https://bucket-name.s3.Region.amazonaws.com/key-name
```

**Példa:**
```
https://my-bucket.s3.us-west-2.amazonaws.com/puppy.png
                 │         │              │
                 │         │              └─ Object key
                 │         └─ Region
                 └─ Bucket name
```

---

### 2. **Path-Style:**

**Format:**
```
https://s3.Region.amazonaws.com/bucket-name/key-name
```

**Példa:**
```
https://s3.us-west-2.amazonaws.com/my-bucket/puppy.png
           │                        │         │
           │                        │         └─ Object key
           │                        └─ Bucket name
           └─ Region
```

---

### 3. **Legacy Global Endpoint:**

**Virtual Hosted:**
```
https://bucket-name.s3.amazonaws.com
```

**Path-Style:**
```
https://s3.amazonaws.com/bucket-name
```

---

## Tesztelési Módszerek

### 1. **Bucket Discovery** (URL Finding)
### 2. **Read Test** (Unauthorized Download)
### 3. **Write Test** (Unauthorized Upload)
### 4. **Delete Test** (Unauthorized Removal)
### 5. **List Test** (Directory Listing)

---

## 1. Bucket Discovery

### Method #1: **HTML Source Review**

```bash
# Check HTML for S3 URLs
curl -s https://victim.com | grep -oE 'https://[^"]*\.s3[^"]*'
```

**Output példa:**
```
https://my-assets.s3.amazonaws.com/logo.png
https://backups.s3.us-west-2.amazonaws.com/data.zip
```

---

### Method #2: **JavaScript Files**

```bash
# Check JS files
curl -s https://victim.com/app.js | grep -oE 's3://[^"]*'
```

---

### Method #3: **Google Dorking**

```
# Find S3 buckets
site:s3.amazonaws.com victim

# Find Azure blobs
site:blob.core.windows.net victim

# Find GCS buckets
site:storage.googleapis.com victim
```

---

### Method #4: **Certificate Transparency**

```bash
# Find subdomains potentially pointing to S3
curl -s "https://crt.sh/?q=%.victim.com&output=json" | grep s3
```

---

### Method #5: **Common Naming Patterns**

**Try common bucket names:**
```
https://victim-backups.s3.amazonaws.com
https://victim-assets.s3.amazonaws.com
https://victim-uploads.s3.amazonaws.com
https://victim-logs.s3.amazonaws.com
https://victim-data.s3.amazonaws.com
https://company-name-prod.s3.amazonaws.com
```

---

## 2. Read Test (Unauthorized Download)

### Tool #1: **curl**

#### Parancsok:
```bash
# Download object
curl https://my-bucket.s3.amazonaws.com/file.txt

# Download with output
curl https://my-bucket.s3.amazonaws.com/file.txt -o downloaded.txt

# Check if accessible (HEAD request)
curl -I https://my-bucket.s3.amazonaws.com/file.txt
```

---

**Response Examples:**

**Accessible (200 OK):**
```bash
curl -I https://my-bucket.s3.amazonaws.com/sensitive.xlsx
```

```http
HTTP/1.1 200 OK
Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
Content-Length: 12345
```

→ **VULNERABLE!** File downloadable!

---

**Access Denied (403 Forbidden):**
```http
HTTP/1.1 403 Forbidden
Content-Type: application/xml
```

```xml
<Error>
  <Code>AccessDenied</Code>
  <Message>Access Denied</Message>
</Error>
```

→ Properly secured

---

### Tool #2: **AWS CLI**

#### Parancsok:
```bash
# List bucket contents
aws s3 ls s3://bucket-name

# List with path
aws s3 ls s3://bucket-name/folder/

# Recursive list
aws s3 ls s3://bucket-name --recursive

# Download file
aws s3 cp s3://bucket-name/file.txt ./
```

---

**Output Examples:**

**Public bucket (vulnerable):**
```bash
aws s3 ls s3://my-bucket
```

```
2024-01-18 10:00:00    1234 confidential.pdf
2024-01-17 15:30:00    5678 passwords.xlsx
2024-01-16 09:15:00    9012 backup.zip
```

→ **CRITICAL!** Anyone can list contents!

---

**Access Denied (secure):**
```bash
aws s3 ls s3://secure-bucket
```

```
An error occurred (AccessDenied) when calling the ListObjectsV2 operation: Access Denied
```

→ Properly secured

---

## 3. Write Test (Unauthorized Upload)

### Tool #1: **curl**

#### Parancsok:
```bash
# Upload file
curl -X PUT https://my-bucket.s3.amazonaws.com/test.txt \
  -d 'test content'

# Upload from file
curl -X PUT https://my-bucket.s3.amazonaws.com/test.txt \
  --upload-file test.txt

# Upload with data
curl -X PUT https://my-bucket.s3.amazonaws.com/proof.txt \
  -d 'Uploaded by security tester'
```

---

**Response Examples:**

**Upload Successful (vulnerable):**
```http
HTTP/1.1 200 OK
ETag: "abc123def456"
```

→ **CRITICAL!** Anyone can upload!

---

**Access Denied (secure):**
```http
HTTP/1.1 403 Forbidden
```

```xml
<Error>
  <Code>AccessDenied</Code>
  <Message>Access Denied</Message>
</Error>
```

→ Properly secured

---

### Tool #2: **AWS CLI**

#### Parancsok:
```bash
# Upload file
aws s3 cp test.txt s3://bucket-name/test.txt

# Upload directory
aws s3 cp ./folder s3://bucket-name/folder --recursive

# Upload with public-read ACL (if allowed)
aws s3 cp test.txt s3://bucket-name/test.txt --acl public-read
```

---

**Output Examples:**

**Success (vulnerable):**
```bash
aws s3 cp test.txt s3://my-bucket/test.txt
```

```
upload: ./test.txt to s3://my-bucket/test.txt
```

→ **VULNERABLE!**

---

**Denied (secure):**
```
upload failed: ./test.txt to s3://my-bucket/test.txt 
An error occurred (AccessDenied) when calling the PutObject operation: Access Denied
```

→ Secure

---

## 4. Delete Test (Unauthorized Removal)

### ⚠️ **FIGYELEM: DESTRUCTIVE TEST!**

```bash
# Create test file first
echo "test" > test-delete.txt
aws s3 cp test-delete.txt s3://bucket-name/test-delete.txt

# Try to delete
aws s3 rm s3://bucket-name/test-delete.txt
```

**Success (vulnerable):**
```
delete: s3://bucket-name/test-delete.txt
```

**Denied (secure):**
```
delete failed: s3://bucket-name/test-delete.txt 
An error occurred (AccessDenied) when calling the DeleteObject operation: Access Denied
```

---

## 5. List Test (Directory Listing)

### Browser Test:

**Navigate to:**
```
https://bucket-name.s3.amazonaws.com
```

---

**If bucket is public (vulnerable):**
```xml
<ListBucketResult>
  <Name>bucket-name</Name>
  <Contents>
    <Key>file1.txt</Key>
    <Size>1234</Size>
  </Contents>
  <Contents>
    <Key>confidential.pdf</Key>
    <Size>5678</Size>
  </Contents>
</ListBucketResult>
```

→ **CRITICAL!** Directory listing enabled!

---

**If secured:**
```xml
<Error>
  <Code>AccessDenied</Code>
  <Message>Access Denied</Message>
</Error>
```

---

## Azure Blob Storage

### URL Format:

```
https://storageaccount.blob.core.windows.net/container/blob
```

**Példa:**
```
https://mycompany.blob.core.windows.net/images/logo.png
```

---

### Testing:

#### Read Test:
```bash
curl https://mycompany.blob.core.windows.net/images/logo.png
```

---

#### List Test:
```bash
# List container
curl https://mycompany.blob.core.windows.net/container?restype=container&comp=list
```

---

**Public container (vulnerable):**
```xml
<EnumerationResults>
  <Blobs>
    <Blob>
      <Name>file1.txt</Name>
    </Blob>
  </Blobs>
</EnumerationResults>
```

---

## Google Cloud Storage (GCS)

### URL Format:

```
https://storage.googleapis.com/bucket-name/object-name
```

**Vagy:**
```
https://bucket-name.storage.googleapis.com/object-name
```

---

### Testing:

```bash
# Read test
curl https://storage.googleapis.com/my-bucket/file.txt

# List test
curl https://storage.googleapis.com/storage/v1/b/my-bucket/o
```

---

## Bucket Permission Checker Scripts

### AWS S3 Quick Test:

```bash
#!/bin/bash

BUCKET=$1

echo "[*] Testing S3 bucket: $BUCKET"

# Test read
echo "[+] Testing read access..."
aws s3 ls s3://$BUCKET 2>&1 | grep -q "AccessDenied"
if [ $? -eq 0 ]; then
    echo "  [-] Read: DENIED (secure)"
else
    echo "  [!] Read: ALLOWED (VULNERABLE!)"
fi

# Test write
echo "[+] Testing write access..."
echo "test" > /tmp/s3test.txt
aws s3 cp /tmp/s3test.txt s3://$BUCKET/s3test.txt 2>&1 | grep -q "upload:"
if [ $? -eq 0 ]; then
    echo "  [!] Write: ALLOWED (CRITICAL!)"
    # Cleanup
    aws s3 rm s3://$BUCKET/s3test.txt 2>/dev/null
else
    echo "  [-] Write: DENIED (secure)"
fi

rm /tmp/s3test.txt
```

**Használat:**
```bash
chmod +x s3test.sh
./s3test.sh my-bucket-name
```

---

## Common Misconfiguration Patterns

### 1. **Public Read (Most Common):**

**Bucket Policy:**
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::bucket-name/*"
  }]
}
```

→ Anyone can read all objects!

---

### 2. **Public Write (Critical):**

```json
{
  "Effect": "Allow",
  "Principal": "*",
  "Action": "s3:PutObject",
  "Resource": "arn:aws:s3:::bucket-name/*"
}
```

→ Anyone can upload files!

---

### 3. **Public List:**

```json
{
  "Effect": "Allow",
  "Principal": "*",
  "Action": "s3:ListBucket",
  "Resource": "arn:aws:s3:::bucket-name"
}
```

→ Anyone can list contents!

---

### 4. **Full Public Access (Worst Case):**

```json
{
  "Effect": "Allow",
  "Principal": "*",
  "Action": "s3:*",
  "Resource": [
    "arn:aws:s3:::bucket-name",
    "arn:aws:s3:::bucket-name/*"
  ]
}
```

→ **CRITICAL!** Anyone can do anything!

---

## Real-World Examples

### Example #1: **Capital One Breach (2019)**

**Vulnerability:**
- Misconfigured S3 bucket
- WAF role had excessive permissions
- Attacker accessed 100 million customer records

---

### Example #2: **Tesla AWS Breach**

**Vulnerability:**
- Public Kubernetes console
- AWS credentials in scripts
- S3 bucket with proprietary data accessible

---

### Example #3: **Dow Jones**

**Vulnerability:**
- 2.2 million customer records in public S3 bucket
- No authentication required
- Discovered by security researcher

---

## Gyakorlati Cheat Sheet

| Parancs | Cél |
|---------|-----|
| `curl URL` | Read test |
| `curl -X PUT URL -d 'test'` | Write test |
| `aws s3 ls s3://bucket` | List bucket |
| `aws s3 cp file s3://bucket/` | Upload test |
| `aws s3 rm s3://bucket/file` | Delete test |
| `curl -I URL` | Check accessibility |

---

## Fontos Toolok

### Manual Testing:
- **curl** - HTTP requests
- **AWS CLI** - S3 operations
- **Azure CLI** - Blob storage ops
- **gsutil** - Google Cloud Storage

### Automated:
- **S3Scanner** - S3 bucket scanner
- **bucketfinder** - Bucket discovery
- **AWSBucketDump** - Download buckets
- **CloudMapper** - AWS visualization

---

## Védelem (Remediation)

### 1. **Block Public Access (AWS):**

**AWS Console:**
```
S3 → Bucket → Permissions → Block Public Access
✓ Block all public access
```

**AWS CLI:**
```bash
aws s3api put-public-access-block \
  --bucket my-bucket \
  --public-access-block-configuration \
  "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
```

---

### 2. **Principle of Least Privilege:**

```json
{
  "Effect": "Allow",
  "Principal": {
    "AWS": "arn:aws:iam::123456789012:role/MyRole"
  },
  "Action": "s3:GetObject",
  "Resource": "arn:aws:s3:::bucket-name/specific-folder/*"
}
```

→ Only specific role, specific action, specific path

---

### 3. **Enable Logging:**

```bash
# Enable S3 access logging
aws s3api put-bucket-logging \
  --bucket my-bucket \
  --bucket-logging-status \
  file://logging.json
```

---

### 4. **Use Signed URLs:**

```python
# Generate pre-signed URL (expires)
import boto3

s3 = boto3.client('s3')
url = s3.generate_presigned_url(
    'get_object',
    Params={'Bucket': 'my-bucket', 'Key': 'file.txt'},
    ExpiresIn=3600  # 1 hour
)
```

---

### 5. **Regular Audits:**

```bash
# Check all buckets
aws s3api list-buckets --query 'Buckets[].Name' | \
  xargs -I {} aws s3api get-bucket-acl --bucket {}
```

---

## Fontos Megjegyzések

✅ **Public S3 bucket** = adatszivárgás, malware hosting  
✅ **Default S3 = private** (de easy to misconfigure!)  
✅ **Block Public Access** = best defense  
✅ **List permission** = directory enumeration  
✅ **Write permission** = malware upload  
❌ **`"Principal": "*"`** = EVERYONE has access!  
⚠️ **Capital One, Dow Jones** = real breaches from S3 misconfig!  
⚠️ **Subdomain takeover** via deleted S3 bucket!

---

**Összefoglalva:** Ez a fejezet a **cloud storage misconfiguration** teszteléséről szól. **AWS S3**, **Azure Blob**, és **Google Cloud Storage** bucket-ek **improper access control**-ja **unauthorized read** (data exposure), **write** (malware upload), vagy **delete** (data tampering) műveleteket tesz lehetővé. **curl** vagy **AWS CLI**-vel tesztelhető **read** (`curl URL`), **write** (`curl -X PUT`), **list** (`aws s3 ls`), és **delete** (`aws s3 rm`). **Public bucket** = `"Principal": "*"` policy → **CRITICAL vulnerability**! **Real-world breaches**: Capital One, Tesla, Dow Jones. **Remediation**: **Block Public Access**, **principle of least privilege**, **signed URLs**, és **regular audits**!
