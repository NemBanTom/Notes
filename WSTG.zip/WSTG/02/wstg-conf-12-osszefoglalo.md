# WSTG-CONF-12: Content Security Policy (CSP) Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **Content Security Policy (CSP)** egy **HTTP response header**, amely **meghatározza**, hogy honnan tölthetők be **resources** (JavaScript, CSS, images). **Weak vagy hiányzó CSP** **XSS** és **clickjacking** attackoknak teszi ki az alkalmazást. **`unsafe-inline`**, **`unsafe-eval`**, vagy **wildcard** (`*`) sources **CSP bypass**-t tesznek lehetővé.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM XSS vulnerability testing, hanem **CSP configuration review** - van-e CSP, és helyesen van-e beállítva a XSS és clickjacking ellen.

---

## Mi a cél?

**CSP header misconfiguration-jeinek azonosítása:**
- `unsafe-inline` (XSS vulnerability)
- `unsafe-eval` (bypass lehetőség)
- Wildcard sources (`*`)
- Weak `frame-ancestors` (clickjacking)
- Missing CSP

---

## CSP Concept

### Alapelv:
**Whitelist approach** - csak meghatározott source-okból lehet resource-okat tölteni.

**Példa:**
```
Content-Security-Policy: script-src 'self' https://trusted-cdn.com
```

**Jelentése:**
- JavaScript csak:
  - Saját domain-ről (`'self'`)
  - `https://trusted-cdn.com`-ról
- Más source-ból (pl. inline script, más domain) → **BLOCKED**

---

## CSP Directives

### Főbb Directive-ek:

| Directive | Mit szabályoz |
|-----------|---------------|
| `script-src` | JavaScript sources |
| `style-src` | CSS sources |
| `img-src` | Image sources |
| `font-src` | Font sources |
| `connect-src` | AJAX, WebSocket sources |
| `frame-src` | iframe sources |
| `frame-ancestors` | Where page can be framed |
| `object-src` | Plugin sources (Flash, etc.) |
| `base-uri` | `<base>` tag URLs |
| `default-src` | Fallback for other directives |

---

### Special Keywords:

| Keyword | Jelentés |
|---------|----------|
| `'self'` | Same origin |
| `'none'` | No sources allowed |
| `'unsafe-inline'` | Inline scripts/styles allowed |
| `'unsafe-eval'` | `eval()` allowed |
| `'unsafe-hashes'` | Inline event handlers allowed |
| `'strict-dynamic'` | Trust scripts dynamically loaded |
| `'nonce-<value>'` | Only scripts with matching nonce |

---

## Insecure CSP Configurations

### 1. **`unsafe-inline` (XSS Vulnerability)**

**Bad CSP:**
```
Content-Security-Policy: script-src 'self' 'unsafe-inline'
```

**Impact:**
```html
<!-- Inline script ALLOWED -->
<script>alert(document.cookie)</script>

<!-- Event handler ALLOWED -->
<img src=x onerror="alert(1)">
```

→ **CRITICAL!** CSP does NOT protect against XSS!

---

### 2. **`unsafe-eval` (Bypass)**

**Bad CSP:**
```
Content-Security-Policy: script-src 'self' 'unsafe-eval'
```

**Impact:**
```javascript
// eval() allowed
eval("alert(document.cookie)");

// Function constructor allowed
new Function("alert(1)")();

// setTimeout with string allowed
setTimeout("alert(1)", 0);
```

---

### 3. **Wildcard Source (`*`)**

**Bad CSP:**
```
Content-Security-Policy: script-src *
```

**Impact:**
```html
<!-- ANY domain allowed -->
<script src="https://evil.com/malicious.js"></script>
```

→ **NO PROTECTION!**

---

### 4. **Partial Wildcard**

**Bad CSP:**
```
Content-Security-Policy: script-src https://*
```

**Impact:**
```html
<!-- Any HTTPS domain allowed -->
<script src="https://attacker.com/xss.js"></script>
```

→ Still vulnerable!

---

### 5. **Weak `frame-ancestors` (Clickjacking)**

**Bad CSP:**
```
Content-Security-Policy: frame-ancestors *
```

**Impact:**
```html
<!-- Attacker site -->
<iframe src="https://victim.com"></iframe>
```

→ **Clickjacking possible!**

---

**Or missing:**
```
Content-Security-Policy: script-src 'self'
(no frame-ancestors directive)
```

→ **Clickjacking vulnerable!**

---

### 6. **JSONP Endpoint Bypass**

**CSP:**
```
Content-Security-Policy: script-src 'self' https://trusted-api.com
```

**If `trusted-api.com` has JSONP endpoint:**
```html
<script src="https://trusted-api.com/jsonp?callback=alert(document.cookie)"></script>
```

→ **CSP bypassed!** (via trusted domain)

---

### 7. **Missing CSP**

**No CSP header:**
```
(HTTP response without Content-Security-Policy)
```

→ **NO PROTECTION** against XSS, clickjacking!

---

## Tesztelési Módszerek

### Tool #1: **Browser DevTools**

#### Használat:
```
1. F12 → Network tab
2. Reload page
3. Click first request (document)
4. Headers → Response Headers
5. Look for: Content-Security-Policy
```

**Screenshot:**
```
Response Headers:
Content-Type: text/html
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'
X-Frame-Options: DENY
```

→ **BAD!** `unsafe-inline` present!

---

### Tool #2: **curl**

#### Parancsok:
```bash
# Check CSP header
curl -I https://pelda.hu | grep -i content-security-policy

# Verbose
curl -v https://pelda.hu 2>&1 | grep -i content-security-policy
```

**Good CSP:**
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-abc123'
```

**Bad CSP:**
```
Content-Security-Policy: script-src 'unsafe-inline'
```

**Missing CSP:**
```
(no Content-Security-Policy header)
```

---

### Tool #3: **Google CSP Evaluator**

**URL:** https://csp-evaluator.withgoogle.com/

#### Használat:
```
1. Go to CSP Evaluator
2. Paste CSP header value
3. Click "Evaluate"
4. Review findings
```

---

**Example Input:**
```
default-src 'self'; script-src 'self' 'unsafe-inline'
```

**Output:**
```
HIGH SEVERITY:
'unsafe-inline' allows the execution of unsafe in-page scripts 
and event handlers.

RECOMMENDATION:
Remove 'unsafe-inline' and use 'nonce-' or 'hash-' based approach
```

---

### Tool #4: **CSP Auditor (Burp Extension)**

#### Használat:
```
1. Install CSP Auditor in Burp Suite
2. Browse target site through Burp proxy
3. CSP Auditor → Issues tab
4. Review CSP findings
```

---

## CSP Analysis Examples

### Example #1: **Weak CSP**

**CSP:**
```
Content-Security-Policy: default-src *; script-src * 'unsafe-inline'
```

**Issues:**
- `default-src *` → All resources from anywhere
- `script-src *` → Scripts from any domain
- `'unsafe-inline'` → Inline scripts allowed

**Severity:** **CRITICAL** - No protection!

---

### Example #2: **Better, but still weak**

**CSP:**
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-eval'
```

**Issues:**
- `'unsafe-eval'` → `eval()` allowed (bypass possible)

**Severity:** **HIGH**

---

### Example #3: **Missing frame-ancestors**

**CSP:**
```
Content-Security-Policy: default-src 'self'; script-src 'self'
```

**Issues:**
- No `frame-ancestors` directive

**Severity:** **MEDIUM** - Clickjacking possible

---

### Example #4: **Good CSP (Nonce-based)**

**CSP:**
```
Content-Security-Policy: default-src 'self'; script-src 'nonce-r4nd0m123'; object-src 'none'; base-uri 'none'
```

**No issues!** ✓

---

### Example #5: **Strict CSP**

**CSP:**
```
Content-Security-Policy: script-src 'nonce-r4nd0m' 'strict-dynamic'; object-src 'none'; base-uri 'none'
```

**Benefits:**
- Nonce-based (very secure)
- `'strict-dynamic'` (dynamically loaded scripts inherit trust)
- `object-src 'none'` (no Flash, etc.)
- `base-uri 'none'` (no base tag injection)

**Rating:** **A+** ✓✓✓

---

## Strict CSP Configurations

### Google Recommended - Moderate Strict:

```
script-src 'nonce-r4nd0m' 'strict-dynamic';
object-src 'none';
base-uri 'none';
```

**How it works:**
```html
<!-- Server generates random nonce -->
<script nonce="r4nd0m123">
  // This script is allowed
  const lib = document.createElement('script');
  lib.src = 'https://cdn.com/library.js';
  document.head.appendChild(lib);
  // Dynamically loaded script is also trusted (strict-dynamic)
</script>

<!-- Inline script without nonce -->
<script>alert(1)</script>  <!-- BLOCKED! -->
```

---

### Locked Down Strict:

```
script-src 'nonce-r4nd0m';
object-src 'none';
base-uri 'none';
```

**Difference:**
- No `'strict-dynamic'`
- Even more restrictive
- Dynamically loaded scripts must have nonce too

---

## CSP Meta Tag (Alternative)

**Instead of HTTP header:**
```html
<meta http-equiv="Content-Security-Policy" 
      content="default-src 'self'; script-src 'self' 'nonce-abc123'">
```

**Limitations:**
- Cannot use `frame-ancestors` in meta tag
- Less flexible than header
- Can be removed by XSS (if before execution)

---

## CSP Bypass Techniques (For Testing)

### 1. **JSONP Endpoints:**

**CSP:**
```
script-src https://trusted-api.com
```

**Bypass:**
```html
<script src="https://trusted-api.com/jsonp?callback=alert(document.cookie)"></script>
```

---

### 2. **AngularJS CDN:**

**CSP:**
```
script-src https://ajax.googleapis.com
```

**Bypass:**
```html
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.0/angular.min.js"></script>
<div ng-app ng-csp>
  {{constructor.constructor('alert(1)')()}}
</div>
```

---

### 3. **Base Tag Injection (if `base-uri` missing):**

**CSP:**
```
script-src 'self'
(no base-uri directive)
```

**Attack:**
```html
<base href="https://attacker.com/">
<script src="/evil.js"></script>
<!-- Loads from https://attacker.com/evil.js -->
```

---

## Testing Workflow

### 1. **Check CSP Presence:**
```bash
curl -I https://pelda.hu | grep -i content-security-policy
```

**Present?** → Continue analysis  
**Missing?** → **CRITICAL** - No CSP protection!

---

### 2. **Extract CSP Value:**
```bash
curl -I https://pelda.hu | grep -i content-security-policy | cut -d':' -f2-
```

---

### 3. **Evaluate with Google CSP Evaluator:**
```
https://csp-evaluator.withgoogle.com/
Paste CSP
Review findings
```

---

### 4. **Check for Specific Issues:**

```bash
CSP=$(curl -I https://pelda.hu | grep -i content-security-policy)

# Check unsafe-inline
echo $CSP | grep -i 'unsafe-inline' && echo "WARNING: unsafe-inline found!"

# Check unsafe-eval
echo $CSP | grep -i 'unsafe-eval' && echo "WARNING: unsafe-eval found!"

# Check wildcard
echo $CSP | grep -E "script-src.*\*" && echo "WARNING: wildcard source!"

# Check frame-ancestors
echo $CSP | grep -i 'frame-ancestors' || echo "WARNING: Missing frame-ancestors!"
```

---

### 5. **Test XSS with CSP:**

**If CSP has `unsafe-inline`:**
```html
<!-- This should work (BAD!) -->
<script>alert(1)</script>
```

**If proper CSP (no unsafe-inline):**
```html
<!-- This should be BLOCKED (GOOD!) -->
<script>alert(1)</script>
```

**Check browser console:**
```
Refused to execute inline script because it violates the following 
Content Security Policy directive: "script-src 'self'".
```

→ CSP working!

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs/Tool |
|-------|--------------|
| CSP check | `curl -I URL \| grep content-security-policy` |
| CSP evaluation | Google CSP Evaluator |
| unsafe-inline check | `grep 'unsafe-inline'` |
| wildcard check | `grep 'script-src.*\*'` |
| frame-ancestors | `grep frame-ancestors` |
| Browser test | F12 → Network → Headers |

---

## Fontos Toolok

### Online:
- **Google CSP Evaluator** - Best CSP analyzer
- **CSP Validator** - Alternative validator
- **CSP Generator** - Chrome/Firefox extension

### Burp Suite:
- **CSP Auditor** - Automated CSP checking

### Manual:
- **curl** - HTTP headers
- **Browser DevTools** - Real-time CSP

---

## Védelem (Remediation)

### 1. **Implement Strict CSP (Nonce-based):**

**Backend (Node.js example):**
```javascript
const crypto = require('crypto');

app.use((req, res, next) => {
    // Generate random nonce
    const nonce = crypto.randomBytes(16).toString('base64');
    res.locals.nonce = nonce;
    
    // Set CSP header
    res.setHeader(
        'Content-Security-Policy',
        `script-src 'nonce-${nonce}' 'strict-dynamic'; ` +
        `object-src 'none'; ` +
        `base-uri 'none';`
    );
    
    next();
});
```

---

**Frontend (template):**
```html
<!-- Use nonce in scripts -->
<script nonce="<%= nonce %>">
    // Your code here
</script>
```

---

### 2. **Remove `unsafe-inline` and `unsafe-eval`:**

**BAD:**
```
script-src 'self' 'unsafe-inline' 'unsafe-eval'
```

**GOOD:**
```
script-src 'self' 'nonce-abc123'
```

---

### 3. **Specify `frame-ancestors`:**

```
frame-ancestors 'self'
```

**Or completely block framing:**
```
frame-ancestors 'none'
```

---

### 4. **Set `base-uri`:**

```
base-uri 'self'
```

**Or:**
```
base-uri 'none'
```

---

### 5. **Use `object-src 'none'`:**

```
object-src 'none'
```

→ Blocks Flash, Java applets, etc.

---

### 6. **Report-Only Mode (Testing):**

```
Content-Security-Policy-Report-Only: default-src 'self'; script-src 'self'; report-uri /csp-report
```

**Benefits:**
- Doesn't block anything
- Reports violations
- Safe for production testing

---

## CSP Strength Ratings

### F (Fail) - No CSP:
```
(missing Content-Security-Policy header)
```

---

### D - Very Weak:
```
script-src *
```

---

### C - Weak:
```
script-src 'self' 'unsafe-inline'
```

---

### B - Moderate:
```
script-src 'self' 'unsafe-eval' https://trusted-cdn.com
```

---

### A - Good:
```
default-src 'self'; script-src 'self' https://trusted-cdn.com; object-src 'none'; base-uri 'none'
```

---

### A+ - Strict (Best):
```
script-src 'nonce-r4nd0m' 'strict-dynamic'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'
```

---

## Fontos Megjegyzések

✅ **CSP** = defense in depth против XSS  
✅ **Nonce-based CSP** = legbiztonságosabb  
✅ **`unsafe-inline`** = CRITICAL vulnerability!  
✅ **`unsafe-eval`** = bypass lehetőség  
✅ **Wildcard `*`** = no protection  
✅ **Missing `frame-ancestors`** = clickjacking risk  
❌ **Meta tag** = cannot set frame-ancestors!  
⚠️ **JSONP endpoints** = CSP bypass vector!  
⚠️ **Report-Only mode** = safe for testing  

---

**Összefoglalva:** Ez a fejezet a **Content Security Policy (CSP)** teszteléséről szól. **CSP** egy **HTTP header**, amely **whitelist-based approach**-sal meghatározza, honnan tölthetők be **resources**. **`unsafe-inline`** lehetővé teszi **inline script**-eket → **XSS vulnerable**! **`unsafe-eval`** lehetővé teszi **`eval()`**-t → **bypass**. **Wildcard `*`** vagy **partial wildcard** (`https://*`) = **no protection**. **Missing `frame-ancestors`** = **clickjacking vulnerable**. **Strict CSP** = **nonce-based** approach: `script-src 'nonce-random' 'strict-dynamic'; object-src 'none'; base-uri 'none'`. **Google CSP Evaluator** a legjobb analyzer tool. **Report-Only mode** safe testing-re production-ban!
