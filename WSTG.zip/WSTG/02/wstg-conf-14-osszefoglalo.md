# WSTG-CONF-14: Egyéb HTTP Security Header Misconfiguration-ök Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **security header-ek** (X-Frame-Options, Referrer-Policy, CORS, stb.) **helytelen konfigurációja** vagy **hiánya** különböző **attack-oknak** teszi ki az alkalmazást (XSS, clickjacking, CORS bypass, information leak). **Empty value**, **typo**, **overpermissive directive**, **duplicate header**, vagy **deprecated header** mind **weakening** a védelmet.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM CSP vagy HSTS testing (azok külön fejezetek)! Ez az **összes többi security header** (X-Frame-Options, Referrer-Policy, CORS, Permissions-Policy, stb.) misconfiguration-jeinek tesztelése.

---

## Mi a cél?

**Security header misconfiguration-ök azonosítása:**
- Empty vagy invalid value
- Typo-k (elírások)
- Overpermissive directives (`*`)
- Duplicate headers (konfliktusok)
- Deprecated headers (HPKP)
- Improper placement (HSTS over HTTP)
- META tag conflicts

---

## Common Security Headers

### HTTP Security Headers Overview:

| Header | Cél | Default (hiányában) |
|--------|-----|---------------------|
| `X-Frame-Options` | Clickjacking védelem | Vulnerable |
| `X-Content-Type-Options` | MIME sniffing védelem | Vulnerable |
| `Referrer-Policy` | Referrer control | Full URL leaked |
| `Permissions-Policy` | Feature control | All enabled |
| `X-Permitted-Cross-Domain-Policies` | Flash/PDF policy | Permissive |
| `Cross-Origin-*` | CORS policy | Restrictive |
| `Access-Control-Allow-Origin` | CORS origin | No CORS |

**Megjegyzés:** CSP és HSTS külön fejezetek (CONF-07, CONF-12)!

---

## 7 Misconfiguration Típus

### 1. **Empty Value**
### 2. **Invalid Value / Typo**
### 3. **Overpermissive**
### 4. **Duplicate Headers**
### 5. **Deprecated Headers**
### 6. **Invalid Placement**
### 7. **META Tag Conflicts**

---

## 1. Empty Value

### Concept:
**Header jelen van**, de **nincs értéke** → browser ignores.

### Example:

```http
X-Frame-Options:
(empty value!)
```

→ **No clickjacking protection!**

---

**Test:**
```bash
curl -I https://pelda.hu | grep -i x-frame-options
```

**Output:**
```
X-Frame-Options:
```

→ **VULNERABLE!** Empty value!

---

## 2. Invalid Value / Typo

### Concept:
**Typo** vagy **invalid directive** → browser nem ismeri fel.

### Example #1: **Typo in Header Name**

```http
X-Fram-Options: DENY
       ↑ Missing 'e'!
```

→ Browser doesn't recognize → **No protection!**

---

### Example #2: **Typo in Value**

```http
X-Frame-Options: DENNY
                    ↑ Wrong spelling!
```

**Valid values:** `DENY`, `SAMEORIGIN`, `ALLOW-FROM`  
**Invalid:** `DENNY` → **No protection!**

---

### Example #3: **Invalid Directive**

```http
Referrer-Policy: unsafe
                   ↑ Invalid!
```

**Valid values:** `no-referrer`, `origin`, `strict-origin`, etc.  
**Invalid:** `unsafe` → **Default behavior (full URL leaked)!**

---

**Test:**
```bash
curl -I https://pelda.hu | grep -i referrer-policy
```

**Check:**
- Valid directive?
- Correct spelling?

---

## 3. Overpermissive Headers

### Concept:
**Wildcard (`*`)** vagy **too broad** directive → excessive permissions.

---

### Example #1: **CORS - Allow All Origins**

**Overpermissive (BAD):**
```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
```

**Impact:**
```javascript
// Attacker site
fetch('https://victim.com/api/user', {
    credentials: 'include'  // Send cookies
}).then(r => r.json())
  .then(data => {
      // Steal user data!
      console.log(data);
  });
```

→ **CRITICAL!** Any origin can access with credentials!

---

**Note:** `Access-Control-Allow-Origin: *` **CANNOT** be used with `Access-Control-Allow-Credentials: true` (browser blocks), but some frameworks misconfigure this.

**Secure:**
```http
Access-Control-Allow-Origin: https://trusted-app.com
Access-Control-Allow-Credentials: true
```

---

### Example #2: **Referrer-Policy - unsafe-url**

**Overpermissive (BAD):**
```http
Referrer-Policy: unsafe-url
```

**Impact:**
```
User navigates: https://victim.com/profile?sessionid=abc123
To external site: https://analytics.com

Referer header sent:
Referer: https://victim.com/profile?sessionid=abc123
                                    ↑ Session ID leaked!
```

→ **HIGH!** Full URL (including sensitive params) leaked!

---

**Secure:**
```http
Referrer-Policy: no-referrer
```

**Or:**
```http
Referrer-Policy: strict-origin-when-cross-origin
```

---

### Example #3: **X-Permitted-Cross-Domain-Policies**

**Overpermissive (BAD):**
```http
X-Permitted-Cross-Domain-Policies: all
```

**Impact:**
- Flash/PDF can load data from any domain
- Cross-domain attacks possible

**Secure:**
```http
X-Permitted-Cross-Domain-Policies: none
```

---

### Example #4: **Permissions-Policy - All Features Allowed**

**Overpermissive (BAD):**
```http
Permissions-Policy: geolocation=*, microphone=*, camera=*
```

**Impact:**
- Any iframe can access geolocation, microphone, camera
- Privacy violation

**Secure:**
```http
Permissions-Policy: geolocation=(self), microphone=(self), camera=(self)
```

**Or disable completely:**
```http
Permissions-Policy: geolocation=(), microphone=(), camera=()
```

---

## 4. Duplicate Headers

### Concept:
**Ugyanaz a header többször**, különböző értékekkel → unpredictable browser behavior.

### Example:

```http
HTTP/1.1 200 OK
X-Frame-Options: DENY
X-Frame-Options: SAMEORIGIN
Content-Type: text/html
```

**Browser behavior:**
- Some browsers: Use first value (DENY)
- Some browsers: Use last value (SAMEORIGIN)
- Some browsers: Ignore all → **NO PROTECTION!**

→ **Unpredictable!** Avoid duplicates!

---

**Test:**
```bash
curl -I https://pelda.hu | grep -c "X-Frame-Options"
```

**If output > 1:** Duplicate headers!

---

## 5. Deprecated / Obsolete Headers

### Concept:
**Régi, elavult** header-ek már nem támogatottak → nem működnek vagy kockázatot jelentenek.

---

### Example #1: **HPKP (HTTP Public Key Pinning)**

```http
Public-Key-Pins: pin-sha256="base64=="; max-age=5184000
```

**Status:** **DEPRECATED!** (2018)

**Why removed:**
- Too risky (bricked websites if misconfigured)
- Certificate Transparency replaced it

**Action:** **REMOVE!**

**Reference:** https://scotthelme.co.uk/hpkp-is-no-more/

---

### Example #2: **X-Frame-Options ALLOW-FROM**

```http
X-Frame-Options: ALLOW-FROM https://trusted.com
```

**Status:** **OBSOLETE!** (deprecated directive)

**Problem:**
- Not supported by Chrome, Safari, Edge
- Only works in Firefox (legacy)

**Modern alternative:**
```http
Content-Security-Policy: frame-ancestors https://trusted.com
```

---

### Example #3: **X-XSS-Protection**

```http
X-XSS-Protection: 1; mode=block
```

**Status:** **DEPRECATED!**

**Why:**
- Introduced vulnerabilities in some cases
- Modern browsers removed XSS Auditor
- CSP provides better protection

**Action:** Use CSP instead!

---

**Deprecated Headers to Remove:**

| Header | Status | Alternative |
|--------|--------|-------------|
| `Public-Key-Pins` | Deprecated | Certificate Transparency |
| `X-XSS-Protection` | Deprecated | CSP |
| `Expect-CT` | Deprecated | Certificate Transparency |
| `X-Frame-Options ALLOW-FROM` | Obsolete | CSP `frame-ancestors` |

---

## 6. Invalid Placement

### Concept:
**Header csak bizonyos körülmények között érvényes**, pl. HSTS csak HTTPS-en.

---

### Example: **HSTS over HTTP**

```bash
# HTTP connection
curl -I http://pelda.hu | grep strict-transport-security
```

**Output:**
```
Strict-Transport-Security: max-age=31536000
```

→ **INEFFECTIVE!** HSTS **only works over HTTPS**!

**If sent over HTTP:**
- Browser ignores it
- No HSTS protection

---

**Proper implementation:**

**HTTP → Redirect to HTTPS:**
```http
HTTP/1.1 301 Moved Permanently
Location: https://pelda.hu/
```

**HTTPS → Send HSTS:**
```http
HTTP/1.1 200 OK
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

---

## 7. META Tag Conflicts

### Concept:
**Security policy** (pl. CSP) **HTTP header**-ben ÉS **META tag**-ben is → konfliktus lehetséges.

---

### Example:

**HTTP Header (Secure):**
```http
Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-abc123'
```

**HTML META Tag (Insecure):**
```html
<meta http-equiv="Content-Security-Policy" 
      content="default-src 'self'; script-src 'self' 'unsafe-inline'">
```

**Browser behavior:**
- Some browsers: HTTP header takes precedence
- Some browsers: META tag overrides header
- **Result:** `unsafe-inline` might be applied → **XSS vulnerable!**

---

**Best practice:**
- **Prefer HTTP headers** over META tags
- **Don't use both** for same policy
- If using META tag, ensure it matches header

---

**Exception:**
Some headers **CANNOT** be set via META tag:
- `X-Frame-Options`
- `Strict-Transport-Security`
- `Access-Control-*`

---

## Tesztelési Módszerek

### Tool #1: **curl**

#### Parancsok:
```bash
# Basic header check
curl -I https://pelda.hu

# Follow redirects
curl -L -I https://pelda.hu

# Custom User-Agent (bypass WAF)
curl -I -L -k --user-agent "Mozilla/5.0" https://pelda.hu

# Specific header
curl -I https://pelda.hu | grep -i x-frame-options
```

---

### Tool #2: **Browser DevTools**

#### Használat:
```
1. F12 → Network tab
2. Reload page
3. Click first request (document)
4. Headers → Response Headers
5. Review all security headers
```

**Check:**
- Are headers present?
- Correct values?
- Any duplicates?
- Any deprecated headers?

---

### Tool #3: **Mozilla Observatory**

**URL:** https://observatory.mozilla.org/

#### Használat:
```
1. Enter domain: pelda.hu
2. Click "Scan Me"
3. Review results
```

**Output példa:**
```
Score: C (55/100)

Issues:
✗ X-Frame-Options header not found
✗ Referrer-Policy header not found
✗ Content-Security-Policy header not found
⚠ X-Content-Type-Options: nosniff (good)
```

---

### Tool #4: **Security Headers Checker**

**URL:** https://securityheaders.com/

```
Enter URL → Scan
Results:
- Grade: A to F
- Missing headers
- Misconfigured headers
```

---

## Comprehensive Security Header Checklist

### ✅ Required Headers:

**1. X-Frame-Options:**
```http
X-Frame-Options: DENY
```

**Or:**
```http
X-Frame-Options: SAMEORIGIN
```

---

**2. X-Content-Type-Options:**
```http
X-Content-Type-Options: nosniff
```

---

**3. Referrer-Policy:**
```http
Referrer-Policy: no-referrer
```

**Or:**
```http
Referrer-Policy: strict-origin-when-cross-origin
```

---

**4. Permissions-Policy:**
```http
Permissions-Policy: geolocation=(self), microphone=(), camera=()
```

---

**5. X-Permitted-Cross-Domain-Policies:**
```http
X-Permitted-Cross-Domain-Policies: none
```

---

**6. Content-Security-Policy** (lásd CONF-12)

**7. Strict-Transport-Security** (lásd CONF-07)

---

### ❌ Remove Deprecated:

```
✗ Public-Key-Pins
✗ X-XSS-Protection
✗ Expect-CT
✗ X-Frame-Options ALLOW-FROM
```

---

## Gyakorlati Testing Script

```bash
#!/bin/bash

URL=$1

echo "=== Security Headers Test ==="
echo "Target: $URL"
echo ""

# Fetch headers
HEADERS=$(curl -I -L -s -k $URL)

# Check X-Frame-Options
echo "[*] X-Frame-Options:"
echo "$HEADERS" | grep -i "x-frame-options" || echo "  MISSING!"

# Check X-Content-Type-Options
echo "[*] X-Content-Type-Options:"
echo "$HEADERS" | grep -i "x-content-type-options" || echo "  MISSING!"

# Check Referrer-Policy
echo "[*] Referrer-Policy:"
echo "$HEADERS" | grep -i "referrer-policy" || echo "  MISSING!"

# Check HSTS
echo "[*] Strict-Transport-Security:"
echo "$HEADERS" | grep -i "strict-transport-security" || echo "  MISSING!"

# Check CSP
echo "[*] Content-Security-Policy:"
echo "$HEADERS" | grep -i "content-security-policy" || echo "  MISSING!"

# Check Permissions-Policy
echo "[*] Permissions-Policy:"
echo "$HEADERS" | grep -i "permissions-policy" || echo "  MISSING!"

# Check deprecated
echo "[*] Deprecated headers:"
echo "$HEADERS" | grep -i "public-key-pins" && echo "  WARNING: HPKP found!"
echo "$HEADERS" | grep -i "x-xss-protection" && echo "  WARNING: X-XSS-Protection found!"

# Check duplicates
echo "[*] Duplicate headers:"
for header in "x-frame-options" "strict-transport-security" "content-security-policy"; do
    count=$(echo "$HEADERS" | grep -ic "$header")
    if [ $count -gt 1 ]; then
        echo "  WARNING: $header appears $count times!"
    fi
done

echo ""
echo "=== Test Complete ==="
```

**Használat:**
```bash
chmod +x security-headers-test.sh
./security-headers-test.sh https://pelda.hu
```

---

## Gyakorlati Cheat Sheet

| Header | Recommended Value |
|--------|-------------------|
| `X-Frame-Options` | `DENY` vagy `SAMEORIGIN` |
| `X-Content-Type-Options` | `nosniff` |
| `Referrer-Policy` | `no-referrer` vagy `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `geolocation=(self), microphone=(), camera=()` |
| `X-Permitted-Cross-Domain-Policies` | `none` |

---

## Fontos Toolok

### Online Scanners:
- **Mozilla Observatory** - Comprehensive scan
- **SecurityHeaders.com** - Quick grade
- **SSL Labs** - HTTPS + headers

### Manual:
- **curl** - Command line
- **Browser DevTools** - F12

### Proxy:
- **Burp Suite** - Header inspection
- **ZAP** - Automated scan

---

## Védelem (Remediation)

### 1. **Implement All Required Headers:**

**Apache (.htaccess vagy httpd.conf):**
```apache
Header always set X-Frame-Options "DENY"
Header always set X-Content-Type-Options "nosniff"
Header always set Referrer-Policy "no-referrer"
Header always set Permissions-Policy "geolocation=(self), microphone=(), camera=()"
Header always set X-Permitted-Cross-Domain-Policies "none"
```

---

**nginx (nginx.conf):**
```nginx
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "no-referrer" always;
add_header Permissions-Policy "geolocation=(self), microphone=(), camera=()" always;
add_header X-Permitted-Cross-Domain-Policies "none" always;
```

---

**Node.js (Express + Helmet):**
```javascript
const helmet = require('helmet');

app.use(helmet({
    frameguard: { action: 'deny' },
    contentSecurityPolicy: false, // Configure separately
    hsts: { maxAge: 31536000, includeSubDomains: true },
    referrerPolicy: { policy: 'no-referrer' }
}));

app.use((req, res, next) => {
    res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
    res.setHeader('Permissions-Policy', 'geolocation=(self), microphone=(), camera=()');
    next();
});
```

---

### 2. **Remove Deprecated Headers:**

```apache
# REMOVE these!
# Header set Public-Key-Pins ...
# Header set X-XSS-Protection ...
# Header set Expect-CT ...
```

---

### 3. **Avoid Duplicates:**

```
Check configuration files:
- Only ONE definition per header
- Use "always" directive (Apache) to prevent duplicates
```

---

### 4. **Validate CORS:**

**Bad:**
```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
```

**Good:**
```http
Access-Control-Allow-Origin: https://trusted-app.com
Access-Control-Allow-Credentials: true
```

---

## Fontos Megjegyzések

✅ **X-Frame-Options** = clickjacking protection  
✅ **X-Content-Type-Options: nosniff** = MIME sniffing protection  
✅ **Referrer-Policy** = control what referrer info is sent  
✅ **Permissions-Policy** = restrict browser features  
✅ **HPKP** = **DEPRECATED!** Remove it!  
✅ **X-XSS-Protection** = **DEPRECATED!** Use CSP!  
❌ **Empty value** = header ignored!  
❌ **Typo** = header not recognized!  
❌ **CORS `*` + credentials** = security risk!  
⚠️ **HSTS over HTTP** = ineffective!  
⚠️ **Duplicate headers** = unpredictable behavior!

---

**Összefoglalva:** Ez a fejezet az **egyéb HTTP security header** misconfiguration-jeiről szól (X-Frame-Options, Referrer-Policy, CORS, Permissions-Policy, stb.). **Empty value**, **typo**, **overpermissive directive** (`Access-Control-Allow-Origin: *`), **duplicate headers**, **deprecated headers** (HPKP, X-XSS-Protection), **invalid placement** (HSTS over HTTP), és **META tag conflicts** mind **weakening** a security-t. **Mozilla Observatory** és **SecurityHeaders.com** comprehensive scanner-ek. **Required headers**: X-Frame-Options (DENY/SAMEORIGIN), X-Content-Type-Options (nosniff), Referrer-Policy (no-referrer), Permissions-Policy. **Remove deprecated**: HPKP, X-XSS-Protection, Expect-CT!
