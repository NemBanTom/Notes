# WSTG-IDNT-01: Role Definition Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **RBAC (Role-Based Access Control)** rendszerek **role definition-jeit** kell tesztelni - **milyen role-ok** léteznek, **hogyan lehet role-t váltani**, és hogy a **role permission-ök** megfelelően vannak-e beállítva. **Weak role control** = **privilege escalation**, **unauthorized access**, vagy **administrative function abuse**.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános authorization testing! Ez specifikusan **role identification** és **role switching** - mely role-ok vannak, és lehet-e váltani közöttük.

---

## Mi a cél?

**Application role-ok azonosítása és tesztelése:**
- Role-ok felderítése (admin, user, moderator, stb.)
- Role switching/change lehetőségek
- Role permission-ök granularitása
- Maker-checker principle betartása

---

## RBAC Concept

### Role-Based Access Control:

**Concept:** User-ekhez **role-okat** rendelnek, role-okhoz **permission-öket**.

```
User → assigned to → Role → has → Permissions
```

---

### Tipikus Role-ok:

| Role | Permissions | Example Actions |
|------|-------------|-----------------|
| **Administrator** | Full control | User management, system config |
| **Moderator** | Content management | Delete posts, ban users |
| **Support** | Customer assistance | View tickets, update status |
| **Auditor** | Read-only access | View logs, generate reports |
| **Customer** | Basic features | View profile, make purchases |

---

## 3 Tesztelési Terület

### 1. **Role Identification** (Role-ok Felderítése)
### 2. **Role Switching** (Role Váltás Tesztelése)
### 3. **Permission Review** (Jogosultságok Ellenőrzése)

---

## 1. Role Identification

### Method #1: **Application Documentation**

**Check:**
- User manual
- API documentation
- Admin guide
- Help pages

**Példa:**
```
Documentation mentions:
- Administrator role
- Moderator role
- Premium user role
- Free user role
```

---

### Method #2: **Developer/Admin Guidance**

**Gray-box testing:**
```
Ask developers:
- What roles exist?
- What permissions does each have?
- How are roles assigned?
```

---

### Method #3: **Application Comments**

**HTML source code:**
```html
<!-- Admin panel available at /admin -->
<!-- Moderator features: ban users, delete posts -->
<!-- Role: customer -->
```

**JavaScript:**
```javascript
if (user.role === 'admin') {
    showAdminPanel();
}
```

---

### Method #4: **Cookie/Parameter Fuzzing**

#### Cookie-based Roles:

```bash
# Check cookies
curl https://pelda.hu -H "Cookie: session=abc123" -v 2>&1 | grep -i "Set-Cookie"
```

**Possible cookies:**
```
role=user
isAdmin=false
userType=customer
privilege=0
accessLevel=1
```

---

**Role fuzzing:**
```bash
# Try different role values
curl https://pelda.hu -H "Cookie: session=abc123; role=admin"
curl https://pelda.hu -H "Cookie: session=abc123; role=moderator"
curl https://pelda.hu -H "Cookie: session=abc123; isAdmin=true"
curl https://pelda.hu -H "Cookie: session=abc123; privilege=999"
```

---

#### Parameter-based Roles:

**Account variable (JSON response):**
```json
{
  "username": "john",
  "email": "john@example.com",
  "role": "user"
}
```

**Test fuzzing:**
```bash
# Modify role in request
curl -X PUT https://pelda.hu/api/profile \
  -H "Content-Type: application/json" \
  -d '{"role": "admin"}'
```

---

#### URL Parameter:

```
https://pelda.hu/dashboard?role=admin
https://pelda.hu/panel?userType=moderator
https://pelda.hu/admin?access=true
```

---

### Method #5: **Hidden Directories/Files**

**Common admin paths:**
```bash
# Fuzz admin directories
gobuster dir -u https://pelda.hu -w admin-paths.txt

# admin-paths.txt:
/admin
/administrator
/mod
/moderator
/backups
/manager
/super
/root
/staff
```

---

**Example discovery:**
```bash
curl https://pelda.hu/admin/
# → 200 OK (admin panel accessible!)

curl https://pelda.hu/mod/
# → 200 OK (moderator panel!)
```

---

### Method #6: **Well-Known Users**

**Try switching to common usernames:**
```
admin
administrator
root
moderator
mod
support
backups
system
sa (SQL Server admin)
```

**Test:**
```bash
# Login as admin
curl -X POST https://pelda.hu/api/login \
  -d "username=admin&password=admin123"
```

---

### Method #7: **HTTP Headers**

**Check response headers:**
```bash
curl -I https://pelda.hu/dashboard
```

**Possible headers:**
```
X-User-Role: customer
X-Access-Level: 1
X-Permissions: read,write
```

---

## 2. Role Switching

### Concept:
**Tesztelni**, hogy **user válthat-e role-t** authorization nélkül.

---

### Attack #1: **Cookie Manipulation**

**Scenario:**
```
1. Login as regular user
2. Check cookie: role=user
3. Modify to: role=admin
4. Access admin features
```

---

**Example:**

**1. Login:**
```bash
curl -X POST https://pelda.hu/login \
  -d "username=testuser&password=password123" \
  -c cookies.txt
```

**2. Check cookie:**
```bash
cat cookies.txt
# → role=user
```

**3. Modify cookie:**
```bash
# Edit cookies.txt
# Change: role=user
# To: role=admin
```

**4. Access admin panel:**
```bash
curl https://pelda.hu/admin/dashboard -b cookies.txt
```

**If successful (200 OK):**
→ **CRITICAL!** Role switching vulnerability!

---

### Attack #2: **JWT Token Manipulation**

**Scenario:**
```
JWT contains role claim
Modify role in JWT
Re-sign or use without signature verification
```

---

**Example:**

**1. Get JWT:**
```bash
curl -X POST https://pelda.hu/api/login \
  -d '{"username":"user","password":"pass"}' \
  -H "Content-Type: application/json"
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoidXNlciIsInJvbGUiOiJ1c2VyIn0.xxx"
}
```

---

**2. Decode JWT** (jwt.io):
```json
{
  "user": "user",
  "role": "user"
}
```

---

**3. Modify role:**
```json
{
  "user": "user",
  "role": "admin"
}
```

---

**4. Re-encode:**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoidXNlciIsInJvbGUiOiJhZG1pbiJ9.xxx
```

---

**5. Test:**
```bash
curl https://pelda.hu/api/admin/users \
  -H "Authorization: Bearer eyJ..."
```

**If successful:**
→ **CRITICAL!** JWT role manipulation!

---

### Attack #3: **Parameter Tampering**

**Scenario:**
```
Role parameter in request
Modify to escalate privileges
```

---

**Example:**

**Normal request:**
```bash
POST /api/updateProfile HTTP/1.1
Content-Type: application/json

{
  "username": "john",
  "email": "john@example.com",
  "role": "user"
}
```

---

**Tampered request:**
```bash
POST /api/updateProfile HTTP/1.1
Content-Type: application/json

{
  "username": "john",
  "email": "john@example.com",
  "role": "admin"
}
```

**If accepted:**
→ **CRITICAL!** User can self-promote to admin!

---

### Attack #4: **Account Creation with Role**

**Scenario:**
```
Registration endpoint
Add role parameter
Create admin account directly
```

---

**Example:**

**Normal registration:**
```bash
POST /api/register HTTP/1.1
Content-Type: application/json

{
  "username": "newuser",
  "password": "pass123",
  "email": "new@test.com"
}
```

---

**With role injection:**
```bash
POST /api/register HTTP/1.1
Content-Type: application/json

{
  "username": "newuser",
  "password": "pass123",
  "email": "new@test.com",
  "role": "admin"
}
```

**If accepted:**
→ **CRITICAL!** Anyone can create admin account!

---

## 3. Permission Review

### Concept:
**Ellenőrizni**, hogy **role permission-ök** megfelelően granular-ok és restrictive-ek.

---

### Principle of Least Privilege:

**Minden role csak a minimálisan szükséges permission-öket kapja.**

---

### Common Permission Issues:

#### Issue #1: **Support Engineer with Admin Powers**

**BAD:**
```
Support Engineer role:
- View user accounts ✓
- Modify user accounts ✓
- Delete user accounts ✗ (TOO MUCH!)
- Access admin panel ✗ (TOO MUCH!)
- Manage backups ✗ (TOO MUCH!)
```

**GOOD:**
```
Support Engineer role:
- View user accounts ✓
- Update ticket status ✓
- View logs (limited) ✓
- NO admin functions
- NO backup access
```

---

#### Issue #2: **Admin without Maker-Checker**

**BAD:**
```
Administrator can:
- Delete all users (single action)
- Transfer funds (no approval)
- Change system config (immediate effect)
```

**GOOD:**
```
Administrator can:
- Delete users (requires second admin approval)
- Transfer funds (requires MFA + approval)
- Config changes (staged, reviewed)
```

---

#### Issue #3: **Overly Broad Permissions**

**BAD:**
```
Moderator role:
- Delete ANY post (including admin posts)
- Ban ANY user (including admins)
- Access user private messages
```

**GOOD:**
```
Moderator role:
- Delete regular user posts only
- Ban regular users only (not admins/mods)
- NO access to private messages
```

---

### Real-World Example: **Twitter Hack 2020**

**Incident:**
- Support engineers had **too broad access**
- Could access ANY user account
- No maker-checker for sensitive accounts
- Attackers compromised support accounts
- Took over high-profile accounts (Obama, Musk, etc.)

**Lesson:**
- Support should have **limited access**
- **MFA** for sensitive operations
- **Maker-checker** for VIP accounts
- **Audit logs** for all actions

**Reference:** https://blog.twitter.com/en_us/topics/company/2020/an-update-on-our-security-incident.html

---

## Testing with Burp Suite

### Tool: **Autorize Extension**

**Install:**
```
1. Burp → Extender → BApp Store
2. Search: Autorize
3. Install
```

---

**Usage:**
```
1. Autorize → Configuration
2. Low-privileged user session: [paste session cookie]
3. Browse as admin (or higher-privilege user)
4. Autorize intercepts requests
5. Replays with low-privileged session
6. Compares responses
7. Highlights unauthorized access
```

---

**Example:**

**Admin request:**
```
GET /admin/users HTTP/1.1
Cookie: session=admin_session_abc123
```

**Autorize replays with user session:**
```
GET /admin/users HTTP/1.1
Cookie: session=user_session_xyz789
```

---

**If response is same (200 OK):**
→ **VULNERABLE!** User can access admin endpoint!

**If response is different (403 Forbidden):**
→ Properly secured

---

## Testing with ZAP

### Tool: **Access Control Testing Add-on**

**Install:**
```
ZAP → Manage Add-ons → Marketplace
Search: Access Control Testing
Install
```

---

**Usage:**
```
1. ZAP → Tools → Access Control Testing
2. Set up users:
   - User 1: Admin (high privilege)
   - User 2: Regular user (low privilege)
3. Define test rules
4. Run test
5. Review unauthorized access findings
```

---

## Role Permission Matrix

### Example Matrix:

| Feature | Admin | Moderator | Support | User |
|---------|-------|-----------|---------|------|
| View users | ✓ | ✓ | ✓ | Self only |
| Edit users | ✓ | ✗ | Profile only | Self only |
| Delete users | ✓ (w/ approval) | ✗ | ✗ | ✗ |
| View posts | ✓ | ✓ | ✓ | ✓ |
| Edit posts | ✓ | Own only | ✗ | Own only |
| Delete posts | ✓ | ✓ | ✗ | Own only |
| Ban users | ✓ | ✓ | ✗ | ✗ |
| System config | ✓ (w/ MFA) | ✗ | ✗ | ✗ |
| View logs | ✓ | Limited | Limited | ✗ |
| Manage backups | ✓ (w/ approval) | ✗ | ✗ | ✗ |

---

## Comprehensive Testing Checklist

### 1. **Role Discovery:**
```
☐ Review documentation
☐ Check application comments
☐ Fuzz cookie values (role=, isAdmin=, etc.)
☐ Fuzz URL parameters
☐ Brute-force admin directories
☐ Try well-known usernames
☐ Inspect HTTP headers
```

---

### 2. **Role Switching:**
```
☐ Modify role cookie
☐ Modify JWT role claim
☐ Parameter tampering (role in JSON)
☐ Account creation with role injection
☐ Session fixation with different role
```

---

### 3. **Permission Review:**
```
☐ Document all roles and permissions
☐ Test each role's access boundaries
☐ Verify least privilege principle
☐ Check for maker-checker (sensitive ops)
☐ Test cross-role access (user → admin)
☐ Verify MFA for critical actions
☐ Review audit logging
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs/Módszer |
|-------|-----------------|
| Cookie role check | `curl -b cookies.txt https://URL` |
| Role modification | Edit cookie: `role=admin` |
| JWT decode | jwt.io or `echo JWT \| cut -d'.' -f2 \| base64 -d` |
| Admin dir fuzz | `gobuster dir -u URL -w admin-paths.txt` |
| Parameter tamper | Add `"role": "admin"` to JSON |
| Burp Autorize | Extension: replay low-priv session |

---

## Fontos Toolok

### Manual:
- **curl** - Cookie/header manipulation
- **Browser DevTools** - Cookie editing
- **jwt.io** - JWT decode/encode

### Proxy:
- **Burp Suite** - Autorize extension
- **ZAP** - Access Control Testing add-on

### Fuzzing:
- **gobuster** - Directory brute-force
- **ffuf** - Parameter fuzzing

---

## Védelem (Remediation)

### 1. **Server-Side Role Enforcement:**

**BAD (Client-side):**
```javascript
// Client-side only
if (user.role === 'admin') {
    showAdminButton();
}
```

**GOOD (Server-side):**
```python
# Server validates role
@require_role('admin')
def admin_dashboard():
    return render_template('admin.html')
```

---

### 2. **Signed/Encrypted Role Claims:**

**JWT with signature:**
```python
import jwt

payload = {'user': 'john', 'role': 'user'}
secret = 'super-secret-key'

token = jwt.encode(payload, secret, algorithm='HS256')

# Verify on every request
decoded = jwt.decode(token, secret, algorithms=['HS256'])
```

---

### 3. **Role Immutability:**

```python
# Users cannot modify their own role
@app.route('/api/profile', methods=['PUT'])
def update_profile():
    data = request.json
    
    # Remove role from user input
    if 'role' in data:
        del data['role']  # Ignore client-provided role
    
    # Update allowed fields only
    current_user.update(data)
```

---

### 4. **Maker-Checker for Sensitive Operations:**

```python
@require_role('admin')
@require_approval  # Second admin must approve
def delete_all_users():
    # Create approval request
    approval = ApprovalRequest(
        action='delete_all_users',
        requestor=current_user,
        status='pending'
    )
    approval.save()
    return "Approval required"
```

---

### 5. **MFA for Critical Actions:**

```python
@require_role('admin')
@require_mfa  # MFA token required
def transfer_funds(amount, to_account):
    # Verify MFA token
    if not verify_mfa(request.headers['X-MFA-Token']):
        return "MFA required", 403
    
    # Proceed with transfer
    do_transfer(amount, to_account)
```

---

### 6. **Audit Logging:**

```python
@log_action  # Log all admin actions
@require_role('admin')
def admin_action():
    logger.info(f"Admin {current_user} performed action X")
    # ... action ...
```

---

## Fontos Megjegyzések

✅ **RBAC** = Role-Based Access Control  
✅ **Role switching** = changing from user to admin  
✅ **Cookie manipulation** = common attack vector  
✅ **JWT role claim** = must be signed/verified  
✅ **Least privilege** = minden role minimal permissions  
✅ **Maker-checker** = second approval for critical ops  
✅ **Twitter 2020** = real example of weak role control  
❌ **Client-side role check** = easily bypassed!  
⚠️ **Support with admin powers** = too broad!  
⚠️ **Registration with role** = mass privilege escalation!

---

**Összefoglalva:** Ez a fejezet az **RBAC role definition** teszteléséről szól. **Role identification** (documentation, fuzzing, hidden directories), **role switching** (cookie manipulation, JWT tampering, parameter injection), és **permission review** (least privilege, maker-checker). **Cookie-based role** (`role=admin`) vagy **JWT claim** (`"role": "admin"`) **easily manipulated** ha nincs server-side validation. **Support engineer** ne legyen **admin powers**-szal. **Sensitive operations** (user deletion, fund transfer) **maker-checker** principle és **MFA**. **Twitter 2020 hack** = support engineers túl sok hozzáféréssel. **Burp Autorize** és **ZAP Access Control Testing** automated testing-hez!
