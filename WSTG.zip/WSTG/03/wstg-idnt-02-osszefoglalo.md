# WSTG-IDNT-02: User Registration Process Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **user registration process** (felhasználói regisztráció) **identity requirement-jei** és **validation-je** megfelelően szigorú-e a **security requirements**-hez képest. **Weak registration** = **fake accounts**, **abuse**, **bot registration**, vagy **identity theft**. Kritikus kérdés: **bárki regisztrálhat** vagy van **identity verification**?

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános input validation! Ez specifikusan **registration process** - ki regisztrálhat, milyen proof of identity kell, és van-e verification.

---

## Mi a cél?

**Registration process** biztonsági követelményeinek ellenőrzése:
- Identity requirements (mi kell a regisztrációhoz?)
- Verification process (ellenőrzik-e az identity-t?)
- Multiple registration prevention (lehet többször regisztrálni?)
- Role assignment (milyen role-t kap az új user?)
- Identity forgery prevention (lehet-e fake identity-vel regisztrálni?)

---

## 6 Kritikus Kérdés (Identity Requirements)

### 1. **Can Anyone Register?**

**Kérdés:** Nyilvános-e a regisztráció vagy korlátozott?

---

**Példa - Nyilvános:**
```
WordPress, Gmail, Facebook:
- Bárki regisztrálhat
- Csak email kell
- Nincs pre-approval
```

**Megfelelő?** → Depends on use case:
- Public forum: ✓ OK
- Banking app: ✗ NOT OK!

---

**Példa - Korlátozott:**
```
Corporate application:
- Csak alkalmazottak
- Pre-approval szükséges
- HR validates before provisioning
```

**Megfelelő?** → ✓ Internal systems

---

### 2. **Are Registrations Vetted?**

**Kérdés:** Van-e emberi jóváhagyás vagy automatikus?

---

**Automatikus:**
```
WordPress:
1. Fill form
2. Verify email
3. Account created
(no human review)
```

**Kockázat:** Bots, fake accounts, abuse

---

**Manual vetting:**
```
Corporate app:
1. Submit registration request
2. Admin reviews
3. Approves/rejects
4. Account provisioned
```

**Benefit:** Kontrolláltabb, de lassabb

---

### 3. **Can Same Person Register Multiple Times?**

**Kérdés:** Lehet ugyanaz a személy többször regisztrálni?

---

**Teszt:**
```bash
# Register with same email
curl -X POST https://pelda.hu/api/register \
  -d "email=test@test.com&username=user1&password=pass1"

curl -X POST https://pelda.hu/api/register \
  -d "email=test@test.com&username=user2&password=pass2"
```

**Ha mindkettő sikeres:**
→ **Weak!** Multiple accounts same email

---

**Variációk:**
```
test@test.com
test+1@test.com  (Gmail alias)
test+spam@test.com
test@test.com vs TEST@TEST.COM (case variation)
test@test.com with trailing spaces
```

---

### 4. **Can Users Register for Different Roles?**

**Kérdés:** Választhat-e user role-t regisztrációnál?

---

**Vulnerable példa:**
```bash
POST /api/register HTTP/1.1
Content-Type: application/json

{
  "username": "hacker",
  "email": "hack@evil.com",
  "password": "pass123",
  "role": "admin"    ← User-provided!
}
```

**Ha elfogadja:**
→ **CRITICAL!** User can register as admin!

---

**Secure:**
```python
# Server assigns default role
def register_user(data):
    # Ignore client-provided role
    if 'role' in data:
        del data['role']
    
    # Assign default
    data['role'] = 'user'
    
    create_user(data)
```

---

### 5. **What Proof of Identity is Required?**

**Kérdés:** Milyen identity proof szükséges?

---

**Weak (WordPress-style):**
```
Required:
- Email address
- Username
- Password

Verification:
- Email verification link
```

**Pro:** Gyors regisztráció  
**Con:** Fake accounts, disposable emails

---

**Moderate (Google-style):**
```
Required:
- Name
- Date of birth
- Country
- Mobile number
- Email
- CAPTCHA

Verification:
- Email verification
- SMS code to mobile
```

**Pro:** Harder to fake  
**Con:** Privacy concerns

---

**Strong (Banking):**
```
Required:
- Full legal name
- National ID / Passport
- Address proof
- Photo ID
- Phone number (verified)
- Email (verified)
- Video KYC (Know Your Customer)

Verification:
- ID document verification
- Face matching
- Address verification
- Credit check
```

**Pro:** Very secure  
**Con:** Slow, invasive

---

### 6. **Are Registered Identities Verified?**

**Kérdés:** Ellenőrzik-e ténylegesen az identity-t?

---

**No verification:**
```
Register with:
- Name: Mickey Mouse
- Email: fake@fake.com (disposable)
- Phone: 555-1234 (fake)

→ Account created!
```

**Risk:** Fake accounts, abuse

---

**Email verification:**
```
1. User registers
2. Email sent: "Click to verify"
3. User clicks link
4. Account activated
```

**Helps:** Ensure email is accessible  
**Doesn't prevent:** Disposable emails

---

**SMS verification:**
```
1. User registers with phone
2. SMS code sent
3. User enters code
4. Account activated
```

**Helps:** Real phone number  
**Doesn't prevent:** VoIP numbers, temporary services

---

**Document verification:**
```
1. User uploads ID (passport, driver's license)
2. System/human verifies document
3. Face matching (selfie vs ID)
4. Account approved
```

**Best for:** High-security applications (banking, crypto)

---

## Validation Testing (7 Tests)

### Test #1: **Can Identity Be Forged?**

#### Teszt:
```bash
# Register with fake data
curl -X POST https://pelda.hu/api/register \
  -d "name=Donald Duck&email=fake@fake.com&password=pass"
```

**Ha sikeres:**
→ **Weak!** No identity validation

---

#### Fake Email Services:

**Disposable email-ek:**
```
10minutemail.com
guerrillamail.com
temp-mail.org
throwaway.email
```

**Teszt:**
```bash
# Get disposable email
# Register with it
# Check if accepted
```

**Ha elfogadja:**
→ No email domain validation

---

### Test #2: **Email Enumeration**

#### Teszt:
```bash
# Try to register with existing email
curl -X POST https://pelda.hu/api/register \
  -d "email=existing@user.com&username=new&password=pass"
```

**Ha válasz:**
```
"Email already registered"
```

→ **Email enumeration** vulnerability!  
→ Attacker can discover registered emails

---

**Secure response:**
```
"If email exists, verification link sent"
(Same response for existing and new emails)
```

---

### Test #3: **Username Enumeration**

#### Teszt:
```bash
curl -X POST https://pelda.hu/api/register \
  -d "username=admin&email=new@test.com&password=pass"
```

**Ha válasz:**
```
"Username already taken"
```

→ **Username enumeration!**

---

**Secure:**
```
"Registration request received"
(No indication if username exists)
```

---

### Test #4: **Multiple Registrations (Same Email)**

#### Teszt:
```bash
# First registration
curl -X POST https://pelda.hu/api/register \
  -d "email=test@test.com&username=user1&password=pass1"

# Second registration (same email, different username)
curl -X POST https://pelda.hu/api/register \
  -d "email=test@test.com&username=user2&password=pass2"
```

**Ha mindkettő sikeres:**
→ **Weak!** Allows multiple accounts

---

#### Email Alias Testing:

**Gmail aliases:**
```
test@gmail.com
test+1@gmail.com
test+anything@gmail.com
(All deliver to same inbox!)
```

**Teszt:**
```bash
# Register with aliases
curl -X POST /register -d "email=test@gmail.com&..."
curl -X POST /register -d "email=test+1@gmail.com&..."
curl -X POST /register -d "email=test+2@gmail.com&..."
```

**Ha mindhárom sikeres:**
→ **Multiple accounts with one email!**

---

**Secure:**
```python
# Normalize email before checking
def normalize_email(email):
    local, domain = email.split('@')
    
    # Remove Gmail alias
    if domain == 'gmail.com':
        local = local.split('+')[0]
    
    # Lowercase
    email = f"{local}@{domain}".lower()
    
    return email

# Check if normalized email exists
if User.exists(normalize_email(email)):
    return "Email already registered"
```

---

### Test #5: **Role Assignment Manipulation**

#### Teszt:
```bash
# Try to register with admin role
POST /api/register HTTP/1.1
{
  "username": "hacker",
  "password": "pass",
  "role": "admin",
  "isAdmin": true,
  "privilege": 999
}
```

**Ha elfogadja valamelyik paramétert:**
→ **CRITICAL!** Role manipulation

---

### Test #6: **CAPTCHA Bypass**

#### No CAPTCHA:
```bash
# Automated registration (bot)
for i in {1..1000}; do
  curl -X POST /register -d "email=bot$i@spam.com&..."
done
```

**Ha működik:**
→ **Bot registration** possible!

---

#### Weak CAPTCHA:
```
CAPTCHA:
- Simple math: 2 + 2 = ?
- OCR-able images
- Reusable tokens
```

**Bypass:**
```bash
# Reuse same CAPTCHA token
curl -X POST /register \
  -d "email=bot1@spam.com&captcha_token=ABC123&..."

curl -X POST /register \
  -d "email=bot2@spam.com&captcha_token=ABC123&..."
```

---

### Test #7: **Rate Limiting**

#### Teszt:
```bash
# Mass registration
for i in {1..100}; do
  curl -X POST /register -d "email=spam$i@test.com&..."
done
```

**Ha nincs rate limit:**
→ **Account creation abuse!**

---

**Secure:**
```
Rate limit:
- 5 registrations per IP per hour
- CAPTCHA after 3 attempts
- Email domain blacklist (disposable emails)
```

---

## Real-World Scenarios

### Scenario #1: **WordPress**

**Requirements:**
```
- Email address
- Username
- Password
```

**Verification:**
- Email verification link

**Weakness:**
- Disposable email OK
- No phone verification
- No CAPTCHA (default)
- Username enumeration possible

**Use case:** Blog, simple sites (OK)  
**Banking app:** Not secure enough!

---

### Scenario #2: **Google**

**Requirements:**
```
- First & Last name
- Username
- Password
- Date of birth
- Gender
- Country
- Phone number (optional but recommended)
- Recovery email
- CAPTCHA
```

**Verification:**
- Email verification
- SMS verification (if phone provided)

**Strengths:**
- Phone verification
- CAPTCHA
- Harder to fake

---

### Scenario #3: **Banking App**

**Requirements:**
```
- Full legal name
- National ID / SSN
- Date of birth
- Address
- Phone number
- Email
- Photo ID upload
- Selfie (face matching)
```

**Verification:**
- Document verification (AI + human)
- Face matching
- Address proof
- Credit bureau check
- Video KYC

**Strengths:**
- Very secure
- Regulatory compliance (KYC/AML)

---

## Testing with Burp Suite

### Intercept Registration Request:

```
1. Burp → Proxy → Intercept On
2. Fill registration form
3. Submit
4. Intercept request in Burp
```

---

### Modify Parameters:

**Original:**
```http
POST /api/register HTTP/1.1
Content-Type: application/json

{
  "username": "testuser",
  "email": "test@test.com",
  "password": "Password123"
}
```

---

**Modified (add role):**
```http
POST /api/register HTTP/1.1
Content-Type: application/json

{
  "username": "testuser",
  "email": "test@test.com",
  "password": "Password123",
  "role": "admin",
  "isAdmin": true,
  "verified": true
}
```

**Forward → Check response**

---

## Comprehensive Testing Checklist

### Identity Requirements:
```
☐ Is registration open to public or restricted?
☐ What identity fields are required?
☐ Is manual approval needed?
☐ Can users choose roles?
☐ What proof of identity is required?
☐ How is identity verified?
```

---

### Validation Testing:
```
☐ Can fake data be used?
☐ Are disposable emails blocked?
☐ Email enumeration vulnerability?
☐ Username enumeration vulnerability?
☐ Multiple registrations (same email)?
☐ Email alias bypass (Gmail +)?
☐ Role parameter injection?
☐ CAPTCHA present and effective?
☐ Rate limiting implemented?
☐ Account activation required?
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Basic registration | `curl -X POST /register -d "email=...&password=..."` |
| Fake email | Register with 10minutemail.com |
| Email enumeration | Try existing email, check response |
| Multiple accounts | Register twice with same email |
| Gmail alias | `test+1@gmail.com` vs `test@gmail.com` |
| Role injection | Add `"role": "admin"` in JSON |
| Bot registration | Loop 100 registrations |
| Rate limit test | Mass registration from same IP |

---

## Fontos Toolok

### Manual:
- **curl** - API testing
- **Browser DevTools** - Form inspection
- **Disposable emails** - 10minutemail, guerrillamail

### Proxy:
- **Burp Suite** - Request interception
- **ZAP** - Automated scanning

### Automation:
- **Python scripts** - Mass registration testing
- **Selenium** - Browser automation

---

## Védelem (Remediation)

### 1. **Email Verification:**

```python
# Send verification email
def register_user(email, password):
    token = generate_token()
    user = User(email=email, password=hash(password), verified=False)
    user.save()
    
    send_email(
        to=email,
        subject="Verify your account",
        body=f"Click: https://app.com/verify?token={token}"
    )
```

---

### 2. **Block Disposable Emails:**

```python
DISPOSABLE_DOMAINS = [
    '10minutemail.com',
    'guerrillamail.com',
    'temp-mail.org',
    # ... more
]

def is_disposable(email):
    domain = email.split('@')[1]
    return domain in DISPOSABLE_DOMAINS

if is_disposable(email):
    return "Disposable emails not allowed", 400
```

---

### 3. **Normalize Email (Prevent Duplicates):**

```python
def normalize_email(email):
    local, domain = email.lower().split('@')
    
    # Gmail: remove dots and aliases
    if domain == 'gmail.com':
        local = local.replace('.', '')
        local = local.split('+')[0]
    
    return f"{local}@{domain}"

# Check uniqueness
normalized = normalize_email(email)
if User.query.filter_by(email_normalized=normalized).first():
    return "Email already registered", 400
```

---

### 4. **CAPTCHA (reCAPTCHA v3):**

```html
<!-- Frontend -->
<script src="https://www.google.com/recaptcha/api.js"></script>
<form>
  <div class="g-recaptcha" data-sitekey="YOUR_SITE_KEY"></div>
  <button>Register</button>
</form>
```

```python
# Backend verification
import requests

def verify_recaptcha(token):
    response = requests.post('https://www.google.com/recaptcha/api/siteverify', data={
        'secret': 'YOUR_SECRET_KEY',
        'response': token
    })
    result = response.json()
    return result.get('success', False)

if not verify_recaptcha(request.form['g-recaptcha-response']):
    return "CAPTCHA verification failed", 400
```

---

### 5. **Rate Limiting:**

```python
from flask_limiter import Limiter

limiter = Limiter(app, key_func=lambda: request.remote_addr)

@app.route('/register', methods=['POST'])
@limiter.limit("5 per hour")  # 5 registrations per IP per hour
def register():
    # ... registration logic ...
```

---

### 6. **Phone Verification (SMS):**

```python
from twilio.rest import Client

def send_sms_code(phone_number):
    code = generate_6_digit_code()
    
    # Store code temporarily
    redis.setex(f"sms_code:{phone_number}", 300, code)  # 5 min expiry
    
    # Send SMS
    client = Client(TWILIO_SID, TWILIO_TOKEN)
    client.messages.create(
        body=f"Your verification code: {code}",
        from_=TWILIO_NUMBER,
        to=phone_number
    )

def verify_sms_code(phone_number, code):
    stored_code = redis.get(f"sms_code:{phone_number}")
    return stored_code == code
```

---

### 7. **Server-Side Role Assignment:**

```python
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    
    # IGNORE client-provided role
    if 'role' in data:
        del data['role']
    if 'isAdmin' in data:
        del data['isAdmin']
    
    # Assign default role
    user = User(
        username=data['username'],
        email=data['email'],
        password=hash_password(data['password']),
        role='user'  # Always default
    )
    user.save()
```

---

## Fontos Megjegyzések

✅ **Email verification** = minimum requirement  
✅ **CAPTCHA** = bot prevention  
✅ **Rate limiting** = abuse prevention  
✅ **Disposable email block** = fake account prevention  
✅ **Email normalization** = duplicate prevention  
✅ **Phone verification** = stronger identity proof  
✅ **KYC** (Know Your Customer) = banking/financial apps  
❌ **No verification** = weak for sensitive apps!  
❌ **Client-side role** = easily manipulated!  
⚠️ **Email enumeration** = privacy leak!  
⚠️ **Gmail alias** (`+`) = multiple accounts!

---

**Összefoglalva:** Ez a fejezet a **user registration process** teszteléséről szól. **Identity requirements** (email, phone, ID) és **verification** (email link, SMS code, KYC) a **security requirements**-nek megfelelőek legyenek. **Weak registration** = **disposable emails**, **fake data**, **multiple accounts** (Gmail alias: `test+1@gmail.com`), **role injection** (`"role": "admin"`), **bot registration** (no CAPTCHA). **Email/username enumeration** = privacy vulnerability. **Defense**: **email verification**, **CAPTCHA**, **rate limiting**, **disposable email blocking**, **email normalization**, **phone verification** (SMS), **server-side role assignment**. **Banking apps** = **KYC** (document + face verification) required!
