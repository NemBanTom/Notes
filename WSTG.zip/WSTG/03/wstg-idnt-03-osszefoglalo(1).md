# WSTG-IDNT-03: Account Provisioning Process Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **account provisioning** (felhasználó létrehozás) és **de-provisioning** (felhasználó törlés) folyamatok **megfelelően korlátozottak** és **ellenőrzöttek** legyenek. **Weak provisioning control** = **unauthorized account creation**, **privilege escalation**, vagy **account hijacking** de-provisioning után.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM registration testing (IDNT-02)! Ez **internal provisioning** - mely role-ok hozhatnak létre **más user-eket**, milyen **verification** van, és mi történik **de-provisioning** után.

---

## Mi a cél?

**Account provisioning/de-provisioning** controls tesztelése:
- Ki hozhat létre account-okat (mely role-ok)?
- Milyen típusú account-okat hozhatnak létre?
- Van-e verification/authorization a provisioning-hoz?
- Van-e verification/authorization a de-provisioning-hoz?
- Admin létrehozhat-e magasabb privilegiójú user-t?
- User de-provision-elheti-e saját magát?
- Mi történik a user adataival de-provisioning után?

---

## 7 Kritikus Kérdés

### 1. **Which Roles Can Provision Accounts?**

**Kérdés:** Ki hozhat létre új user-eket?

---

**Teszt:**
```bash
# Login as different roles
# Try to access user creation

# Admin
curl https://pelda.hu/admin/users/create -H "Cookie: role=admin"
# → 200 OK (expected)

# Moderator
curl https://pelda.hu/admin/users/create -H "Cookie: role=moderator"
# → Should be 403 Forbidden

# Regular user
curl https://pelda.hu/admin/users/create -H "Cookie: role=user"
# → Should be 403 Forbidden
```

---

**Proper matrix:**

| Role | Can Provision? | What Type? |
|------|----------------|------------|
| Admin | ✓ | Any user type |
| Moderator | ✗ | None |
| Support | ✓ | Basic users only |
| User | ✗ | None |

---

### 2. **What Type of Accounts Can Be Provisioned?**

**Kérdés:** Milyen role-jú account-okat lehet létrehozni?

---

**Teszt:**
```bash
# Admin tries to create another admin
POST /api/users/create HTTP/1.1
Cookie: session=admin_session
Content-Type: application/json

{
  "username": "newadmin",
  "email": "admin@test.com",
  "role": "admin"
}
```

**Kérdés:**
- Engedélyezett?
- Kell-e second approval?
- Van-e MFA?

---

**Scenarios:**

**Scenario A - Admin can create admin (BAD!):**
```
Admin → Creates → Admin (instantly)
No approval needed
No MFA required
→ RISK: Rogue admin can create backup admin accounts
```

---

**Scenario B - Admin needs approval (BETTER):**
```
Admin → Request to create admin
→ Second admin must approve
→ Admin created
→ SAFER: Maker-checker principle
```

---

**Scenario C - Support can only create users:**
```
Support → Can create → Basic users only
Support → Cannot create → Admin, Moderator
→ GOOD: Least privilege
```

---

### 3. **Is Provisioning Verified/Authorized?**

**Kérdés:** Van-e ellenőrzés a provisioning request-nél?

---

**Weak (No verification):**
```python
@app.route('/admin/users/create', methods=['POST'])
@require_role('admin')
def create_user():
    data = request.json
    user = User(**data)
    user.save()
    return "User created"
```

→ Admin létrehozhat bárkit, azonnal, ellenőrzés nélkül!

---

**Better (Approval required):**
```python
@app.route('/admin/users/create', methods=['POST'])
@require_role('admin')
def create_user():
    data = request.json
    
    # If creating admin, require approval
    if data.get('role') == 'admin':
        approval = ApprovalRequest(
            type='create_admin',
            data=data,
            requestor=current_user,
            status='pending'
        )
        approval.save()
        return "Approval required"
    
    # Regular users can be created directly
    user = User(**data)
    user.save()
    return "User created"
```

---

### 4. **Is De-Provisioning Verified?**

**Kérdés:** Van-e ellenőrzés account törléskor?

---

**Teszt:**
```bash
# Try to delete user
DELETE /api/users/123 HTTP/1.1
Cookie: session=admin_session
```

**Kérdések:**
- Azonnal törölhető?
- Kell-e confirmation?
- Kell-e second approval?
- Van-e MFA?

---

**Weak:**
```
DELETE /api/users/123
→ User deleted instantly
No confirmation
No audit log
```

---

**Better:**
```
DELETE /api/users/123
→ Are you sure? (confirmation required)
→ MFA code required
→ User marked for deletion
→ Actual deletion after 30 days (grace period)
→ Audit log entry created
```

---

### 5. **Can Admin Provision Higher Privilege?**

**Kérdés:** Admin létrehozhat-e nála magasabb privilegiójú user-t?

---

**Teszt:**
```bash
# Admin tries to create Super Admin
POST /api/users/create HTTP/1.1
Cookie: session=admin_session
{
  "username": "superadmin",
  "role": "superadmin"
}
```

**Ha sikeres:**
→ **CRITICAL!** Privilege escalation!

---

**Proper hierarchy:**
```
Super Admin (level 3)
  ↓ can create
Admin (level 2)
  ↓ can create
User (level 1)

Admin (level 2) CANNOT create Super Admin (level 3)
```

---

**Secure implementation:**
```python
def can_provision(provisioner_role, target_role):
    role_hierarchy = {
        'user': 1,
        'moderator': 2,
        'admin': 3,
        'superadmin': 4
    }
    
    provisioner_level = role_hierarchy.get(provisioner_role, 0)
    target_level = role_hierarchy.get(target_role, 0)
    
    # Can only provision equal or lower level
    return provisioner_level >= target_level

if not can_provision(current_user.role, data['role']):
    return "Insufficient privileges", 403
```

---

### 6. **Can User De-Provision Themselves?**

**Kérdés:** User törölheti-e saját account-ját?

---

**Scenario A - User CAN delete self:**
```
Pros:
- User privacy (right to delete)
- GDPR compliance

Cons:
- Data loss
- Potential abuse
- Accidental deletion
```

---

**Scenario B - User CANNOT delete self:**
```
Pros:
- Prevents accidental deletion
- Data retention

Cons:
- GDPR violation?
- User has no control
```

---

**Best practice:**
```
User can REQUEST deletion:
1. User clicks "Delete Account"
2. Confirmation email sent
3. User clicks confirmation link
4. Account marked for deletion
5. 30-day grace period
6. Account actually deleted after 30 days

Admin can DELETE immediately (with MFA)
```

---

**Admin self-deletion test:**
```bash
# Admin tries to delete own account
DELETE /api/users/me HTTP/1.1
Cookie: session=admin_session
```

**Should:**
- Require MFA
- Require second admin confirmation
- Transfer ownership of resources
- Not allowed if last admin!

---

### 7. **What Happens to User's Data After De-Provisioning?**

**Kérdés:** Mi történik a user file-jaival, post-jaival, resource-aival?

---

**Option A - Delete everything:**
```
User deleted → All posts deleted
→ RISKY: Data loss, broken references
```

---

**Option B - Transfer to another user:**
```
User deleted → Posts transferred to Admin
→ BETTER: Data preserved
```

---

**Option C - Anonymize:**
```
User deleted → Posts kept
→ Author changed to "Deleted User"
→ BEST: Data preserved, privacy protected
```

---

**WordPress példa:**

**De-provisioning dialog:**
```
Delete user "john"?

What to do with content:
○ Delete all content
○ Transfer content to: [dropdown: select user]

[Cancel] [Confirm Deletion]
```

---

## Provisioning Attack Scenarios

### Attack #1: **Unauthorized Account Creation**

**Scenario:**
```
Regular user → Intercepts admin provisioning request
→ Modifies request to create account
→ Account created without authorization
```

---

**Teszt:**
```bash
# Login as regular user
# Intercept admin's provisioning request (Burp)

# Original request (admin):
POST /api/users/create HTTP/1.1
Cookie: session=admin_session_abc
{
  "username": "newuser",
  "role": "user"
}

# Modify session to regular user:
POST /api/users/create HTTP/1.1
Cookie: session=user_session_xyz
{
  "username": "newuser",
  "role": "user"
}
```

**Ha sikeres:**
→ User can create accounts!

---

### Attack #2: **Role Escalation During Provisioning**

**Scenario:**
```
Support engineer → Creates user
→ Modifies role parameter to "admin"
→ Admin account created
```

---

**Teszt:**
```bash
# Support tries to create admin
POST /api/users/create HTTP/1.1
Cookie: session=support_session
{
  "username": "backdoor",
  "role": "admin"  ← Support shouldn't be able to!
}
```

**Ha sikeres:**
→ **CRITICAL!** Support can create admins!

---

### Attack #3: **Mass Account Creation**

**Scenario:**
```
Attacker → Compromises admin account
→ Automated script creates 10,000 accounts
→ System overload / abuse
```

---

**Teszt:**
```bash
# No rate limiting on provisioning
for i in {1..10000}; do
  curl -X POST https://pelda.hu/api/users/create \
    -H "Cookie: session=admin" \
    -d "{\"username\":\"user$i\",\"email\":\"user$i@spam.com\"}"
done
```

**Ha nincs rate limit:**
→ Mass provisioning abuse!

---

### Attack #4: **Account Hijacking via De-Provisioning**

**Scenario:**
```
User deleted → Email released
→ Attacker registers with same email
→ "Forgot password" for old accounts
→ Gains access to old data
```

---

**Teszt:**
```bash
# 1. Admin deletes user (email: victim@test.com)
DELETE /api/users/123

# 2. Attacker registers with same email
POST /api/register -d "email=victim@test.com&..."

# 3. Password reset for other services
# "Forgot password" → Email sent to victim@test.com
# Attacker receives it!
```

**Prevention:** Email cooldown period (can't re-register for 90 days)

---

## Testing with Burp Suite

### Intercept Provisioning Request:

```
1. Login as admin
2. Burp → Proxy → Intercept On
3. Navigate to "Create User"
4. Fill form, submit
5. Intercept request
```

---

### Modify Role Parameter:

**Original:**
```http
POST /admin/users/create HTTP/1.1
Content-Type: application/json

{
  "username": "testuser",
  "email": "test@test.com",
  "role": "user"
}
```

---

**Modified (create admin):**
```http
{
  "username": "testuser",
  "email": "test@test.com",
  "role": "admin"     ← Changed!
}
```

**Forward → Check if accepted**

---

### Test Authorization Bypass:

**Original (admin session):**
```
Cookie: session=admin_abc123
```

---

**Modified (regular user session):**
```
Cookie: session=user_xyz789
```

**Forward → Check if provisioning succeeds**

---

## Comprehensive Testing Checklist

### Provisioning Tests:
```
☐ Which roles can provision accounts?
☐ What account types can each role provision?
☐ Can admin provision other admins?
☐ Can support provision admins?
☐ Is second approval required for admin creation?
☐ Is MFA required for privileged account creation?
☐ Rate limiting on account provisioning?
☐ Audit logging of provisioning actions?
```

---

### De-Provisioning Tests:
```
☐ Which roles can delete accounts?
☐ Can user delete own account?
☐ Can admin delete own account?
☐ What happens to user data? (delete/transfer/anonymize)
☐ Is confirmation required?
☐ Is MFA required?
☐ Grace period before actual deletion?
☐ Can deleted email be re-registered immediately?
☐ Audit logging of de-provisioning?
```

---

### Privilege Escalation Tests:
```
☐ Can lower-privilege role create higher-privilege?
☐ Can regular user provision accounts?
☐ Can role parameter be manipulated?
☐ Can provisioner assign higher role than own?
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Provision as admin | `POST /api/users -H "Cookie: admin_session" -d '{...}'` |
| Provision as user | `POST /api/users -H "Cookie: user_session" -d '{...}'` |
| Create admin account | `-d '{"role": "admin"}'` |
| Delete user | `DELETE /api/users/123` |
| Delete self | `DELETE /api/users/me` |
| Role escalation | Modify `role` param to `admin` |
| Mass provisioning | Loop 1000+ create requests |

---

## Fontos Toolok

### Manual:
- **curl** - API testing
- **Browser DevTools** - Form inspection

### Proxy:
- **Burp Suite** - Request interception/modification
- **ZAP** - Automated scanning

### Automation:
- **Python scripts** - Mass provisioning testing

---

## Védelem (Remediation)

### 1. **Role-Based Provisioning Control:**

```python
PROVISIONING_MATRIX = {
    'admin': ['admin', 'moderator', 'user'],
    'support': ['user'],
    'user': []  # Cannot provision
}

def can_provision_role(provisioner_role, target_role):
    allowed = PROVISIONING_MATRIX.get(provisioner_role, [])
    return target_role in allowed

@app.route('/api/users/create', methods=['POST'])
@require_role('admin', 'support')
def create_user():
    data = request.json
    target_role = data.get('role', 'user')
    
    if not can_provision_role(current_user.role, target_role):
        return "Cannot provision that role", 403
    
    user = User(**data)
    user.save()
```

---

### 2. **Maker-Checker for Admin Provisioning:**

```python
@app.route('/api/users/create', methods=['POST'])
@require_role('admin')
def create_user():
    data = request.json
    
    # Admin creation requires approval
    if data['role'] == 'admin':
        request = ProvisioningRequest(
            type='create_admin',
            data=data,
            requestor=current_user,
            status='pending'
        )
        request.save()
        
        # Notify other admins
        notify_admins("Admin provisioning approval needed")
        
        return "Approval required", 202
    
    # Regular users created directly
    user = User(**data)
    user.save()
    return "User created", 201
```

---

### 3. **MFA for Critical Provisioning:**

```python
@app.route('/api/users/create', methods=['POST'])
@require_role('admin')
@require_mfa  # MFA decorator
def create_user():
    # Verify MFA
    if not verify_mfa_token(request.headers.get('X-MFA-Token')):
        return "MFA required", 403
    
    # Proceed with provisioning
    user = User(**data)
    user.save()
```

---

### 4. **Rate Limiting:**

```python
from flask_limiter import Limiter

limiter = Limiter(app, key_func=lambda: current_user.id)

@app.route('/api/users/create', methods=['POST'])
@limiter.limit("10 per hour")  # Max 10 users per hour
def create_user():
    # ... provisioning logic ...
```

---

### 5. **Soft Delete with Grace Period:**

```python
@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@require_role('admin')
def delete_user(user_id):
    user = User.query.get(user_id)
    
    # Don't actually delete, mark as deleted
    user.deleted_at = datetime.utcnow()
    user.deleted_by = current_user.id
    user.save()
    
    # Schedule actual deletion after 30 days
    schedule_task('delete_user_permanently', user_id, delay_days=30)
    
    return "User marked for deletion (30 day grace period)"
```

---

### 6. **Data Transfer on De-Provisioning:**

```python
@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    user = User.query.get(user_id)
    transfer_to_id = request.json.get('transfer_to')
    
    if transfer_to_id:
        # Transfer ownership
        user.posts.update(author_id=transfer_to_id)
        user.files.update(owner_id=transfer_to_id)
    else:
        # Anonymize
        user.posts.update(author_id=None, author_name="Deleted User")
    
    user.delete()
```

---

### 7. **Email Re-Registration Prevention:**

```python
DELETED_EMAILS_COOLDOWN = {}  # Or use Redis

@app.route('/api/register', methods=['POST'])
def register():
    email = request.json['email']
    
    # Check if email was recently deleted
    deleted_at = DELETED_EMAILS_COOLDOWN.get(email)
    if deleted_at:
        cooldown_end = deleted_at + timedelta(days=90)
        if datetime.utcnow() < cooldown_end:
            return "Email cannot be re-registered yet", 403
    
    # Proceed with registration
    user = User(**data)
    user.save()

@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    user = User.query.get(user_id)
    
    # Record deletion timestamp
    DELETED_EMAILS_COOLDOWN[user.email] = datetime.utcnow()
    
    user.delete()
```

---

## Fontos Megjegyzések

✅ **Maker-checker** = two admins for admin provisioning  
✅ **MFA** for privileged account creation  
✅ **Rate limiting** = prevent mass provisioning  
✅ **Soft delete** = grace period before actual deletion  
✅ **Data transfer** = don't lose content on de-provisioning  
✅ **Email cooldown** = prevent hijacking via re-registration  
✅ **Audit logging** = who provisioned/de-provisioned whom  
❌ **Admin can create admin instantly** = risky!  
❌ **No confirmation for delete** = accidental deletion!  
⚠️ **Support can create admin** = privilege escalation!  
⚠️ **Deleted email immediately available** = hijacking risk!

---

**Összefoglalva:** Ez a fejezet az **account provisioning/de-provisioning** teszteléséről szól. **Ki hozhat létre account-okat** (admin, support, user?), **milyen role-jú user-eket**, és **van-e verification**. **Admin létrehozhat-e másik admin-t** → **maker-checker** + **MFA** kell! **Support ne hozhasson létre admin-t** (privilege escalation). **De-provisioning**: **soft delete** (grace period), **data transfer/anonymize**, **email cooldown** (90 days) re-registration ellen. **User törölheti-e saját magát** → **confirmation** + **grace period**. **WordPress példa**: delete user → transfer or delete content. **Rate limiting** mass provisioning ellen. **Audit logging** minden provisioning/de-provisioning action-re!
