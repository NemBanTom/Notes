# WSTG-IDNT-04: Account Enumeration és Guessable User Account Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **account enumeration** (felhasználó felsorolás) vulnerability-k hogyan fedezhetők fel, ahol az **alkalmazás response-ai** (error messages, HTTP codes, timing) **felfedik**, hogy egy **username létezik-e** vagy sem. Ez **brute-force attack-okat** tesz lehetővé, mivel az attacker **valid username list-et** készíthet.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM brute-force testing! Ez **username enumeration** - megállapítani, mely username-ek léteznek **különböző response-ok** alapján.

---

## Mi a cél?

**Username enumeration** vulnerability-k azonosítása:
- Different error messages (valid vs invalid user)
- Different HTTP response codes
- Different response lengths
- Different response times
- URL redirections revealing user existence

---

## Username Enumeration Concept

### Vulnerable Application:

```
Login with valid username + wrong password:
→ "Invalid password for user john"

Login with invalid username + wrong password:
→ "User does not exist"
```

→ **VULNERABLE!** Attacker knows "john" exists!

---

### Secure Application:

```
Login with valid username + wrong password:
→ "Invalid credentials"

Login with invalid username + wrong password:
→ "Invalid credentials"
```

→ **Same message** → No enumeration!

---

## Testing Scenarios

### Scenario #1: **Different Error Messages**
### Scenario #2: **Different HTTP Response Codes**
### Scenario #3: **Different Response Lengths**
### Scenario #4: **Different Response Times**
### Scenario #5: **URL Redirections**
### Scenario #6: **URI Probing**
### Scenario #7: **Recovery Facility**
### Scenario #8: **Reserved Username Testing**

---

## Scenario #1: Different Error Messages

### Test: **Valid User + Wrong Password**

```bash
curl -X POST https://pelda.hu/login \
  -d "username=admin&password=wrongpass"
```

**Vulnerable response:**
```
"Login for User admin: invalid password"
```

→ Reveals "admin" exists!

---

### Test: **Invalid User + Wrong Password**

```bash
curl -X POST https://pelda.hu/login \
  -d "username=nonexistent&password=wrongpass"
```

**Vulnerable response:**
```
"Login failed for User nonexistent: invalid account"
```

→ Reveals "nonexistent" does NOT exist!

---

### Enumeration Attack:

```bash
# Test multiple usernames
for user in admin administrator root test; do
  response=$(curl -s -X POST https://pelda.hu/login \
    -d "username=$user&password=test")
  
  if echo "$response" | grep -q "invalid password"; then
    echo "FOUND: $user exists!"
  else
    echo "NOT FOUND: $user"
  fi
done
```

---

### Secure Response (Same for Both):

```
Valid user + wrong password:
→ "Invalid credentials"

Invalid user + wrong password:
→ "Invalid credentials"
```

→ **No enumeration possible!**

---

## Scenario #2: Different HTTP Response Codes

### Vulnerable Application:

```bash
# Valid username
curl -I -X POST https://pelda.hu/login \
  -d "username=admin&password=wrong"
# → HTTP/1.1 401 Unauthorized

# Invalid username
curl -I -X POST https://pelda.hu/login \
  -d "username=fake&password=wrong"
# → HTTP/1.1 404 Not Found
```

→ **Different codes** = enumeration!

---

### Secure Application:

```bash
# Both return same code
curl -I -X POST https://pelda.hu/login \
  -d "username=admin&password=wrong"
# → HTTP/1.1 401 Unauthorized

curl -I -X POST https://pelda.hu/login \
  -d "username=fake&password=wrong"
# → HTTP/1.1 401 Unauthorized
```

→ **Same code** = no enumeration

---

## Scenario #3: Different Response Lengths

### Vulnerable Application:

```bash
# Valid username
response1=$(curl -s -X POST https://pelda.hu/login \
  -d "username=admin&password=wrong")
echo ${#response1}  # Length: 1234 bytes

# Invalid username
response2=$(curl -s -X POST https://pelda.hu/login \
  -d "username=fake&password=wrong")
echo ${#response2}  # Length: 987 bytes
```

→ **Different lengths** = enumeration!

---

**Automated test:**
```bash
for user in admin root test fake; do
  response=$(curl -s -X POST https://pelda.hu/login \
    -d "username=$user&password=test")
  length=${#response}
  echo "$user: $length bytes"
done
```

**Output:**
```
admin: 1234 bytes  ← Exists
root: 1234 bytes   ← Exists
test: 987 bytes    ← Doesn't exist
fake: 987 bytes    ← Doesn't exist
```

---

## Scenario #4: Different Response Times

### Concept:
**Valid username** → queries database, checks password hash  
**Invalid username** → returns immediately (no DB query)

---

### Test:

```bash
# Measure response time
time curl -X POST https://pelda.hu/login \
  -d "username=admin&password=wrong"
# → real 0m0.350s (valid user, password check)

time curl -X POST https://pelda.hu/login \
  -d "username=fake&password=wrong"
# → real 0m0.050s (invalid user, immediate return)
```

→ **Different timing** = enumeration!

---

**Automated timing test:**
```bash
for user in admin root test fake; do
  start=$(date +%s%N)
  curl -s -X POST https://pelda.hu/login \
    -d "username=$user&password=test" > /dev/null
  end=$(date +%s%N)
  elapsed=$(( (end - start) / 1000000 ))
  echo "$user: ${elapsed}ms"
done
```

**Output:**
```
admin: 350ms  ← Valid (password check)
root: 340ms   ← Valid (password check)
test: 50ms    ← Invalid (immediate)
fake: 45ms    ← Invalid (immediate)
```

---

## Scenario #5: URL Redirections

### Vulnerable Application:

**Valid username:**
```
POST /login (username=admin, password=wrong)
→ Redirect to: /error?user=admin&error=InvalidPassword
```

**Invalid username:**
```
POST /login (username=fake, password=wrong)
→ Redirect to: /error?user=fake&error=InvalidUser
```

→ **Different error codes** in URL = enumeration!

---

**Test:**
```bash
curl -i -X POST https://pelda.hu/login \
  -d "username=admin&password=wrong" | grep Location

# Location: /error?user=admin&error=InvalidPassword
```

---

## Scenario #6: URI Probing

### Concept:
**User directories** or **profile pages** reveal user existence via **HTTP codes**.

---

### Test:

```bash
# Check user profile pages
curl -I https://pelda.hu/users/admin
# → 403 Forbidden (exists but no access)

curl -I https://pelda.hu/users/fake
# → 404 Not Found (doesn't exist)
```

→ **403 = exists, 404 = doesn't exist**

---

**Automated:**
```bash
for user in admin root moderator fake test; do
  code=$(curl -s -o /dev/null -w "%{http_code}" \
    https://pelda.hu/users/$user)
  
  if [ "$code" == "403" ]; then
    echo "FOUND: $user exists (403)"
  elif [ "$code" == "404" ]; then
    echo "NOT FOUND: $user (404)"
  fi
done
```

---

## Scenario #7: Recovery Facility (Forgot Password)

### Vulnerable Application:

**Valid email:**
```bash
POST /forgot-password (email=admin@company.com)
→ "Password reset link sent to admin@company.com"
```

**Invalid email:**
```bash
POST /forgot-password (email=fake@fake.com)
→ "Email address not found"
```

→ **Different messages** = email enumeration!

---

### Test:

```bash
curl -X POST https://pelda.hu/forgot-password \
  -d "email=admin@company.com"
# → "Password reset link sent"

curl -X POST https://pelda.hu/forgot-password \
  -d "email=fake@fake.com"
# → "Email not found"
```

---

### Secure Response:

```
Valid or invalid email:
→ "If your email is registered, you will receive a password reset link"
```

→ **Same message** for both!

---

## Scenario #8: Reserved Username Testing (Staff Impersonation)

### Test: **Registration with Reserved Username**

```bash
# Try to register as "admin"
curl -X POST https://pelda.hu/register \
  -d "username=admin&email=test@test.com&password=pass"
```

**Vulnerable:**
```
"Registration successful"
→ Can register as "admin"!
```

**Secure:**
```
"Username 'admin' is reserved and cannot be used"
```

---

### Test: **Profile Edit with Reserved Username**

```bash
# Login as regular user
# Try to change username to "admin"
curl -X PUT https://pelda.hu/api/profile \
  -H "Cookie: session=user_session" \
  -d '{"username": "admin"}'
```

**Vulnerable:**
```
"Username updated"
→ User can become "admin"!
```

**Secure:**
```
"Username 'admin' is reserved"
```

---

### Test: **Case Variations**

```bash
# Try variations
curl -X POST /register -d "username=admin&..."      # lowercase
curl -X POST /register -d "username=Admin&..."      # capitalize
curl -X POST /register -d "username=ADMIN&..."      # uppercase
curl -X POST /register -d "username=AdMiN&..."      # mixed
curl -X POST /register -d "username=administrator&..."
curl -X POST /register -d "username=moderator&..."
```

**All should be rejected!**

---

## Guessable User Accounts

### Pattern #1: **Sequential User IDs**

```
CN000100
CN000101
CN000102
...
```

**Enumeration:**
```bash
for i in {100..200}; do
  user="CN0001$i"
  curl -s -X POST /login -d "username=$user&password=test" | grep -q "invalid password"
  if [ $? -eq 0 ]; then
    echo "FOUND: $user"
  fi
done
```

---

### Pattern #2: **REALM + Sequential**

```
R1001 - user 001 for REALM1
R1002 - user 002 for REALM1
R2001 - user 001 for REALM2
```

**Guess:**
```bash
for realm in R1 R2 R3; do
  for num in {001..100}; do
    user="${realm}${num}"
    # Test $user
  done
done
```

---

### Pattern #3: **Credit Card Pattern**

```
Users: 4111111111111111, 4222222222222222, ...
```

---

### Pattern #4: **Real Names**

```
Freddie Mercury → fmercury
Roger Taylor → rtaylor
John Deacon → jdeacon
```

**LDAP query:**
```bash
ldapsearch -x -b "dc=company,dc=com" "(cn=*)" cn mail
```

**Google dorking:**
```
site:company.com intext:"@company.com"
```

---

## Comprehensive Testing Workflow

### 1. **Login Page Testing:**

```bash
# Test 1: Valid user + wrong pass
curl -X POST /login -d "username=admin&password=wrong"
# Note: message, code, length, time

# Test 2: Invalid user + wrong pass
curl -X POST /login -d "username=fake&password=wrong"
# Note: message, code, length, time

# Compare responses
```

---

### 2. **Forgot Password Testing:**

```bash
# Test with valid email
curl -X POST /forgot-password -d "email=admin@company.com"

# Test with invalid email
curl -X POST /forgot-password -d "email=fake@fake.com"

# Compare messages
```

---

### 3. **Registration Testing:**

```bash
# Try to register existing username
curl -X POST /register -d "username=admin&email=new@test.com&..."

# Check error message
```

---

### 4. **URI Probing:**

```bash
# Check user profile pages
for user in admin root moderator test; do
  curl -I /users/$user
done
```

---

### 5. **Timing Analysis:**

```bash
# Measure response times
for user in admin fake test; do
  time curl -X POST /login -d "username=$user&password=test"
done
```

---

## Automated Tools

### Tool: **Burp Suite Intruder**

```
1. Intercept login request
2. Send to Intruder
3. Mark username parameter
4. Load wordlist (common usernames)
5. Start attack
6. Analyze responses:
   - Different lengths?
   - Different messages?
   - Different codes?
```

---

### Tool: **ffuf (Username Fuzzing)**

```bash
# Username enumeration via login
ffuf -u https://pelda.hu/login \
  -X POST \
  -d "username=FUZZ&password=test" \
  -w usernames.txt \
  -mr "invalid password"  # Match regex

# Usernames that match "invalid password" exist!
```

---

### Tool: **Hydra (with grep)**

```bash
# Not for brute-force, but enumeration
hydra -L usernames.txt -p test pelda.hu http-post-form \
  "/login:username=^USER^&password=^PASS^:F=invalid password"
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Login valid user | `curl -X POST /login -d "username=admin&password=wrong"` |
| Login invalid user | `curl -X POST /login -d "username=fake&password=wrong"` |
| Measure timing | `time curl -X POST /login -d "..."` |
| Check response length | `curl -s ... \| wc -c` |
| URI probing | `curl -I /users/admin` |
| Forgot password | `curl -X POST /forgot-password -d "email=..."` |
| Reserved username | `curl -X POST /register -d "username=admin&..."` |

---

## Fontos Toolok

### Manual:
- **curl** - HTTP requests + timing
- **time** - Response time measurement

### Fuzzing:
- **ffuf** - Username fuzzing
- **wfuzz** - Web fuzzer

### Proxy:
- **Burp Suite Intruder** - Automated enumeration
- **ZAP** - Active scan

### Scripts:
- **Bash scripts** - Custom enumeration
- **Python** - Advanced analysis

---

## Védelem (Remediation)

### 1. **Consistent Error Messages:**

**BAD:**
```python
if user.exists():
    if not user.check_password(password):
        return "Invalid password"
else:
    return "User not found"
```

**GOOD:**
```python
user = User.query.filter_by(username=username).first()
if not user or not user.check_password(password):
    return "Invalid credentials"  # Same message!
```

---

### 2. **Constant-Time Password Check:**

```python
import hmac

def check_password(stored_hash, provided_password):
    provided_hash = hash_password(provided_password)
    # Constant-time comparison
    return hmac.compare_digest(stored_hash, provided_hash)
```

→ Prevents timing attacks

---

### 3. **Rate Limiting:**

```python
from flask_limiter import Limiter

limiter = Limiter(app, key_func=lambda: request.remote_addr)

@app.route('/login', methods=['POST'])
@limiter.limit("5 per minute")  # Max 5 login attempts
def login():
    # ... login logic ...
```

---

### 4. **CAPTCHA After Failed Attempts:**

```python
@app.route('/login', methods=['POST'])
def login():
    # Check failed attempts
    attempts = get_failed_attempts(request.remote_addr)
    
    if attempts >= 3:
        # Require CAPTCHA
        if not verify_captcha(request.form['captcha']):
            return "CAPTCHA required", 403
    
    # ... login logic ...
```

---

### 5. **Forgot Password - Same Response:**

```python
@app.route('/forgot-password', methods=['POST'])
def forgot_password():
    email = request.form['email']
    user = User.query.filter_by(email=email).first()
    
    if user:
        send_reset_email(user)
    
    # SAME response regardless
    return "If your email is registered, you will receive a reset link"
```

---

### 6. **Reserved Username Blacklist:**

```python
RESERVED_USERNAMES = [
    'admin', 'administrator', 'moderator', 'mod',
    'root', 'superuser', 'super', 'staff',
    'support', 'helpdesk', 'webmaster'
]

def is_reserved(username):
    return username.lower() in RESERVED_USERNAMES

@app.route('/register', methods=['POST'])
def register():
    username = request.json['username']
    
    if is_reserved(username):
        return "Username is reserved", 400
    
    # ... registration logic ...
```

---

### 7. **Account Lockout (Caution!):**

```python
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    
    # Increment failed attempts
    increment_failed_attempts(username)
    
    # Check if locked
    if is_account_locked(username):
        return "Account temporarily locked", 403
    
    # ... login logic ...
    
    # On success, reset failed attempts
    reset_failed_attempts(username)
```

**⚠️ CAUTION:** Account lockout can enable **DoS** (attacker locks out users)!

---

## Fontos Megjegyzések

✅ **Consistent error messages** = no enumeration  
✅ **Same response length** for all failures  
✅ **Same response time** (constant-time checks)  
✅ **Rate limiting** = prevents mass enumeration  
✅ **CAPTCHA** after 3 failed attempts  
✅ **Reserved username blacklist** (admin, root, etc.)  
❌ **"Invalid password"** vs **"User not found"** = enumeration!  
❌ **403 vs 404** = URI probing enumeration!  
❌ **Different timing** = timing-based enumeration!  
⚠️ **Account lockout** can cause DoS!  
⚠️ **Recovery facility** often leaks user existence!

---

**Összefoglalva:** Ez a fejezet az **account enumeration** vulnerability-k teszteléséről szól. **Different error messages** ("Invalid password" vs "User not found"), **HTTP codes** (403 vs 404), **response lengths**, vagy **response times** mind **felfedhetik**, hogy egy **username létezik-e**. **URI probing** (`/users/admin` → 403 = exists), **forgot password** ("Email not found"), és **reserved username** testing (register as "admin"). **Guessable patterns** (sequential IDs, real names). **Defense**: **consistent error messages** ("Invalid credentials"), **constant-time password checks**, **rate limiting**, **CAPTCHA**, **reserved username blacklist**. **Burp Intruder** és **ffuf** automated enumeration-höz!
