# WSTG-IDNT-05: Weak vagy Unenforced Username Policy Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **predictable username structure** (pl. jsmith, fnurks) és **weak username policy** lehetővé teszi a **username enumeration**-t és **brute-force attack**-okat. Ha a **username pattern** könnyen kitalálható, akkor az attacker **valid username list-et** generálhat **társadalmi forrásokból** (LDAP, LinkedIn, email címek).

⚠️ **NE KEVERD ÖSSZE:** Ez szorosan kapcsolódik az IDNT-04-hez (Account Enumeration), de specifikusan a **username policy weakness**-re fókuszál - milyen **pattern-ek** léteznek és hogyan **exploitálhatók**.

---

## Mi a cél?

**Username policy** gyengeségeinek azonosítása:
- Consistent account name structure (predictable pattern)
- Weak username rules (too short, simple)
- Guessable username generation logic
- Enumeration via error messages

---

## Username Structure Patterns

### Pattern #1: **FirstLast Pattern**

**Szabály:** `[first_initial][lastname]`

**Példák:**
```
Joe Bloggs → jbloggs
Fred Nurks → fnurks
John Smith → jsmith
Sarah Connor → sconnor
```

**Exploitation:**
```bash
# Given employee list:
# - Alice Anderson
# - Bob Brown
# - Charlie Clark

# Generate usernames:
usernames=(
  "aanderson"
  "bbrown"
  "cclark"
)

# Test each
for user in "${usernames[@]}"; do
  curl -X POST /login -d "username=$user&password=test"
done
```

---

### Pattern #2: **First.Last Pattern**

**Szabály:** `[firstname].[lastname]`

**Példák:**
```
Joe Bloggs → joe.bloggs
John Smith → john.smith
Sarah Connor → sarah.connor
```

**Exploitation:**
```bash
# LinkedIn scraping:
# Company employees: Joe Bloggs, Sarah Connor

usernames=(
  "joe.bloggs"
  "sarah.connor"
)
```

---

### Pattern #3: **FirstInitialLastname Pattern**

**Szabály:** `[first_initial][lastname]`

**Példák:**
```
Joe Bloggs → jbloggs
Sarah Connor → sconnor
Michael Johnson → mjohnson
```

---

### Pattern #4: **EmailPrefix Pattern**

**Szabály:** Username = email prefix

**Példák:**
```
Email: john.smith@company.com
Username: john.smith

Email: jsmith@company.com
Username: jsmith
```

**Exploitation:**
```bash
# Email harvesting
# Hunter.io, LinkedIn, company website

# Extract email prefixes
emails=(
  "john.smith@company.com"
  "sarah.connor@company.com"
)

for email in "${emails[@]}"; do
  username=$(echo $email | cut -d'@' -f1)
  # Test: $username
done
```

---

### Pattern #5: **Employee ID Pattern**

**Szabály:** `EMP[sequential_number]`

**Példák:**
```
EMP001
EMP002
EMP003
...
EMP999
```

**Exploitation:**
```bash
# Brute-force all IDs
for i in {001..999}; do
  user="EMP$i"
  curl -X POST /login -d "username=$user&password=test"
done
```

---

### Pattern #6: **Department + Number**

**Szabály:** `[dept][number]`

**Példák:**
```
IT001, IT002, IT003  (IT department)
HR001, HR002         (HR department)
FIN001, FIN002       (Finance)
```

---

## Username Discovery Methods

### Method #1: **LDAP Enumeration**

```bash
# Anonymous LDAP bind
ldapsearch -x -H ldap://company.com -b "dc=company,dc=com" "(objectClass=person)" cn mail sAMAccountName
```

**Output:**
```
dn: cn=John Smith,ou=Users,dc=company,dc=com
cn: John Smith
mail: john.smith@company.com
sAMAccountName: jsmith

dn: cn=Sarah Connor,ou=Users,dc=company,dc=com
cn: Sarah Connor
mail: sarah.connor@company.com
sAMAccountName: sconnor
```

**Pattern detected:** `[first_initial][lastname]`

---

### Method #2: **Email Harvesting (Hunter.io)**

**Website:** https://hunter.io/

```
Search: company.com

Results:
john.smith@company.com
sarah.connor@company.com
mike.johnson@company.com

Pattern: [firstname].[lastname]
```

**Enumerate usernames:**
```bash
# Extract prefixes
usernames=(
  "john.smith"
  "sarah.connor"
  "mike.johnson"
)
```

---

### Method #3: **LinkedIn Scraping**

```
Company: Acme Corp
Employees:
- John Smith (Software Engineer)
- Sarah Connor (Manager)
- Bob Anderson (Developer)
```

**Generate usernames based on detected pattern:**
```
john.smith / jsmith
sarah.connor / sconnor
bob.anderson / banderson
```

---

### Method #4: **Google Dorking**

```
site:company.com intext:"@company.com"
site:company.com filetype:pdf "email"
```

**Found emails:**
```
john.smith@company.com
sarah.connor@company.com
```

---

### Method #5: **GitHub/GitLab Commits**

```bash
# Check commit history
git log --all --format='%an <%ae>' | sort -u
```

**Output:**
```
John Smith <jsmith@company.com>
Sarah Connor <sconnor@company.com>
```

**Pattern:** `[first_initial][lastname]`

---

## Pattern Detection Workflow

### Step 1: **Gather Sample Usernames**

**Sources:**
- Company website
- LinkedIn
- Email addresses
- LDAP (if accessible)
- Public documents (PDFs, etc.)

---

### Step 2: **Analyze Pattern**

**Example dataset:**
```
jsmith (John Smith)
sconnor (Sarah Connor)
banderson (Bob Anderson)
mjohnson (Mike Johnson)
```

**Pattern:** `[first_initial][lastname]`

---

### Step 3: **Generate Username List**

```python
# Python script
def generate_username(first, last):
    return f"{first[0].lower()}{last.lower()}"

employees = [
    ("John", "Smith"),
    ("Sarah", "Connor"),
    ("Bob", "Anderson"),
    ("Mike", "Johnson"),
    ("Alice", "Williams")
]

usernames = [generate_username(f, l) for f, l in employees]
print(usernames)
# ['jsmith', 'sconnor', 'banderson', 'mjohnson', 'awilliams']
```

---

### Step 4: **Validate Usernames**

```bash
# Test each generated username
for user in jsmith sconnor banderson mjohnson awilliams; do
  response=$(curl -s -X POST https://company.com/login \
    -d "username=$user&password=test")
  
  if echo "$response" | grep -q "invalid password"; then
    echo "✓ VALID: $user"
  else
    echo "✗ INVALID: $user"
  fi
done
```

---

## Weak Username Policy Issues

### Issue #1: **Too Short Usernames**

**Policy:** Minimum 3 characters

**Weakness:**
```
Allows: "joe", "bob", "sam"
→ Easy to brute-force!
```

**Better:** Minimum 6 characters

---

### Issue #2: **Simple Sequential Usernames**

**Pattern:**
```
user1
user2
user3
...
user10000
```

**Exploitation:**
```bash
for i in {1..10000}; do
  curl -X POST /login -d "username=user$i&password=test"
done
```

---

### Issue #3: **Predictable Test Accounts**

**Common test usernames:**
```
test
test1
testuser
demo
guest
admin
```

**Check:**
```bash
for user in test test1 testuser demo guest admin; do
  curl -X POST /login -d "username=$user&password=test"
done
```

---

### Issue #4: **No Username Uniqueness Check**

**Weakness:** Same username with different case

```
Register: "john" (lowercase)
Register: "John" (capitalized)
Register: "JOHN" (uppercase)

If all allowed:
→ 3 different accounts!
```

**Better:** Case-insensitive uniqueness check

---

## Advanced Pattern Detection

### Tool: **Pattern Analysis Script**

```python
#!/usr/bin/env python3
import re

# Sample usernames
usernames = [
    "jsmith",
    "sconnor",
    "banderson",
    "mjohnson",
    "awilliams"
]

# Full names (from LinkedIn, etc.)
full_names = [
    "John Smith",
    "Sarah Connor",
    "Bob Anderson",
    "Mike Johnson",
    "Alice Williams"
]

# Analyze pattern
def detect_pattern(usernames, full_names):
    for i, username in enumerate(usernames):
        first, last = full_names[i].split()
        
        # Check patterns
        if username == f"{first[0].lower()}{last.lower()}":
            print(f"Pattern: [first_initial][lastname]")
            return
        elif username == f"{first.lower()}.{last.lower()}":
            print(f"Pattern: [firstname].[lastname]")
            return
        elif username == f"{first.lower()}{last.lower()}":
            print(f"Pattern: [firstname][lastname]")
            return

detect_pattern(usernames, full_names)
```

---

## Comprehensive Testing Checklist

### Username Structure Analysis:
```
☐ Gather sample usernames (3-5 minimum)
☐ Obtain corresponding full names
☐ Identify pattern (first.last, flast, etc.)
☐ Verify pattern consistency across samples
☐ Generate additional usernames based on pattern
☐ Validate generated usernames
```

---

### Username Policy Testing:
```
☐ Minimum length requirement? (test with short names)
☐ Maximum length limit?
☐ Allowed characters? (special chars, numbers)
☐ Case sensitivity enforced?
☐ Uniqueness check? (can same username exist twice?)
☐ Reserved username blocking? (admin, root, test)
```

---

### Error Message Testing:
```
☐ Valid username + wrong password → message?
☐ Invalid username + wrong password → message?
☐ Messages identical? (no enumeration)
☐ Response codes identical?
☐ Response lengths identical?
☐ Response times identical?
```

---

## Gyakorlati Cheat Sheet

| Feladat | Módszer |
|---------|---------|
| Pattern detection | Collect 5+ usernames + full names, analyze |
| Email harvesting | Hunter.io, LinkedIn, Google dorking |
| LDAP enumeration | `ldapsearch -x -H ldap://... "(cn=*)"` |
| Username generation | Python script based on pattern |
| Validation | Test with wrong password, check error |
| GitHub mining | `git log --format='%an <%ae>'` |

---

## Fontos Toolok

### Information Gathering:
- **Hunter.io** - Email finder
- **LinkedIn** - Employee names
- **theHarvester** - Email harvesting
- **LDAP** - Directory enumeration

### Pattern Detection:
- **Python scripts** - Custom analysis
- **Regex** - Pattern matching

### Validation:
- **curl** - Testing usernames
- **Burp Intruder** - Mass validation
- **ffuf** - Fuzzing

---

## Védelem (Remediation)

### 1. **Unpredictable Username Policy:**

**BAD (Predictable):**
```
Rule: [first_initial][lastname]
Result: jsmith, sconnor (guessable!)
```

**BETTER (Random component):**
```
Rule: [firstname].[lastname].[random4digits]
Result: john.smith.8472, sarah.connor.2941
```

---

### 2. **Allow Custom Usernames:**

```python
# Registration
username = request.form['username']  # User chooses

# Not forced pattern
# User picks: "dragonslayer123" instead of "jsmith"
```

---

### 3. **Email as Username:**

```
Username = Email address
→ Still guessable, but at least not pattern-based
```

---

### 4. **Minimum Length Enforcement:**

```python
MIN_USERNAME_LENGTH = 6
MAX_USERNAME_LENGTH = 20

if len(username) < MIN_USERNAME_LENGTH:
    return "Username must be at least 6 characters"
```

---

### 5. **Case-Insensitive Uniqueness:**

```python
def register(username):
    # Check if username exists (case-insensitive)
    existing = User.query.filter(
        func.lower(User.username) == username.lower()
    ).first()
    
    if existing:
        return "Username already taken", 400
    
    user = User(username=username)
    user.save()
```

---

### 6. **Reserved Username Blocking:**

```python
RESERVED = ['admin', 'root', 'administrator', 'moderator', 
            'test', 'guest', 'user', 'default']

if username.lower() in RESERVED:
    return "Username is reserved", 400
```

---

### 7. **Consistent Error Messages:**

```python
# Same message for all login failures
if not user or not user.check_password(password):
    return "Invalid credentials", 401
# NOT "User not found" or "Invalid password"!
```

---

### 8. **Rate Limiting:**

```python
@limiter.limit("10 per hour")
def login():
    # Prevents mass username validation
```

---

## Real-World Example

### Case Study: **Corporate Application**

**Discovered pattern:**
```
Employees from LinkedIn:
- John Smith (CEO)
- Sarah Connor (CTO)
- Mike Johnson (Developer)

Email pattern (from website):
john.smith@company.com
sarah.connor@company.com
mike.johnson@company.com

Username pattern (tested):
john.smith ✓ (valid)
sarah.connor ✓ (valid)
mike.johnson ✓ (valid)

Pattern confirmed: [firstname].[lastname]
```

---

**Exploitation:**

```python
# LinkedIn scraping (100 employees)
employees = [
    "John Smith",
    "Sarah Connor",
    "Mike Johnson",
    # ... 97 more
]

# Generate usernames
usernames = [
    name.lower().replace(' ', '.') 
    for name in employees
]

# Result: 100 valid usernames
# Next step: Password spray attack
```

---

## Fontos Megjegyzések

✅ **Predictable pattern** = easy username enumeration  
✅ **[first_initial][lastname]** = very common pattern  
✅ **Email prefix = username** = guessable  
✅ **LinkedIn + pattern** = valid username list  
✅ **LDAP enumeration** = reveals pattern  
✅ **Minimum 6 chars** = harder to brute-force  
✅ **Custom usernames** = breaks pattern  
❌ **Sequential IDs** (user1, user2) = very weak!  
❌ **Too short** (3 chars) = brute-forceable!  
⚠️ **Consistent error messages** critical for defense!  
⚠️ **Case-insensitive uniqueness** prevents duplicates!

---

**Összefoglalva:** Ez a fejezet a **weak username policy** teszteléséről szól. **Predictable username structure** (pl. `[first_initial][lastname]` → jsmith, sconnor) lehetővé teszi **username enumeration**-t **social sources**-ból (LinkedIn, Hunter.io, LDAP). **Email harvesting** → email prefix = username. **Pattern detection**: collect 5+ username + full name pairs, identify pattern, generate new usernames, validate. **Weak policies**: too short (3 chars), sequential (user1, user2), no uniqueness check. **Defense**: **unpredictable usernames** (random component), **custom usernames** (user choice), **minimum 6 characters**, **case-insensitive uniqueness**, **reserved username blocking**, **consistent error messages**. **LinkedIn + detected pattern** = instant valid username list!
