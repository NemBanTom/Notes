# WSTG-ATHN-02: Default Credentials Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy **default credentials** (gyári jelszavak) és **weak initial passwords** lehetővé teszik az **unauthorized access**-t, mivel az **attacker könnyen kitalálhatja** vagy **online adatbázisokban** megtalálhatja ezeket. **Vendor default** (admin/admin), **organization default** (Password1), vagy **application-generated** predictable passwords mind **critical vulnerability-k**.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM brute-force testing! Ez specifikusan **default** és **initial** password-ok tesztelése - ami a rendszerrel/alkalmazással **jön** vagy **automatikusan generálódik**.

---

## Mi a cél?

**Default credentials** azonosítása:
- Vendor default passwords (admin/admin)
- Organization default passwords (Password1)
- Application-generated predictable passwords
- Unchanged initial passwords

---

## 3 Típus Default Credential

### 1. **Vendor Default Credentials** (Gyári)
### 2. **Organization Default Passwords** (Szervezeti)
### 3. **Application-Generated Passwords** (App által generált)

---

## 1. Vendor Default Credentials

### Concept:
**Hardware/software gyárilag beállított** username/password párok.

---

### Common Examples:

| Vendor/Product | Username | Password |
|----------------|----------|----------|
| Cisco Router | admin | admin |
| Tomcat | admin | admin |
| MySQL | root | (empty) |
| phpMyAdmin | root | (empty) |
| MongoDB | admin | (empty) |
| Jenkins | admin | password |
| RabbitMQ | guest | guest |
| Grafana | admin | admin |
| WordPress | admin | password |

---

### Testing Workflow:

**Step 1 - Identify Software:**
```
1. Fingerprint application (WSTG-INFO-02)
2. Determine vendor
3. Identify version
```

**Example:**
```bash
# Identify web server
curl -I https://target.com | grep Server
# → Server: Apache Tomcat/9.0.50

# Product: Apache Tomcat
# Version: 9.0.50
```

---

**Step 2 - Search Default Credentials:**

**Method A - Google Search:**
```
Search: "Tomcat default password"

Results:
Username: admin
Password: admin
```

---

**Method B - CIRT.net Database:**
```
URL: https://cirt.net/passwords

Search: Tomcat

Found:
Username: admin
Password: admin

Username: tomcat
Password: tomcat
```

---

**Method C - SecLists:**
```bash
# Clone SecLists
git clone https://github.com/danielmiessler/SecLists

# Default credentials
cat SecLists/Passwords/Default-Credentials/tomcat-betterdefaultpasslist.txt
```

**Output:**
```
admin:admin
tomcat:tomcat
admin:password
root:root
```

---

**Method D - DefaultCreds Cheat Sheet:**
```
URL: https://github.com/ihebski/DefaultCreds-cheat-sheet

Search CSV for product name
```

---

**Step 3 - Test Default Credentials:**

```bash
# Test admin/admin
curl -X POST https://target.com/manager/html \
  -u admin:admin

# If successful (200 OK):
# → Default credentials unchanged!
```

---

### Common Default Passwords to Try:

```
Usernames:
- admin
- administrator
- root
- user
- test
- guest
- default

Passwords:
- admin
- password
- 12345
- 123456
- password123
- admin123
- root
- (empty/blank)
- default
- guest
```

---

### Hardware Specific:

**Network Devices (Routers, Switches):**
```
Cisco: admin/admin, cisco/cisco
Netgear: admin/password
D-Link: admin/(empty)
TP-Link: admin/admin
```

**IP Cameras:**
```
Hikvision: admin/12345
Dahua: admin/admin
Axis: root/pass
```

**IoT Devices:**
```
Raspberry Pi: pi/raspberry
Arduino: admin/(empty)
```

---

### Physical Inspection:

**Check device for stickers:**
```
Network devices often have:
- Default username on sticker
- Default password on sticker
- Serial number (sometimes used as password)
- MAC address (sometimes used as password)
```

---

## 2. Organization Default Passwords

### Concept:
**Staff manually create** initial passwords for new users → **predictable patterns**.

---

### Common Patterns:

**Pattern #1 - Single Common Password:**
```
All new users get: "Password1"
Or: "Welcome123"
Or: "CompanyName2024"
```

**Test:**
```bash
# Try with known username
curl -X POST /login \
  -d "username=jsmith&password=Password1"

curl -X POST /login \
  -d "username=jsmith&password=Welcome123"

curl -X POST /login \
  -d "username=jsmith&password=CompanyName2024"
```

---

**Pattern #2 - Organization Name:**
```
Company: Acme Corp
Default password: Acme123, AcmeCorp, Acme2024
```

---

**Pattern #3 - Temporal Patterns:**
```
Account created on Monday:
→ Password: Monday123

Account created in January:
→ Password: January2024

Current month:
→ Password: December2024
```

---

**Pattern #4 - Username-Based:**
```
Username: jsmith
Password: Jsmith123, jsmith2024, Jsmith!
```

---

**Pattern #5 - Location-Based:**
```
Office in London:
→ Password: London123

Address: 123 Main Street:
→ Password: MainStreet123
```

---

### Testing (Gray-box):**

**Interview staff:**
```
Q: "How do you create passwords for new users?"
A: "We use Password1 for everyone, they change it on first login"

→ Test Password1!
```

---

**Review documentation:**
```
User onboarding guide:
"Your initial password is: Welcome123"

→ Test Welcome123!
```

---

## 3. Application-Generated Passwords

### Concept:
**Application automatically generates** passwords → may be **predictable**.

---

### Testing Methodology:

**Step 1 - Create Multiple Accounts:**
```
1. Register Account A
   → Password generated: abc123xyz
2. Register Account B (similar details, same time)
   → Password generated: abc124xyz
3. Register Account C
   → Password generated: abc125xyz
```

**Pattern detected:** Sequential increment!

---

### Weak Generation Patterns:

**Pattern #1 - Static String:**
```
All users get same password: "ChangeMe123"
```

---

**Pattern #2 - Based on Username:**
```
Username: john
Generated: md5(john) = 527bd5b5d689e2c32ae974c6229ff785

Username: jane
Generated: md5(jane) = 5c5e45a6c929c6ab6741b7a6d2618e9a
```

**Test:**
```bash
# Generate md5 of username
echo -n "john" | md5sum
# → Try as password
```

---

**Pattern #3 - Timestamp-Based:**
```
Account created: 2024-01-20 14:30:00
Password: 20240120143000 (timestamp)

Or: 143000 (time only)
Or: 012024 (month+year)
```

---

**Pattern #4 - Weak PRNG:**
```python
# Weak random generation
import random
random.seed(12345)  # Static seed!
password = random.randint(100000, 999999)
# → Predictable!
```

---

### Pattern Detection:

**Create test accounts:**
```bash
# Account 1
curl -X POST /register \
  -d "username=testuser1&email=test1@test.com&firstname=John&lastname=Smith"

# Note password: abc123

# Account 2
curl -X POST /register \
  -d "username=testuser2&email=test2@test.com&firstname=Jane&lastname=Doe"

# Note password: abc124

# Account 3
curl -X POST /register \
  -d "username=testuser3&email=test3@test.com&firstname=Mike&lastname=Johnson"

# Note password: abc125
```

**Pattern:** Sequential!

---

## Automated Testing

### Tool #1: **Hydra (Default Credentials)**

```bash
# Test default credentials
hydra -C default_credentials.txt target.com http-post-form \
  "/login:username=^USER^&password=^PASS^:F=incorrect"
```

**default_credentials.txt:**
```
admin:admin
admin:password
root:root
admin:12345
tomcat:tomcat
guest:guest
```

---

### Tool #2: **Burp Intruder**

**Setup:**
```
1. Intercept login request
2. Send to Intruder
3. Mark username and password fields
4. Attack type: Cluster bomb
5. Payload 1 (usernames): admin, root, user
6. Payload 2 (passwords): admin, password, 12345
7. Start attack
8. Look for different response (200 OK)
```

---

### Tool #3: **Nikto**

```bash
# Scan for default credentials
nikto -h https://target.com -Plugins default_creds
```

---

### Tool #4: **Nuclei**

```bash
# Install nuclei
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest

# Run default login templates
nuclei -u https://target.com -t http/default-logins/

# Specific product
nuclei -u https://target.com -t http/default-logins/tomcat-default-login.yaml
```

---

## Default Credential Databases

### CIRT.net:
```
URL: https://cirt.net/passwords
Search: Product name
Result: Default username/password
```

---

### SecLists:
```bash
git clone https://github.com/danielmiessler/SecLists

# Default credentials
cat SecLists/Passwords/Default-Credentials/default-passwords.csv

# Product-specific
cat SecLists/Passwords/Default-Credentials/tomcat-betterdefaultpasslist.txt
```

---

### DefaultCreds Cheat Sheet:
```
URL: https://github.com/ihebski/DefaultCreds-cheat-sheet/blob/main/DefaultCreds-Cheat-Sheet.csv

CSV format:
Product,Username,Password
```

---

## Comprehensive Testing Checklist

### Vendor Default:
```
☐ Identify software/hardware
☐ Search default credentials (Google, CIRT, SecLists)
☐ Try common defaults (admin/admin, root/root)
☐ Try empty password
☐ Check physical device for stickers
☐ Try serial number as password
☐ Try MAC address as password
```

---

### Organization Default:
```
☐ Try company name + 123
☐ Try common defaults (Password1, Welcome123)
☐ Try current month/year (January2024)
☐ Try location-based (London123)
☐ Interview staff (if gray-box)
☐ Review documentation
```

---

### App-Generated:
```
☐ Create multiple test accounts
☐ Compare generated passwords
☐ Test for static string
☐ Test for md5(username)
☐ Test for timestamp-based
☐ Test for sequential pattern
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Test default creds | `curl -u admin:admin https://target.com/admin` |
| Hydra brute-force | `hydra -C defaults.txt target.com http-post-form "..."` |
| Nikto scan | `nikto -h target.com -Plugins default_creds` |
| Nuclei default login | `nuclei -u target.com -t http/default-logins/` |
| MD5 username | `echo -n "username" \| md5sum` |

---

## Fontos Toolok

### Manual:
- **curl** - Testing credentials
- **Browser** - Manual login attempts

### Automated:
- **Hydra** - Brute-force with default cred list
- **Burp Intruder** - Cluster bomb attack
- **Nikto** - Default creds plugin
- **Nuclei** - Default login templates

### Databases:
- **CIRT.net** - Default password database
- **SecLists** - Default credential lists
- **DefaultCreds Cheat Sheet** - CSV database

---

## Védelem (Remediation)

### 1. **Force Password Change on First Login:**

```python
@app.route('/login', methods=['POST'])
def login():
    user = authenticate(username, password)
    
    if user:
        # Check if using default password
        if user.password_is_default:
            return redirect('/change-password?force=true')
        
        return redirect('/dashboard')
```

---

### 2. **Disable Default Accounts:**

```bash
# Disable default admin account
usermod -L admin

# Or delete
userdel admin

# Create custom admin with strong password
useradd custom_admin
passwd custom_admin  # Set strong password
```

---

### 3. **Random Password Generation:**

```python
import secrets
import string

def generate_secure_password(length=16):
    alphabet = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(secrets.choice(alphabet) for i in range(length))
    return password

# Generate for new user
initial_password = generate_secure_password()
# Send via secure channel (not email!)
```

---

### 4. **No Predictable Patterns:**

**BAD:**
```python
# Weak generation
password = f"{username}123"  # Predictable!
password = f"Password{current_month}"  # Predictable!
```

**GOOD:**
```python
# Cryptographically secure
password = secrets.token_urlsafe(16)
# → Example: "Uj3k8F2mN9qL7pR4"
```

---

### 5. **Account Setup Workflow:**

```
1. Admin creates account
2. System generates random password
3. Password sent to user via secure channel:
   - SMS
   - Secure email (encrypted)
   - In-person handover
4. User must change password on first login
5. Cannot reuse initial password
6. Must meet complexity requirements
```

---

### 6. **Password Expiry for Initial Passwords:**

```python
def check_password_age(user):
    if user.password_set_date is None:
        # Initial password, never changed
        days_old = (datetime.now() - user.created_at).days
        
        if days_old > 7:
            # Force password change after 7 days
            user.account_locked = True
            send_notification(user, "Account locked - password change required")
```

---

### 7. **Audit Default Accounts:**

```bash
#!/bin/bash
# Check for common default accounts

default_users=("admin" "root" "guest" "test" "default")

for user in "${default_users[@]}"; do
  if id "$user" &>/dev/null; then
    echo "WARNING: Default user '$user' exists!"
  fi
done
```

---

## Real-World Examples

### Example #1: **WordPress Admin**

**Default:**
```
Username: admin
Password: password (or set during install)
```

**Attack:**
```bash
# Try default credentials
curl -X POST http://target.com/wp-login.php \
  -d "log=admin&pwd=admin"

# Or use WPScan
wpscan --url http://target.com --passwords passwords.txt
```

---

### Example #2: **Tomcat Manager**

**Default:**
```
Username: admin
Password: admin
```

**Attack:**
```bash
curl -u admin:admin http://target.com:8080/manager/html

# If successful:
# → Upload WAR file → RCE!
```

---

### Example #3: **Database Defaults**

**MySQL:**
```
Username: root
Password: (empty)
```

**MongoDB:**
```
Username: admin
Password: (empty)
```

**Attack:**
```bash
# MySQL
mysql -h target.com -u root

# MongoDB
mongo target.com:27017 -u admin
```

---

## Fontos Megjegyzések

✅ **Default credentials** = #1 most common vulnerability  
✅ **Force password change** on first login  
✅ **Random generation** (secrets module)  
✅ **Disable default accounts** before production  
✅ **CIRT.net, SecLists** = comprehensive databases  
❌ **admin/admin** = check first always!  
❌ **Predictable patterns** (Password1) = weak!  
⚠️ **IoT devices** often have hardcoded defaults!  
⚠️ **Network devices** commonly unchanged!

---

**Összefoglalva:** Ez a fejezet a **default credentials** teszteléséről szól. **Vendor defaults** (admin/admin, root/(empty), tomcat/tomcat) **gyakran unchanged** production-ban! **Organization defaults** (Password1, Welcome123, CompanyName2024) staff által manually set. **App-generated** passwords lehet **predictable** (md5(username), timestamp, sequential). **Testing**: identify software → search defaults (CIRT.net, SecLists) → test with Hydra/Burp/Nuclei. **Defense**: **force password change** first login, **random generation** (secrets.token_urlsafe), **disable default accounts**, **no predictable patterns**!
