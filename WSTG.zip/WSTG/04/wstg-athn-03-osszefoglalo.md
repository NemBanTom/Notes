# WSTG-ATHN-03: Weak Lock Out Mechanism Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **account lockout mechanism** (felhasználó zárolási mechanizmus) megfelelően **véd-e brute-force attack-ok** ellen, miközben **nem okoz DoS**-t legitimate user-eknek. **Weak lockout** (túl magas threshold, nincs lockout, client-side only) = **brute-force vulnerable**. **Too strict lockout** (túl alacsony threshold, örök zárolás) = **DoS vulnerability**.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános brute-force testing! Ez specifikusan a **lockout mechanism** (zárolás) **effectiveness** és **bypass** tesztelése.

---

## Mi a cél?

**Lockout mechanism** hatékonyságának tesztelése:
- Lockout threshold (hány sikertelen próbálkozás után?)
- Lockout duration (meddig tart a zárolás?)
- Unlock mechanism (hogyan oldható fel?)
- CAPTCHA effectiveness (megkerülhető-e?)
- DoS potential (lehet-e vele DoS-t csinálni?)

---

## Lockout Mechanism Concept

### Proper Lockout:

```
User: john

Login attempts:
1. Wrong password → "Invalid credentials"
2. Wrong password → "Invalid credentials"
3. Wrong password → "Invalid credentials"
4. Wrong password → "Invalid credentials"
5. Wrong password → "Invalid credentials"
6. Wrong password → "Account locked for 15 minutes"

After 15 minutes:
7. Correct password → Success!
```

**Védelem:** Brute-force mitigated (max 5-10 attempts)

---

### Weak Lockout:

**Problem #1 - No Lockout:**
```
Unlimited attempts:
1. Wrong → Fail
2. Wrong → Fail
...
1000. Wrong → Fail
1001. Correct → Success!

→ Brute-force possible!
```

---

**Problem #2 - Too High Threshold:**
```
Lockout after 100 attempts

→ Attacker can try 99 passwords!
→ Too many attempts before lockout
```

---

**Problem #3 - Client-Side Lockout:**
```javascript
// JavaScript lockout (client-side)
if (failedAttempts >= 5) {
    alert("Account locked!");
    return;
}
```

→ **Bypass:** Disable JavaScript or use Burp!

---

**Problem #4 - No Time-Based Unlock:**
```
Account locked forever
No automatic unlock
Admin must manually unlock

→ DoS possible!
```

---

## Testing Methodology

### Test #1: **Determine Lockout Threshold**

**Workflow:**
```
1. Attempt login with wrong password (count: 1)
2. Wrong password (count: 2)
3. Wrong password (count: 3)
4. Correct password → Success?
   → If yes: threshold > 3

5. Wrong password (count: 4)
6. Correct password → Success?
   → If yes: threshold > 4

7. Wrong password (count: 5)
8. Correct password → Locked?
   → If yes: threshold = 5
```

---

**Automated test:**
```bash
#!/bin/bash

username="testuser"
correct_password="MyPassword123"
wrong_password="wrongpass"

# Try increasing attempts
for threshold in {1..10}; do
  echo "Testing threshold: $threshold"
  
  # Make wrong attempts
  for i in $(seq 1 $threshold); do
    curl -s -X POST https://target.com/login \
      -d "username=$username&password=$wrong_password" > /dev/null
  done
  
  # Try correct password
  response=$(curl -s -X POST https://target.com/login \
    -d "username=$username&password=$correct_password")
  
  if echo "$response" | grep -q "locked"; then
    echo "Lockout threshold: $threshold failed attempts"
    break
  elif echo "$response" | grep -q "success"; then
    echo "No lockout yet at $threshold attempts"
  fi
  
  # Wait before next test
  sleep 300  # 5 minutes
done
```

---

### Test #2: **Determine Lockout Duration**

**Workflow:**
```
1. Trigger lockout (5 failed attempts)
2. Try correct password immediately → "Account locked"
3. Wait 5 minutes
4. Try correct password → Still locked?
5. Wait 10 minutes (total)
6. Try correct password → Still locked?
7. Wait 15 minutes (total)
8. Try correct password → Unlocked!

Result: Lockout duration = 10-15 minutes
```

---

**Test script:**
```bash
#!/bin/bash

# Trigger lockout
for i in {1..5}; do
  curl -X POST /login -d "username=test&password=wrong" > /dev/null
done

# Test unlock at different intervals
for minutes in 1 2 5 10 15 20 30; do
  echo "Waiting $minutes minutes..."
  sleep $((minutes * 60))
  
  response=$(curl -s -X POST /login \
    -d "username=test&password=correct")
  
  if echo "$response" | grep -q "success"; then
    echo "Account unlocked after $minutes minutes"
    break
  else
    echo "Still locked after $minutes minutes"
  fi
done
```

---

### Test #3: **Lockout Reset on Success**

**Test:**
```
1. Failed login (count: 1)
2. Failed login (count: 2)
3. Failed login (count: 3)
4. Successful login
5. Failed login (count: 1 or 4?)
```

**If count resets to 1:** Proper implementation  
**If count continues at 4:** Vulnerability!

---

### Test #4: **Per-User vs Per-IP Lockout**

**Test A - Per-User:**
```bash
# From IP 1.1.1.1
curl -X POST /login -d "username=john&password=wrong"  # Attempt 1
curl -X POST /login -d "username=john&password=wrong"  # Attempt 2

# From IP 2.2.2.2 (different IP!)
curl -X POST /login -d "username=john&password=wrong"  # Attempt 3?

If locked: Per-user lockout (GOOD for brute-force prevention)
If not locked: Per-IP lockout (WEAK - attacker can use multiple IPs)
```

---

**Test B - Per-IP:**
```bash
# From IP 1.1.1.1
curl -X POST /login -d "username=john&password=wrong"  # Attempt 1
curl -X POST /login -d "username=jane&password=wrong"  # Different user

If both attempts count toward same lockout:
→ Per-IP lockout (DoS risk - attacker can lock all users from same IP!)
```

---

### Test #5: **Client-Side Lockout Bypass**

**Scenario:**
```javascript
// Client-side check
var failedAttempts = 0;

function login() {
    failedAttempts++;
    if (failedAttempts >= 5) {
        alert("Account locked!");
        return false;  // Stop submission
    }
    // Submit form
}
```

---

**Bypass:**

**Method A - Disable JavaScript:**
```
Browser settings → Disable JavaScript
→ Try unlimited attempts
```

---

**Method B - Direct API Request:**
```bash
# Bypass client-side check with curl
for i in {1..100}; do
  curl -X POST https://target.com/api/login \
    -d "username=john&password=attempt$i"
done

If successful past 5 attempts:
→ Client-side lockout only! (CRITICAL!)
```

---

**Method C - Burp Suite:**
```
1. Intercept login request
2. Send to Repeater
3. Click "Send" 100 times
4. Check if locked after 5 attempts
```

---

## CAPTCHA Testing

### CAPTCHA Weaknesses:

**Weakness #1 - Easy to Solve:**
```
CAPTCHA: "2 + 2 = ?"
→ Easily automated!
```

---

**Weakness #2 - Check Response Code Only:**
```python
# Backend (BAD)
if captcha_response.status_code == 200:
    # Assume solved
    proceed_with_login()
```

**Bypass:**
```bash
# Send fake 200 response
curl -X POST /login \
  -d "username=john&password=pass&captcha_response=fake" \
  -H "X-Captcha-Status: 200"
```

---

**Weakness #3 - No Server-Side Validation:**
```html
<form>
  <input name="captcha_solved" value="true">  <!-- Client sets! -->
</form>
```

**Bypass:**
```bash
curl -X POST /login \
  -d "username=john&password=pass&captcha_solved=true"
```

---

**Weakness #4 - Default to Success:**
```python
# Backend (BAD)
try:
    verify_captcha(token)
except:
    pass  # Default to success on error!
```

---

**Weakness #5 - CAPTCHA in Alt Text:**
```html
<img src="captcha.png" alt="ABC123">
```

**Bypass:**
```bash
# Parse alt text
captcha=$(curl -s https://target.com/login | grep -oP 'alt="\K[^"]+')
# Use as solution
```

---

**Weakness #6 - Reusable Token:**
```bash
# Get CAPTCHA token
token="abc123xyz"

# Use same token multiple times
curl -X POST /login -d "username=u1&password=p1&captcha=$token"
curl -X POST /login -d "username=u2&password=p2&captcha=$token"

If both work: Token reusable!
```

---

### CAPTCHA Testing Checklist:

```
☐ Assess CAPTCHA difficulty (can it be automated?)
☐ Submit without solving CAPTCHA
☐ Submit with wrong CAPTCHA solution
☐ Check if CAPTCHA solution in alt-text/filename
☐ Attempt to reuse CAPTCHA token
☐ Clear cookies - does CAPTCHA disappear?
☐ Skip CAPTCHA step (multi-step process)
☐ Check API endpoint (might not have CAPTCHA)
☐ Fuzz CAPTCHA parameter (injection?)
```

---

## Unique Lockout: AWS Cognito

### Exponential Backoff:

**Algorithm:** `2^(n-5)` seconds lockout

```
Attempt 1-5: No lockout
Attempt 6: 2^(6-5) = 2^1 = 2 seconds
Attempt 7: 2^(7-5) = 2^2 = 4 seconds
Attempt 8: 2^(8-5) = 2^3 = 8 seconds
...
Attempt 15+: 15 minutes (maximum)
```

---

**Testing:**
```
Burp Intruder:
- Resource Pool → Max concurrent: 1
- Delay between requests: 2 seconds
- 200 invalid attempts
- Then 3 valid attempts
- Wait 2 minutes → Try again

If successful: Cognito-style lockout detected
```

---

## Unlock Mechanism Testing

### Test #1: **Time-Based Unlock**

```bash
# Trigger lockout
for i in {1..5}; do curl -X POST /login -d "...wrong..."; done

# Wait and test
sleep 600  # 10 minutes
curl -X POST /login -d "...correct..."

If unlocked: Time-based (10 min)
```

---

### Test #2: **Self-Service Unlock (Email)**

**Trigger:**
```
1. Lock account (5 failed attempts)
2. Click "Unlock Account"
3. Email sent: "Click to unlock: https://site.com/unlock?token=abc123"
```

---

**Security tests:**

**Test A - Token Predictability:**
```bash
# Token: abc123
# Try: abc124, abc125, etc.

for token in abc{120..130}; do
  curl https://site.com/unlock?token=$token
done
```

---

**Test B - Token Reuse:**
```bash
# Use unlock link
curl https://site.com/unlock?token=abc123
# → Account unlocked

# Trigger lockout again
# Use SAME token
curl https://site.com/unlock?token=abc123

If works: Token reusable! (WEAK!)
```

---

**Test C - Token Timing:**
```bash
# Wait 24 hours
curl https://site.com/unlock?token=old_token

If works: No expiry! (WEAK!)
```

---

### Test #3: **Admin Unlock**

**Test:**
```
1. Lock account
2. Contact admin / use admin panel
3. Admin unlocks account
4. Verify unlock successful
```

**Security:** Highest assurance (manual verification)

---

## DoS via Account Lockout

### Attack Scenario:

**Mass Lockout:**
```bash
# Lock all users
users=("admin" "john" "jane" "mike" "sarah")

for user in "${users[@]}"; do
  for i in {1..5}; do
    curl -X POST /login -d "username=$user&password=wrong" &
  done
done

Result: All accounts locked!
→ DoS attack!
```

---

**Mitigation:**
```
- Per-IP rate limiting
- CAPTCHA after 3 attempts
- Time-based lockout (auto-unlock)
- Alert admin on mass lockouts
```

---

## Comprehensive Testing Checklist

### Lockout Mechanism:
```
☐ Determine lockout threshold (3-10 attempts?)
☐ Test lockout duration (5-30 minutes?)
☐ Test if lockout resets on success
☐ Test per-user vs per-IP lockout
☐ Test client-side vs server-side lockout
☐ Test with different IPs (distributed attack)
☐ Test with multiple users (DoS potential)
```

---

### CAPTCHA:
```
☐ Test CAPTCHA difficulty
☐ Submit without CAPTCHA
☐ Submit with wrong CAPTCHA
☐ Reuse CAPTCHA token
☐ Check alt-text for solution
☐ Test API endpoint (CAPTCHA bypass?)
```

---

### Unlock Mechanism:
```
☐ Test time-based unlock
☐ Test email unlock link
☐ Test unlock token predictability
☐ Test unlock token reuse
☐ Test unlock token expiry
☐ Test admin unlock
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Lockout threshold | Loop 1-10 failed attempts, test each |
| Lockout duration | Wait 5, 10, 15, 30 min intervals |
| Client-side bypass | Disable JS or use curl |
| CAPTCHA bypass | Submit without/with wrong solution |
| Token reuse | Use same unlock token twice |
| DoS test | Lock multiple accounts |

---

## Fontos Toolok

### Manual:
- **curl** - Failed attempt testing
- **Browser** - Disable JavaScript

### Automated:
- **Burp Intruder** - Mass failed attempts
- **Hydra** - Brute-force (with delays)

### Timing:
- **sleep** - Wait between tests
- **time** - Measure lockout duration

---

## Védelem (Remediation)

### 1. **Proper Lockout Threshold:**

```
Recommended: 5-10 failed attempts

Too low (3): Users frequently locked
Too high (20+): Too many brute-force attempts
```

---

### 2. **Time-Based Unlock:**

```python
LOCKOUT_DURATION = 900  # 15 minutes

@app.route('/login', methods=['POST'])
def login():
    user = get_user(username)
    
    # Check if locked
    if user.locked_until and datetime.now() < user.locked_until:
        return "Account locked. Try again later.", 403
    
    # Verify password
    if not user.check_password(password):
        user.failed_attempts += 1
        
        if user.failed_attempts >= 5:
            user.locked_until = datetime.now() + timedelta(seconds=LOCKOUT_DURATION)
            return "Account locked for 15 minutes.", 403
        
        return "Invalid credentials", 401
    
    # Success - reset counter
    user.failed_attempts = 0
    user.locked_until = None
    return "Success", 200
```

---

### 3. **Server-Side Lockout:**

```python
# NEVER client-side only!

# Server tracks failed attempts
# Server enforces lockout
# Client just displays message
```

---

### 4. **CAPTCHA After N Attempts:**

```python
@app.route('/login', methods=['POST'])
def login():
    user = get_user(username)
    
    # Require CAPTCHA after 3 failed attempts
    if user.failed_attempts >= 3:
        if not verify_captcha(request.form['captcha']):
            return "CAPTCHA required", 403
    
    # ... login logic ...
```

---

### 5. **Exponential Backoff (Cognito-style):**

```python
def get_lockout_duration(failed_attempts):
    if failed_attempts <= 5:
        return 0  # No lockout
    
    # 2^(n-5) seconds, max 15 minutes
    duration = 2 ** (failed_attempts - 5)
    return min(duration, 900)  # Max 15 minutes

# Example:
# 6 attempts → 2^1 = 2 seconds
# 7 attempts → 2^2 = 4 seconds
# 8 attempts → 2^3 = 8 seconds
# 15+ attempts → 900 seconds (15 min)
```

---

### 6. **Per-User + Per-IP Rate Limiting:**

```python
from flask_limiter import Limiter

limiter = Limiter(app)

@app.route('/login', methods=['POST'])
@limiter.limit("10 per minute")  # Per-IP
def login():
    # Also track per-user
    user = get_user(username)
    
    # ... lockout logic ...
```

---

### 7. **Secure Unlock Token:**

```python
import secrets

def generate_unlock_token(user):
    # Cryptographically secure token
    token = secrets.token_urlsafe(32)
    
    # Store with expiry
    UnlockToken.create(
        user_id=user.id,
        token=token,
        expires_at=datetime.now() + timedelta(hours=1)  # 1-hour expiry
    )
    
    return token

def unlock_account(token):
    unlock_token = UnlockToken.query.filter_by(token=token).first()
    
    if not unlock_token:
        return False
    
    if datetime.now() > unlock_token.expires_at:
        return False  # Expired
    
    # Unlock account
    user = unlock_token.user
    user.locked_until = None
    user.failed_attempts = 0
    
    # Delete token (one-time use)
    unlock_token.delete()
    
    return True
```

---

## Fontos Megjegyzések

✅ **5-10 attempts** = good threshold  
✅ **15-30 minute lockout** = balance security/UX  
✅ **Time-based unlock** = prevents permanent DoS  
✅ **Server-side lockout** only!  
✅ **CAPTCHA after 3 attempts** = good practice  
✅ **One-time unlock tokens** = secure  
❌ **Client-side lockout** = easily bypassed!  
❌ **No lockout** = brute-force vulnerable!  
❌ **Permanent lockout** = DoS risk!  
⚠️ **Per-IP only** = attacker can use multiple IPs!  
⚠️ **Easy CAPTCHA** (2+2) = automation possible!

---

**Összefoglalva:** Ez a fejezet a **lockout mechanism** teszteléséről szól. **Proper lockout**: **5-10 failed attempts** → **15-30 minute lockout** → **automatic unlock**. **Weak lockout**: **client-side only** (disable JS bypass), **too high threshold** (100+ attempts), **no time-based unlock** (DoS), **per-IP only** (multiple IPs bypass). **CAPTCHA weaknesses**: **easy to solve** (2+2), **no server-side validation**, **reusable tokens**, **solution in alt-text**. **Unlock mechanism**: **one-time tokens**, **1-hour expiry**, **secure random generation**. **AWS Cognito**: exponential backoff (`2^(n-5)` seconds). **Defense**: **server-side lockout**, **CAPTCHA after 3**, **time-based unlock**, **per-user + per-IP** rate limiting!
