# WSTG-ATHN-06: Browser Cache Weakness Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **browser cache** és **browser history** **sensitive information**-t tárolhat, amely **később elérhető** akár **logout után** is. **Weak cache directives** vagy **missing cache headers** miatt **confidential data** (credit card, SSN, personal info) **megmaradhat** a **browser cache**-ben vagy **history**-ban.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM session management! Ez **browser-side caching** - milyen **directives** vannak a **HTTP response**-okban, hogy **ne cache-elje** a browser a **sensitive content**-et.

---

## Mi a cél?

**Browser cache** security ellenőrzése:
- Sensitive data nem tárolódik browser cache-ben
- Proper cache-control headers minden sensitive page-en
- Back button nem mutat sensitive data logout után

---

## 2 Fő Terület

### 1. **Browser History** (Back Button)
### 2. **Browser Cache** (Disk Storage)

---

## 1. Browser History (Back Button)

### Concept:
**Browser history** lehetővé teszi a **Back button**-t → **previously viewed pages** újra megjelenítése.

---

### Vulnerability:

```
Scenario:
1. User logs in
2. Views sensitive page (account details)
3. Logs out
4. Presses Back button
→ Sensitive page still visible!
```

---

### Test:

**Step 1 - Login and view sensitive page:**
```
1. Login to application
2. Navigate to sensitive page (e.g., /account/details)
3. Note: SSN, credit card, personal info visible
```

---

**Step 2 - Logout:**
```
4. Click Logout
5. Redirected to login page or public page
```

---

**Step 3 - Press Back button:**
```
6. Press browser Back button
7. Check if sensitive page still visible
```

---

**If sensitive data visible:**
→ **MEDIUM!** Browser history weakness!

---

### Why it happens:

**Browser caches the page for Back button functionality.**

Even after logout:
- Page still in memory
- Back button retrieves from cache
- No re-authentication required

---

## 2. Browser Cache (Disk Storage)

### Concept:
**Browser caches** files on disk for performance → **reuse** without re-downloading.

---

### Cache Locations:

**Firefox:**
```
Windows:
C:\Users\<user>\AppData\Local\Mozilla\Firefox\Profiles\<profile>\Cache2\

Linux:
~/.cache/mozilla/firefox/
```

**Chrome:**
```
Windows:
C:\Users\<user>\AppData\Local\Google\Chrome\User Data\Default\Cache

Linux:
~/.cache/google-chrome/
```

**Edge/IE:**
```
C:\Users\<user>\AppData\Local\Microsoft\Windows\INetCache\
```

---

### Vulnerability:

**Sensitive pages cached on disk:**
```
1. User views credit card page
2. Browser caches HTML/images to disk
3. User closes browser
4. Attacker accesses cached files
→ Credit card info exposed!
```

---

## Cache-Control Headers

### Proper Headers (Prevent Caching):

**HTTP/1.1:**
```http
Cache-Control: no-cache, no-store, must-revalidate
Pragma: no-cache
Expires: 0
```

---

**Breakdown:**

| Directive | Meaning |
|-----------|---------|
| `no-cache` | Revalidate with server before using cache |
| `no-store` | Do NOT store in cache at all |
| `must-revalidate` | Must check with server if cache expired |
| `Pragma: no-cache` | HTTP/1.0 backwards compatibility |
| `Expires: 0` | HTTP/1.0 - content already expired |

---

### Additional Flags (Stronger):

```http
Cache-Control: no-cache, no-store, must-revalidate, max-age=0, s-maxage=0
```

**Additional directives:**
- `max-age=0` → Cache expires immediately
- `s-maxage=0` → Shared cache (proxy) expires immediately

---

## Testing Methodology

### Test #1: **Back Button Test**

**Step-by-step:**
```
1. Login to application
2. Navigate to sensitive page:
   - Account details
   - Credit card info
   - Personal information
   - SSN, address, etc.
3. Note sensitive data displayed
4. Logout
5. Press Back button
6. Check if sensitive data still visible
```

---

**Expected (Secure):**
```
After logout + Back button:
→ Redirect to login page
→ Or "Session expired" message
→ Or blank page
→ NOT the sensitive data!
```

**Vulnerable:**
```
After logout + Back button:
→ Sensitive page still displayed
→ Data still visible
```

---

### Test #2: **Cache Headers Test**

**Step 1 - Identify sensitive pages:**
```
Pages with sensitive info:
- /account/details
- /payment/card
- /profile/edit
- /transactions
```

---

**Step 2 - Check response headers:**

```bash
# Test each sensitive page
curl -I https://site.com/account/details

# Look for Cache-Control header
```

---

**Secure response:**
```http
HTTP/1.1 200 OK
Content-Type: text/html
Cache-Control: no-cache, no-store, must-revalidate
Pragma: no-cache
Expires: 0
```

✓ Proper cache directives!

---

**Vulnerable response:**
```http
HTTP/1.1 200 OK
Content-Type: text/html
(no Cache-Control header)
```

✗ Missing cache directives!

---

**Or weak directive:**
```http
Cache-Control: max-age=3600
```

✗ Caches for 1 hour!

---

### Test #3: **Inspect Browser Cache**

**Firefox:**
```
1. Visit sensitive page
2. Close tab
3. Type in address bar: about:cache
4. Search for sensitive page URL
```

**If found in cache:**
→ **Vulnerable!**

---

**Chrome DevTools:**
```
1. F12 → Application tab
2. Storage → Cache Storage
3. Look for sensitive URLs
```

---

**Manual file inspection:**
```bash
# Firefox cache (Linux)
ls -la ~/.cache/mozilla/firefox/*/cache2/entries/

# Chrome cache (Linux)
ls -la ~/.cache/google-chrome/Default/Cache/
```

**Search for sensitive content:**
```bash
grep -r "Credit Card" ~/.cache/google-chrome/Default/Cache/
grep -r "SSN" ~/.cache/mozilla/firefox/
```

---

### Test #4: **Mobile Browser Test**

**Different cache handling on mobile!**

**Test with:**
```
Chrome DevTools:
- F12 → Toggle device toolbar
- Select mobile device (iPhone, Android)
- Test cache behavior

Firefox:
- Responsive Design Mode
- Test cache headers
```

---

**Or set mobile User-Agent:**
```bash
curl -I https://site.com/account \
  -A "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)"

# Check Cache-Control headers
```

---

## Attack Scenarios

### Scenario #1: **Shared Computer**

```
1. User A logs in on public computer
2. Views bank account (balance: $50,000)
3. Logs out
4. User B sits down
5. Presses Back button
→ Sees User A's bank balance!
```

---

### Scenario #2: **Browser Cache Forensics**

```
1. User views sensitive page
2. Browser caches to disk
3. User closes browser (thinks they're safe)
4. Attacker with disk access:
   - Searches cache directory
   - Finds cached HTML
   - Extracts sensitive data
```

---

### Scenario #3: **Newsletter Signup**

```
1. User enters email: john.smith@company.com
2. Submits newsletter form
3. Presses Back button
4. Email address still in form field
→ Next user sees previous email!
```

---

## Comprehensive Testing Checklist

### History Testing:
```
☐ Login to application
☐ Visit sensitive pages
☐ Note sensitive data displayed
☐ Logout completely
☐ Press Back button
☐ Check if sensitive data visible
☐ Try on different browsers (Chrome, Firefox, Edge)
```

---

### Cache Header Testing:
```
☐ Identify all sensitive pages
☐ For each page, check HTTP response headers
☐ Verify Cache-Control: no-store
☐ Verify Pragma: no-cache
☐ Verify Expires: 0
☐ Test on public pages (should be cacheable)
☐ Test on login page (should not cache)
```

---

### Cache Inspection:
```
☐ Visit sensitive page
☐ Check about:cache (Firefox)
☐ Check DevTools → Application → Cache (Chrome)
☐ Search cache directory for sensitive URLs
☐ Search cache files for sensitive keywords
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Check headers | `curl -I https://site.com/account` |
| Firefox cache | `about:cache` in URL bar |
| Chrome cache | F12 → Application → Cache Storage |
| Mobile UA test | `curl -A "Mobile UA" https://site.com` |
| Search cache | `grep -r "sensitive" ~/.cache/` |

---

## Fontos Toolok

### Manual:
- **Browser DevTools** - F12 → Network/Application
- **curl** - Header inspection

### Cache Inspection:
- **Firefox about:cache** - Built-in cache viewer
- **Chrome DevTools** - Application → Cache

### Proxy:
- **Burp Suite** - Response analysis
- **ZAP** - Cache directive checker

---

## Védelem (Remediation)

### 1. **Set Proper Cache Headers:**

**Python/Flask:**
```python
from flask import make_response

@app.route('/account/details')
@login_required
def account_details():
    response = make_response(render_template('account.html'))
    
    # Prevent caching
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    
    return response
```

---

**Node.js/Express:**
```javascript
app.get('/account/details', (req, res) => {
    res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
    });
    
    res.render('account');
});
```

---

**Django:**
```python
from django.views.decorators.cache import never_cache

@never_cache
def account_details(request):
    return render(request, 'account.html')
```

---

### 2. **Apache Configuration:**

```apache
# For sensitive directories
<Location /account>
    Header set Cache-Control "no-cache, no-store, must-revalidate"
    Header set Pragma "no-cache"
    Header set Expires "0"
</Location>
```

---

### 3. **Nginx Configuration:**

```nginx
location /account {
    add_header Cache-Control "no-cache, no-store, must-revalidate";
    add_header Pragma "no-cache";
    add_header Expires "0";
}
```

---

### 4. **HTML Meta Tags (Less Effective):**

```html
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
```

**Note:** HTTP headers are more reliable!

---

### 5. **Deliver Over HTTPS:**

```
HTTPS + Cache-Control: must-revalidate
→ Browser must revalidate before showing cached page
```

---

### 6. **Clear Cache on Logout:**

```javascript
// Client-side (limited effectiveness)
window.onbeforeunload = function() {
    // Clear specific cache
    if ('caches' in window) {
        caches.keys().then(keys => {
            keys.forEach(key => caches.delete(key));
        });
    }
}
```

---

## Public vs Sensitive Pages

### Public Pages (Cacheable):

```http
GET /home HTTP/1.1

Response:
Cache-Control: public, max-age=3600
```

✓ OK to cache (improves performance)

---

### Sensitive Pages (No Cache):

```http
GET /account/details HTTP/1.1

Response:
Cache-Control: no-cache, no-store, must-revalidate
Pragma: no-cache
Expires: 0
```

✓ Never cached

---

## Fontos Megjegyzések

✅ **Cache-Control: no-store** = NO disk caching  
✅ **Pragma: no-cache** = HTTP/1.0 compatibility  
✅ **Expires: 0** = already expired  
✅ **HTTPS + must-revalidate** = stops Back button  
✅ **Sensitive pages** = always no-cache  
❌ **Missing cache headers** = default caching!  
❌ **Back button** shows sensitive data = history issue!  
⚠️ **Shared computers** = cache is dangerous!  
⚠️ **Mobile browsers** = different caching behavior!

---

**Összefoglalva:** Ez a fejezet a **browser cache weakness** teszteléséről szól. **Browser history** (Back button) és **browser cache** (disk storage) **sensitive information**-t tárolhatnak **logout után** is! **Back button test**: login → view sensitive page → logout → press Back → ha **látszik az adat** = **vulnerability**! **Cache headers**: minden **sensitive page**-en kell **`Cache-Control: no-cache, no-store, must-revalidate`**, **`Pragma: no-cache`**, **`Expires: 0`**. **Browser cache** inspection: Firefox `about:cache`, Chrome DevTools Application tab, vagy filesystem search (`~/.cache/`). **Defense**: **proper HTTP headers** minden sensitive response-ban, **HTTPS**, és **never cache** sensitive content!
