# WSTG-ATHN-07: Weak Authentication Methods Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **weak password policy** és **alternative weak credentials** (születési dátum, SSN, PIN) **brute-force attack**-oknak teszik ki az alkalmazást. **Common passwords** (123456, password), **no complexity requirements**, vagy **predictable credentials** mind **unauthorized access**-t tesznek lehetővé.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM authentication bypass! Ez **weak password policy** testing - milyen **követelmények** vannak a **password-ökre** és mennyire **könnyen kitalálhatók**.

---

## Mi a cél?

**Password policy** weakness-ek azonosítása:
- Password complexity requirements
- Password length (min/max)
- Common password prevention
- Password reuse restrictions
- Password aging/expiry
- Alternative weak credentials

---

## 9 Tesztelési Terület

### 1. **Character Requirements** (Milyen karakterek kellenek?)
### 2. **Password Change Frequency** (Milyen gyakran lehet váltani?)
### 3. **Password Expiry** (Meddig érvényes?)
### 4. **Password Reuse** (Lehet újrahasználni?)
### 5. **Password Similarity** (Mennyire különbözzen?)
### 6. **Username in Password** (Lehet username-et használni?)
### 7. **Length Requirements** (Min/max hossz?)
### 8. **Common Passwords** (Megengedettek?)
### 9. **Alternative Credentials** (Weak alternatívák?)

---

## 1. Character Requirements

### Test: **What characters are allowed/required?**

**Weak policy:**
```
Allowed: Lowercase letters only
Required: Nothing
```

**Result:** "password" is valid!

---

**Moderate policy:**
```
Allowed: Letters + numbers
Required: At least 1 number
```

**Result:** "password1" is valid (still weak!)

---

**Strong policy:**
```
Allowed: Letters + numbers + special chars
Required:
- At least 1 uppercase
- At least 1 lowercase
- At least 1 number
- At least 1 special character
```

**Result:** "P@ssw0rd!" is valid (meets requirements, but still common!)

---

### Testing:

```bash
# Try weak passwords
curl -X POST /register \
  -d "username=test&password=password&email=test@test.com"

# If accepted:
# → No complexity requirements!

# Try with numbers only
curl -X POST /register \
  -d "username=test2&password=123456&..."

# If accepted:
# → Accepts numeric-only passwords!
```

---

## 2. Password Change Frequency

### Test: **How quickly can user change password repeatedly?**

**Vulnerability:** User bypasses password history by changing password multiple times rapidly.

---

**Scenario:**
```
User wants to reuse old password: "OldPassword123"

Current password: "NewPassword456"

Password history: Last 5 passwords cannot be reused

Bypass:
1. Change to: "Temp1"
2. Change to: "Temp2"
3. Change to: "Temp3"
4. Change to: "Temp4"
5. Change to: "Temp5"
6. Change to: "OldPassword123" ← Successfully reused!
```

---

### Testing:

```bash
# Login
# Change password 6 times rapidly

curl -X POST /change-password \
  -H "Cookie: session=..." \
  -d "old_password=current&new_password=temp1"

curl -X POST /change-password \
  -d "old_password=temp1&new_password=temp2"

# ... repeat ...

curl -X POST /change-password \
  -d "old_password=temp5&new_password=OldPassword123"

# If successful:
# → No rate limiting on password changes!
```

---

**Secure implementation:**
```
Rate limit: 1 password change per 24 hours
OR: Require admin approval for rapid changes
```

---

## 3. Password Expiry

### NIST/NCSC Recommendation:

**DO NOT force regular password expiry!**

**Why?**
- Users choose weaker passwords (Password1, Password2, Password3)
- Users write down passwords
- No security benefit if strong password

---

### Test: **Is password expiry enforced?**

```bash
# Login with old account (created 90 days ago)

curl -X POST /login \
  -d "username=olduser&password=oldpassword"

# If forced to change password:
# → Password expiry enforced

# Check expiry period:
# 30 days? 60 days? 90 days?
```

---

**PCI DSS requirement:**
```
Password expiry: Max 90 days
```

**Note:** PCI DSS may require it, but NIST recommends against it!

---

## 4. Password Reuse

### Test: **Can user reuse old passwords?**

**Weak policy:**
```
Password history: None
→ User can reuse immediately!
```

---

**Moderate policy:**
```
Password history: Last 3 passwords
→ User cannot reuse last 3
```

---

**Strong policy:**
```
Password history: Last 8-12 passwords
→ User cannot reuse last 8-12
```

---

### Testing:

```bash
# 1. Change password to: "NewPassword123"
# 2. Change password to: "AnotherPassword456"
# 3. Try changing back to: "NewPassword123"

curl -X POST /change-password \
  -d "old_password=AnotherPassword456&new_password=NewPassword123"

# If successful:
# → Password history not enforced!
```

---

## 5. Password Similarity

### Test: **Must new password differ from old?**

**Weak policy:**
```
No similarity check
→ "Password1" → "Password2" allowed!
```

---

**Strong policy:**
```
New password must differ by at least 3 characters
→ "Password1" → "Password2" rejected!
```

---

### Testing:

```bash
# Current password: "MyPassword123"
# Try changing to: "MyPassword124"

curl -X POST /change-password \
  -d "old_password=MyPassword123&new_password=MyPassword124"

# If successful:
# → No similarity check!
```

---

## 6. Username in Password

### Test: **Can user include username in password?**

**Example:**
```
Username: john.smith
Password: johnsmith123
```

**Should be rejected!**

---

### Testing:

```bash
# Register with username in password
curl -X POST /register \
  -d "username=testuser&password=testuser123&..."

# If successful:
# → Username can be in password!

# Try variations
curl -X POST /register \
  -d "username=john&password=john123&..."

curl -X POST /register \
  -d "username=admin&password=admin2024&..."
```

---

## 7. Length Requirements

### Test: **What are min/max password lengths?**

**Weak policy:**
```
Minimum: 4 characters
Maximum: 8 characters (!)
```

**Result:** "pass" is valid (too short!)

---

**Moderate policy:**
```
Minimum: 8 characters
Maximum: 20 characters
```

---

**Strong policy:**
```
Minimum: 12 characters
Maximum: 128+ characters
```

---

### NIST Recommendations:

```
Minimum: 8 characters (user-generated)
Minimum: 6 characters (system-generated)
Maximum: At least 64 characters (no upper limit!)
```

---

### Testing:

```bash
# Test minimum length
curl -X POST /register -d "password=abc"  # 3 chars
curl -X POST /register -d "password=abcd"  # 4 chars
# Find minimum that's accepted

# Test maximum length
curl -X POST /register -d "password=$(python -c 'print("A"*100)')"
# Check if rejected or truncated
```

---

## 8. Common Passwords

### Test: **Are common passwords blocked?**

**Top 10 most common passwords:**
```
1. 123456
2. password
3. 123456789
4. 12345678
5. 12345
6. qwerty
7. 123123
8. password1
9. 1234567890
10. 1234567
```

---

### Testing:

```bash
# Try common passwords
curl -X POST /register -d "password=123456&..."
curl -X POST /register -d "password=password&..."
curl -X POST /register -d "password=qwerty&..."
curl -X POST /register -d "password=password1&..."

# If any accepted:
# → Common passwords not blocked!
```

---

**Comprehensive test:**
```bash
#!/bin/bash

# Common passwords list
passwords=(
  "123456"
  "password"
  "qwerty"
  "password1"
  "abc123"
  "monkey"
  "1234567"
  "letmein"
  "trustno1"
  "dragon"
)

for pwd in "${passwords[@]}"; do
  echo "Testing: $pwd"
  curl -s -X POST /register \
    -d "username=test_$pwd&password=$pwd&email=test@test.com" \
    | grep -q "success" && echo "ACCEPTED!"
done
```

---

## 9. Alternative Credentials

### Weak Credentials Used Instead of Passwords:

**Example #1 - Social Security Number:**
```
Username: john.smith
Credential: SSN (123-45-6789)
```

**Issue:** SSN easily obtainable (data breaches, public records)

---

**Example #2 - Birthdate:**
```
Username: john.smith
Credential: 01/01/1990
```

**Issue:** Birthdate easily guessable (Facebook, LinkedIn)

---

**Example #3 - PIN (4 digits):**
```
Username: john.smith
Credential: 1234
```

**Issue:** Only 10,000 combinations (0000-9999)

---

**Example #4 - Security Questions:**
```
Q: What is your mother's maiden name?
A: Smith

Q: What city were you born in?
A: London
```

**Issue:** Answers easily researched (social media, public records)

---

### Testing:

```bash
# If application uses SSN as credential:
# Try common SSNs
curl -X POST /login -d "username=john&ssn=123456789"
curl -X POST /login -d "username=john&ssn=000000000"

# If birthdate:
# Try common dates
curl -X POST /login -d "username=john&birthdate=01/01/1990"
curl -X POST /login -d "username=john&birthdate=01/01/1980"

# If PIN:
# Brute-force 0000-9999
for pin in {0000..9999}; do
  curl -X POST /login -d "username=john&pin=$pin"
done
```

---

## Comprehensive Testing Checklist

### Password Policy:
```
☐ Minimum length? (NIST: 8+ chars)
☐ Maximum length? (NIST: 64+ chars)
☐ Complexity required? (uppercase, lowercase, numbers, special)
☐ Common passwords blocked? (123456, password, etc.)
☐ Username in password blocked?
☐ Password history enforced? (last 5-8 passwords)
☐ Password change rate limiting?
☐ Password similarity check?
☐ Password expiry? (NIST recommends NO)
```

---

### Alternative Credentials:
```
☐ Does app use SSN as credential?
☐ Does app use birthdate?
☐ Does app use PIN?
☐ Are security questions used?
☐ Are answers easily guessable?
☐ Can credentials be brute-forced?
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Test weak password | `curl -X POST /register -d "password=123456&..."` |
| Test short password | `curl -X POST /register -d "password=abc&..."` |
| Test common password | `curl -X POST /register -d "password=password&..."` |
| Test username in pwd | `curl -X POST /register -d "username=john&password=john123&..."` |
| Test password reuse | Change pwd twice, try original |
| Test rapid changes | Change pwd 5 times quickly |

---

## Fontos Toolok

### Password Testing:
- **curl** - Manual testing
- **Burp Intruder** - Automated testing
- **Custom scripts** - Policy testing

### Brute-Force:
- **Hydra** - Password brute-force
- **John the Ripper** - Password cracking
- **Hashcat** - GPU password cracking

### Lists:
- **SecLists** - Common password lists
- **RockYou** - Leaked password database

---

## Védelem (Remediation)

### 1. **Strong Password Policy:**

```python
import re

def validate_password(username, password):
    errors = []
    
    # Minimum length
    if len(password) < 12:
        errors.append("Password must be at least 12 characters")
    
    # Maximum length
    if len(password) > 128:
        errors.append("Password too long (max 128)")
    
    # Complexity
    if not re.search(r'[A-Z]', password):
        errors.append("Must contain uppercase letter")
    if not re.search(r'[a-z]', password):
        errors.append("Must contain lowercase letter")
    if not re.search(r'[0-9]', password):
        errors.append("Must contain number")
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        errors.append("Must contain special character")
    
    # No username in password
    if username.lower() in password.lower():
        errors.append("Password cannot contain username")
    
    # Common passwords
    if password.lower() in COMMON_PASSWORDS:
        errors.append("Password too common")
    
    return errors
```

---

### 2. **Common Password Blacklist:**

```python
# Load common passwords (e.g., top 10,000)
COMMON_PASSWORDS = set()
with open('common-passwords.txt') as f:
    COMMON_PASSWORDS = {line.strip().lower() for line in f}

def is_common_password(password):
    return password.lower() in COMMON_PASSWORDS
```

---

### 3. **Password History:**

```python
import hashlib

def check_password_history(user_id, new_password):
    # Get last 8 password hashes
    old_hashes = db.execute(
        "SELECT password_hash FROM password_history "
        "WHERE user_id=? ORDER BY created_at DESC LIMIT 8",
        (user_id,)
    ).fetchall()
    
    new_hash = hashlib.sha256(new_password.encode()).hexdigest()
    
    for (old_hash,) in old_hashes:
        if new_hash == old_hash:
            return False, "Cannot reuse recent passwords"
    
    return True, "OK"
```

---

### 4. **Rate Limiting Password Changes:**

```python
from datetime import datetime, timedelta

def can_change_password(user_id):
    last_change = db.execute(
        "SELECT MAX(created_at) FROM password_history WHERE user_id=?",
        (user_id,)
    ).fetchone()[0]
    
    if last_change:
        # Require 24 hours between changes
        if datetime.now() - last_change < timedelta(hours=24):
            return False, "Can only change password once per 24 hours"
    
    return True, "OK"
```

---

### 5. **Two-Factor Authentication:**

```python
# Best defense: Add 2FA
# Even if password weak, attacker needs 2nd factor

@app.route('/login', methods=['POST'])
def login():
    user = authenticate(username, password)
    
    if user:
        # Send OTP to user's phone/email
        otp = generate_otp()
        send_otp(user.phone, otp)
        
        # Redirect to OTP verification page
        return redirect('/verify-otp')
```

---

### 6. **No Password Expiry (NIST Recommendation):**

```python
# DON'T force regular password changes
# Only require change if:
# - Password compromised
# - Security breach
# - User requests

# NOT because X days passed
```

---

## Real-World Password Stats

**From leaked databases:**
```
Top 5 passwords:
1. 123456 (23.2 million users)
2. 123456789 (7.7 million users)
3. qwerty (3.8 million users)
4. password (3.6 million users)
5. 12345 (2.9 million users)
```

**Password lengths:**
```
1-6 chars: 11%
7-8 chars: 34%
9-10 chars: 28%
11-12 chars: 15%
13+ chars: 12%
```

→ Most passwords are weak!

---

## Fontos Megjegyzések

✅ **Minimum 12 chars** (NIST: 8+, but 12+ better)  
✅ **Maximum 64+ chars** (no arbitrary limits!)  
✅ **Complexity requirements** (upper, lower, number, special)  
✅ **Common password blacklist** (top 10,000+)  
✅ **Password history** (last 8 passwords)  
✅ **2FA** = best defense  
✅ **NO password expiry** (NIST recommendation)  
❌ **123456, password** = most common!  
❌ **Birthdate, SSN** = weak credentials!  
⚠️ **Rate limit** password changes!  
⚠️ **Block username** in password!

---

**Összefoglalva:** Ez a fejezet a **weak password policy** teszteléséről szól. **Common passwords** (123456, password, qwerty) **MUST be blocked**! **Minimum 12 characters**, **complexity** (uppercase, lowercase, number, special), **NO username** in password. **Password history** (last 8), **rate limiting** password changes (1/24h). **Alternative weak credentials** (SSN, birthdate, PIN) **easily brute-forced**! **NIST recommends NO password expiry** (users choose weaker passwords). **Best defense**: **strong password policy** + **2FA**! **SecLists** common password lists testing-hez!
