# WSTG-ATHN-08: Weak Security Question/Answer Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **security questions** (biztonsági kérdések) **weak answers**-t generálnak, amelyek **könnyen kitalálhatók**, **social media**-n megtalálhatók, vagy **brute-force**-olhatók. **Pre-generated weak questions** ("Mi az anyád leánykori neve?") és **self-generated insecure questions** ("1+1=?") mind **account takeover**-t tesznek lehetővé.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM password recovery mechanizmus testing általában! Ez specifikusan **security question weakness** - milyen **kérdések** vannak és mennyire **könnyen megválaszolhatók**.

---

## Mi a cél?

**Security questions** gyengeségeinek azonosítása:
- Weak pre-generated questions
- Insecure self-generated questions
- Brute-forcible answers
- Publicly discoverable answers

---

## Security Questions Concept

### Célja:
- **Password recovery** (elfelejtett jelszó)
- **Additional authentication** (extra biztonság)

### Probléma:
**Answers must be secret** BUT questions promote **pseudo-private** answers!

---

## Vulnerability Categories

### 1. **Pre-Generated Weak Questions**
### 2. **Self-Generated Insecure Questions**
### 3. **Brute-Forcible Answers**
### 4. **Publicly Discoverable Answers**

---

## 1. Pre-Generated Weak Questions

### Category A: **Known to Family/Friends**

**Examples:**
```
Q: What is your mother's maiden name?
→ Known to family, relatives

Q: What is your date of birth?
→ Often public (Facebook, LinkedIn)

Q: What city were you born in?
→ Family/friends know this

Q: What is your father's middle name?
→ Discoverable from public records
```

---

### Category B: **Easily Guessable**

**Examples:**
```
Q: What is your favorite color?
→ Limited options (red, blue, green, etc.)
→ ~20 common colors

Q: What is your favorite sports team?
→ Limited to popular teams
→ Can brute-force top 50 teams

Q: What is your favorite food?
→ Common answers: pizza, pasta, burger

Q: What is your favorite animal?
→ Dog, cat, lion, etc. (limited set)
```

---

### Category C: **Brute-Forcible**

**Examples:**
```
Q: What is the first name of your favorite high school teacher?
→ Common first names (top 100)
→ John, Mary, David, Sarah, etc.

Q: What was your first car?
→ Popular car models
→ Honda Civic, Toyota Corolla, Ford Focus

Q: What is your pet's name?
→ Common pet names
→ Max, Buddy, Bella, Charlie
```

---

### Category D: **Publicly Discoverable**

**Examples:**
```
Q: What is your favorite movie?
→ Facebook: "Favorite Movies" section
→ IMDb profile, Twitter mentions

Q: What is your favorite book?
→ Goodreads profile
→ Amazon wishlist

Q: What high school did you attend?
→ LinkedIn profile
→ Facebook "Education" section

Q: What is your dream vacation destination?
→ Instagram posts
→ Pinterest boards
```

---

## 2. Self-Generated Insecure Questions

### Real-World Examples:

**Example #1 - Trivial:**
```
Q: What is 1+1?
A: 2
```

→ **CRITICAL!** Anyone can answer!

---

**Example #2 - Username:**
```
Q: What is your username?
A: john.smith
```

→ **CRITICAL!** Defeats the purpose!

---

**Example #3 - Password in Question:**
```
Q: My password is S3curIty!
A: [blank or "yes"]
```

→ **CRITICAL!** Password revealed!

---

**Example #4 - Simple Answer:**
```
Q: Security question?
A: answer
```

---

**Example #5 - Public Info:**
```
Q: Where do I work?
A: Microsoft
```

→ LinkedIn profile!

---

## Testing Methodology

### Test #1: **Enumerate Questions**

**Method A - Account Creation:**
```bash
# Create new account
curl -X POST /register \
  -d "username=testuser&email=test@test.com&password=Pass123"

# Note security questions presented
```

**Collect:**
- All available questions
- Question categories
- Required vs optional

---

**Method B - Password Reset:**
```bash
# Trigger password reset
curl -X POST /forgot-password \
  -d "email=test@test.com"

# Note security questions asked
```

---

### Test #2: **Analyze Question Weakness**

**For each question, evaluate:**

**Is it known to family/friends?**
```
Mother's maiden name → YES (weak!)
Favorite color → NO
```

**Is it easily guessable?**
```
Favorite sports team → YES (limited teams)
Random number → NO
```

**Is it brute-forcible?**
```
First car → YES (~50 popular models)
Random phrase → NO
```

**Is it publicly discoverable?**
```
Favorite movie → YES (Facebook, IMDb)
Secret childhood memory → NO
```

---

### Test #3: **Self-Generated Question Testing**

```bash
# Create account
# Set custom security question

curl -X POST /set-security-question \
  -H "Cookie: session=..." \
  -d 'question=What is 1+1?&answer=2'

# If accepted:
# → Allows weak self-generated questions!
```

---

### Test #4: **Brute-Force Testing**

**Step 1 - Enumerate username:**
```bash
# Find valid username (see IDNT-04)
curl -X POST /forgot-password \
  -d "username=john.smith"

# Response reveals security question
```

---

**Step 2 - Attempt brute-force:**
```bash
# Question: "What is your favorite color?"

colors=("red" "blue" "green" "yellow" "black" "white" "purple" "orange" "pink" "brown")

for color in "${colors[@]}"; do
  curl -X POST /reset-password \
    -d "username=john.smith&answer=$color"
done
```

---

**Step 3 - Check lockout:**
```
Try 10+ incorrect answers
→ Account locked? (good)
→ No lockout? (vulnerable to brute-force!)
```

---

## Attack Scenarios

### Scenario #1: **Social Engineering + Public Info**

**Target:** John Smith

**Step 1 - Reconnaissance:**
```
Facebook profile:
- Education: Lincoln High School
- Favorite movie: Star Wars
- Born in: New York

LinkedIn:
- Mother's name mentioned: Mary Johnson
```

---

**Step 2 - Password Reset:**
```
Q: What high school did you attend?
A: Lincoln High School ✓

Q: What is your favorite movie?
A: Star Wars ✓

Q: What is your mother's maiden name?
A: Johnson ✓

→ Password reset successful!
```

---

### Scenario #2: **Brute-Force Attack**

**Target:** Jane Doe

**Security question:** "What was your first car?"

---

**Brute-force script:**
```bash
#!/bin/bash

# Top 50 car models
cars=(
  "Honda Civic"
  "Toyota Corolla"
  "Ford Focus"
  "Volkswagen Golf"
  "Honda Accord"
  # ... 45 more
)

for car in "${cars[@]}"; do
  echo "Trying: $car"
  response=$(curl -s -X POST /reset-password \
    -d "username=janedoe&answer=$car")
  
  if echo "$response" | grep -q "success"; then
    echo "SUCCESS! Answer: $car"
    exit 0
  fi
done
```

---

### Scenario #3: **Multiple Weak Questions**

**Target:** Mike Johnson

**Questions required:** 2

---

**Q1:** "What is your favorite color?"
**Answers:** ~20 common colors

**Q2:** "What is your favorite sports team?"
**Answers:** ~30 popular teams

**Total combinations:** 20 × 30 = **600**

→ Brute-forcible!

---

## Comprehensive Testing Checklist

### Question Analysis:
```
☐ Enumerate all security questions
☐ Categorize questions (weak/strong)
☐ Identify questions known to family/friends
☐ Identify easily guessable questions
☐ Identify brute-forcible questions
☐ Identify publicly discoverable questions
☐ Check if self-generated questions allowed
☐ Test weak self-generated questions
```

---

### Brute-Force Testing:
```
☐ Determine number of questions required
☐ Identify weakest question
☐ Estimate answer set size
☐ Test for lockout mechanism
☐ Calculate brute-force feasibility
☐ Attempt brute-force attack
```

---

### Social Engineering:
```
☐ Research target on social media
☐ Check Facebook, LinkedIn, Twitter
☐ Review public records
☐ Identify family members
☐ Collect potential answers
☐ Attempt password reset
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs/Módszer |
|-------|-----------------|
| Enumerate questions | Create account or trigger password reset |
| Test weak question | Check if answer on social media |
| Self-generated test | `curl -X POST /set-question -d "question=1+1?&answer=2"` |
| Brute-force colors | Loop through 20 common colors |
| Brute-force names | Loop through top 100 first names |
| Social engineering | Facebook/LinkedIn research |

---

## Fontos Toolok

### Manual:
- **curl** - Testing
- **Browser** - Account creation

### Reconnaissance:
- **Facebook** - Personal info
- **LinkedIn** - Professional info
- **Google** - General search
- **Sherlock** - Username OSINT

### Brute-Force:
- **Burp Intruder** - Automated attempts
- **Custom scripts** - Answer lists

---

## Védelem (Remediation)

### 1. **Use Strong Pre-Generated Questions:**

**BAD Questions:**
```
❌ Mother's maiden name
❌ Favorite color
❌ First car
❌ High school
❌ Favorite movie
```

**BETTER Questions:**
```
✓ What was the name of your first stuffed animal?
✓ What was the street name of your childhood best friend?
✓ What was the model of your first bicycle?
```

**But even better:** Don't use security questions!

---

### 2. **Don't Allow Self-Generated Questions:**

**BAD:**
```
User can create: "What is 1+1?"
```

**GOOD:**
```
Only pre-vetted questions allowed
```

---

### 3. **Require Multiple Questions:**

```python
# Require 3 out of 5 questions answered correctly
def verify_security_questions(answers):
    correct = 0
    for i, answer in enumerate(answers):
        if verify_answer(i, answer):
            correct += 1
    
    return correct >= 3  # 3 out of 5
```

---

### 4. **Rate Limiting:**

```python
from datetime import datetime, timedelta

MAX_ATTEMPTS = 5
LOCKOUT_DURATION = timedelta(hours=1)

def check_security_answer(username, answer):
    attempts = get_failed_attempts(username)
    
    if attempts >= MAX_ATTEMPTS:
        # Check if lockout expired
        last_attempt = get_last_attempt_time(username)
        if datetime.now() - last_attempt < LOCKOUT_DURATION:
            return False, "Account locked. Try again in 1 hour."
    
    # Verify answer
    if verify_answer(username, answer):
        reset_failed_attempts(username)
        return True, "Correct"
    else:
        increment_failed_attempts(username)
        return False, f"Incorrect. {MAX_ATTEMPTS - attempts - 1} attempts remaining."
```

---

### 5. **Case-Insensitive + Trim:**

```python
def normalize_answer(answer):
    # Case-insensitive
    answer = answer.lower()
    
    # Trim whitespace
    answer = answer.strip()
    
    # Remove extra spaces
    answer = ' '.join(answer.split())
    
    return answer

stored_answer = "New York"
user_answer = "  new york  "

if normalize_answer(user_answer) == normalize_answer(stored_answer):
    # Correct!
```

---

### 6. **Alternative: Email/SMS Verification:**

**Instead of security questions:**
```python
@app.route('/forgot-password', methods=['POST'])
def forgot_password():
    email = request.form['email']
    user = User.query.filter_by(email=email).first()
    
    if user:
        # Generate reset token
        token = generate_reset_token()
        
        # Send email with token
        send_email(
            to=email,
            subject="Password Reset",
            body=f"Click here to reset: {SITE_URL}/reset?token={token}"
        )
    
    return "If email exists, reset link sent"
```

**Better:** SMS OTP

---

### 7. **Best Solution: Don't Use Security Questions!**

**Modern alternatives:**
- Email verification
- SMS OTP
- Authenticator app (TOTP)
- Backup codes
- Account recovery via support

---

## Real-World Statistics

**Most common security questions:**
```
1. Mother's maiden name (42%)
2. Favorite pet's name (31%)
3. City of birth (28%)
4. High school name (24%)
5. Favorite color (19%)
```

**Answer guessability:**
```
Favorite color: ~20 options
First car: ~50 popular models
Pet's name: ~100 common names
Mother's maiden name: ~1000 common surnames
```

→ All brute-forcible!

---

## Fontos Megjegyzések

✅ **Email/SMS verification** > Security questions  
✅ **Multiple questions** (3/5) = harder  
✅ **Rate limiting** = prevent brute-force  
✅ **Case-insensitive** comparison  
❌ **Mother's maiden name** = weak!  
❌ **Favorite color** = ~20 options only!  
❌ **Self-generated** = "1+1?" bypass!  
⚠️ **Social media** = answer goldmine!  
⚠️ **No lockout** = brute-force vulnerable!  
⚠️ **Single question** = easier to crack!

---

**Összefoglalva:** Ez a fejezet a **security questions** weakness-ek teszteléséről szól. **Pre-generated questions** (mother's maiden name, favorite color, first car) **weak** - **family knows**, **easily guessable**, **brute-forcible** (~20-100 options), vagy **publicly discoverable** (Facebook, LinkedIn). **Self-generated questions** még **rosszabb** - users create "1+1?" vagy "My password is X". **Attack**: **social engineering** (Facebook research) + **brute-force** (top 50 cars, 20 colors). **Defense**: **DON'T use security questions**! Use **email/SMS verification** instead. Ha muszáj: **multiple questions** (3/5), **rate limiting** (5 attempts), **no self-generated**. **OWASP recommends**: avoid security questions entirely!
