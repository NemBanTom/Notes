# WSTG-ATHN-09: Weak Password Change/Reset Functionality Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **password reset/change** mechanizmusok **weak implementation**-je **account takeover**-t tesz lehetővé. **Predictable tokens**, **no expiry**, **missing rate limiting**, **CSRF**, vagy **user ID manipulation** mind **unauthorized password change**-hez vezethetnek.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM egyszerű password policy testing! Ez a **reset/change folyamat** sebezhetőségeinek tesztelése - token security, rate limiting, CSRF, stb.

---

## Mi a cél?

**Password reset/change** vulnerability-k azonosítása:
- Weak token generation
- Missing token expiry
- No rate limiting
- CSRF vulnerabilities
- User ID manipulation
- MFA bypass

---

## 4 Password Reset Módszer

### 1. **Email - New Password**
### 2. **Email - Reset Link with Token**
### 3. **SMS/Phone - Token**
### 4. **Security Questions**

---

## 1. Email - New Password

### Concept:
**New password generated** és **emailben elküldve**.

---

### Vulnerabilities:

**Issue #1 - Unencrypted Email:**
```
Password sent: MyNewPassword123
→ Plaintext in email!
→ Stays in inbox forever!
```

**Issue #2 - Password Changed Immediately:**
```
Attacker requests reset for victim@example.com
→ Password immediately changed
→ Victim locked out!
→ Repeated requests = DoS
```

**Issue #3 - Existing Password Sent:**
```
Email: "Your password is: OldPassword123"
→ CRITICAL! Passwords stored in plaintext!
```

---

### Testing:

```bash
# Request password reset
curl -X POST /forgot-password \
  -d "email=victim@example.com"

# Check email
# Password sent in plaintext? → VULNERABLE

# Try again immediately
curl -X POST /forgot-password \
  -d "email=victim@example.com"

# Victim locked out? → DoS vulnerability
```

---

## 2. Email - Reset Link with Token

### Concept:
**Reset link** with **token** emailed → user clicks → set new password.

---

### Token Security Checklist:

#### 1. **HTTPS Usage:**

```bash
# Check reset link
https://site.com/reset?token=abc123  ✓ Secure
http://site.com/reset?token=abc123   ✗ Token exposed!
```

---

#### 2. **Single Use:**

```bash
# Use token once
curl -X POST /reset-password \
  -d "token=abc123&new_password=NewPass123"

# Try using same token again
curl -X POST /reset-password \
  -d "token=abc123&new_password=Hacked456"

# If successful second time:
# → Token reusable! (persistent backdoor)
```

---

#### 3. **Token Expiry:**

```bash
# Generate reset token
curl -X POST /forgot-password -d "email=test@test.com"

# Wait 2 hours (or change system time)
# Try using old token

curl -X POST /reset-password \
  -d "token=abc123&new_password=NewPass"

# If successful after long time:
# → No expiry! (or too long)
```

**Recommendation:** 15-60 minutes expiry

---

#### 4. **Token Randomness:**

**Weak token generation:**
```python
# BAD!
token = md5(email)  # Predictable!
token = str(user_id) + str(timestamp)  # Guessable!
```

**Strong token generation:**
```python
import secrets
token = secrets.token_urlsafe(32)  # 32 bytes = 256 bits
# → "Xj8K2m9Qn4Lp7Rt6Wv3Yz1Bc5Df8Gh..."
```

---

**Testing:**
```bash
# Generate multiple tokens
for i in {1..10}; do
  curl -X POST /forgot-password -d "email=test$i@test.com"
done

# Collect tokens, analyze for patterns
# Sequential? Timestamp-based? Predictable?
```

---

#### 5. **Token Length:**

**Weak:**
```
Token: 123456 (6 digits = 1M combinations)
→ Brute-forcible!
```

**Strong:**
```
Token: Xj8K2m9Qn4Lp7Rt6... (32+ chars)
→ Impractical to brute-force
```

**Minimum:** 128 bits (32 hex chars)

---

#### 6. **User ID in URL:**

**Vulnerable:**
```
https://site.com/reset?userid=123&token=abc123
                       ↑ Can modify!
```

**Attack:**
```bash
# Original link (for user 123)
curl -X POST /reset-password \
  -d "userid=123&token=abc123&new_password=Pass1"

# Modified (for user 456 - admin!)
curl -X POST /reset-password \
  -d "userid=456&token=abc123&new_password=Hacked!"

# If successful:
# → Can reset ANY user's password with valid token!
```

---

#### 7. **Host Header Injection:**

**Concept:**
App uses `Host` header to generate reset link.

**Attack:**
```bash
# Send reset request with malicious Host header
curl -X POST /forgot-password \
  -H "Host: attacker.com" \
  -d "email=victim@example.com"

# Email sent with:
https://attacker.com/reset?token=abc123
      ↑ Attacker's domain!

# Victim clicks link
# → Token sent to attacker!
```

---

#### 8. **Referer Leakage:**

**Vulnerable page:**
```html
<!-- Reset password page -->
<script src="https://analytics.com/tracking.js"></script>

<!-- Token in URL: /reset?token=abc123 -->
<!-- Request to analytics.com includes Referer header! -->

GET /tracking.js HTTP/1.1
Host: analytics.com
Referer: https://site.com/reset?token=abc123
                                 ↑ Token leaked!
```

**Defense:** `Referrer-Policy: no-referrer`

---

## 3. SMS/Phone - Token

### Concept:
**Short token** (usually 6 digits) sent via **SMS** or **phone call**.

---

### Vulnerabilities:

#### 1. **Short Token (6 digits):**

```
Token: 123456
Combinations: 10^6 = 1,000,000
→ Brute-forcible if no rate limiting!
```

**Attack:**
```bash
# Brute-force 6-digit token
for token in {000000..999999}; do
  curl -X POST /verify-reset-token \
    -d "phone=+1234567890&token=$token"
done
```

**Without rate limiting:** 1M attempts = compromise!

---

#### 2. **No Expiry:**

```bash
# Receive SMS token: 123456
# Wait 1 week
# Token still valid?
# → VULNERABLE!
```

**Recommendation:** 5-10 minutes expiry

---

#### 3. **SMS Hijacking:**

**Attacks:**
- SIM swapping
- SS7 exploitation
- Malware (SMS interception)

**NCSC:** SMS not recommended for critical authentication!

---

#### 4. **Rate Limiting (SMS Costs):**

```bash
# Attacker triggers 10,000 SMS
for i in {1..10000}; do
  curl -X POST /send-reset-sms -d "phone=+1234567890"
done

# Company charged for all SMS!
# → Financial DoS
```

---

## 4. Security Questions

**See WSTG-ATHN-08!**

**Summary:** Weak authentication method, not recommended!

---

## Password Change (Authenticated)

### Vulnerabilities:

#### 1. **No Re-Authentication:**

```bash
# Logged in user changes password
curl -X POST /change-password \
  -H "Cookie: session=abc123" \
  -d "new_password=NewPass123"

# No current password required?
# → Session hijacking = password change!
```

---

#### 2. **CSRF Vulnerability:**

**Attack page:**
```html
<!-- Attacker's page -->
<form action="https://victim.com/change-password" method="POST">
  <input type="hidden" name="new_password" value="Hacked123">
</form>
<script>document.forms[0].submit();</script>
```

**Victim visits attacker's page:**
```
1. Form auto-submits
2. Password changed to "Hacked123"
3. Attacker logs in with new password
```

---

#### 3. **User ID Manipulation:**

**Vulnerable:**
```bash
POST /change-password HTTP/1.1
{
  "user_id": "123",  ← Can modify!
  "new_password": "Pass123"
}

# Change to user_id=456 (admin)
# → Reset admin password!
```

---

## Email Configuration Changes

### Concept:
**Email change** without **re-authentication** → **reset bypass**.

---

### Attack Scenario:

```
1. Attacker compromises session (stolen cookie)
2. Changes email from victim@company.com to attacker@evil.com
   (no re-authentication required!)
3. Uses "Forgot Password" feature
4. Reset link sent to attacker@evil.com
5. Attacker sets new password
6. Full account takeover!
```

**Defense:** Require re-authentication for email change!

---

## Comprehensive Testing Checklist

### Email-Based Reset:
```
☐ HTTPS for reset link?
☐ Token single-use?
☐ Token expiry (15-60 min)?
☐ Token randomness (128+ bits)?
☐ Token length (32+ chars)?
☐ User ID in URL manipulable?
☐ Host header injection?
☐ Referer leakage?
☐ SPF/DKIM/DMARC configured?
☐ Force password change on first login?
```

---

### SMS/Phone-Based:
```
☐ Token length (6+ digits)?
☐ Token expiry (5-10 min)?
☐ Rate limiting on SMS sending?
☐ Rate limiting on token verification?
☐ Token single-use?
☐ International/premium number blocking?
```

---

### Password Change:
```
☐ Re-authentication required?
☐ CSRF protection?
☐ User ID validation?
☐ Strong password policy?
☐ MFA not bypassed?
```

---

### Email/Config Changes:
```
☐ Re-authentication for email change?
☐ Re-authentication for phone change?
☐ Re-authentication for MFA changes?
☐ Notification sent to old email?
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Request reset | `curl -X POST /forgot-password -d "email=..."` |
| Token reuse | Use same token twice |
| Token expiry | Wait 2 hours, use token |
| User ID manip | Modify `userid` parameter |
| Host injection | `curl -H "Host: evil.com" /forgot-password` |
| CSRF | Create auto-submit form |
| SMS brute-force | Loop 000000-999999 |

---

## Fontos Toolok

### Manual:
- **curl** - Testing requests
- **Burp Suite** - Intercept/modify

### Brute-Force:
- **Burp Intruder** - Token brute-force
- **Custom scripts** - Automated attacks

---

## Védelem (Remediation)

### 1. **Secure Token Generation:**

```python
import secrets
from datetime import datetime, timedelta

def create_reset_token(user_id):
    # Generate cryptographically secure token
    token = secrets.token_urlsafe(32)  # 256 bits
    
    # Store with expiry
    expires = datetime.now() + timedelta(minutes=30)
    
    db.execute(
        "INSERT INTO reset_tokens (token_hash, user_id, expires_at) VALUES (?, ?, ?)",
        (hashlib.sha256(token.encode()).hexdigest(), user_id, expires)
    )
    
    return token
```

---

### 2. **Token Validation:**

```python
def validate_reset_token(token):
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    
    result = db.execute(
        "SELECT user_id, expires_at, used FROM reset_tokens WHERE token_hash=?",
        (token_hash,)
    ).fetchone()
    
    if not result:
        return None, "Invalid token"
    
    user_id, expires_at, used = result
    
    # Check if already used
    if used:
        return None, "Token already used"
    
    # Check expiry
    if datetime.now() > expires_at:
        return None, "Token expired"
    
    # Mark as used
    db.execute("UPDATE reset_tokens SET used=1 WHERE token_hash=?", (token_hash,))
    
    return user_id, "Valid"
```

---

### 3. **Rate Limiting:**

```python
from flask_limiter import Limiter

@app.route('/forgot-password', methods=['POST'])
@limiter.limit("3 per hour")  # 3 requests per hour per IP
def forgot_password():
    email = request.form['email']
    # ... send reset email ...
```

---

### 4. **CSRF Protection:**

```python
from flask_wtf.csrf import CSRFProtect

csrf = CSRFProtect(app)

@app.route('/change-password', methods=['POST'])
@csrf_protect  # CSRF token required
def change_password():
    # Verify current password
    if not verify_password(current_user, request.form['old_password']):
        return "Invalid current password", 403
    
    # Change password
    update_password(current_user, request.form['new_password'])
```

---

### 5. **Re-Authentication for Critical Changes:**

```python
@app.route('/change-email', methods=['POST'])
def change_email():
    # Require password confirmation
    if not verify_password(current_user, request.form['password']):
        return "Re-authentication required", 403
    
    old_email = current_user.email
    new_email = request.form['new_email']
    
    # Update email
    current_user.email = new_email
    current_user.save()
    
    # Notify old email
    send_email(old_email, "Email changed", "Your email was changed to: " + new_email)
```

---

### 6. **Referrer-Policy Header:**

```python
@app.route('/reset-password')
def reset_password_page():
    response = make_response(render_template('reset.html'))
    response.headers['Referrer-Policy'] = 'no-referrer'
    return response
```

---

## Fontos Megjegyzések

✅ **128+ bit token** (32+ hex chars)  
✅ **Single-use tokens** only  
✅ **15-60 min expiry** for email tokens  
✅ **5-10 min expiry** for SMS tokens  
✅ **Rate limiting** on all endpoints  
✅ **CSRF protection** on password change  
✅ **Re-authentication** for critical changes  
✅ **Referrer-Policy: no-referrer**  
❌ **Plaintext password** in email = CRITICAL!  
❌ **Reusable tokens** = persistent backdoor!  
❌ **No expiry** = indefinite vulnerability!  
❌ **6-digit SMS** without rate limit = brute-forcible!  
⚠️ **User ID in URL** = manipulation risk!  
⚠️ **Host header injection** = token theft!  
⚠️ **Email change** without re-auth = bypass!

---

**Összefoglalva:** Ez a fejezet a **password reset/change** mechanizmusok teszteléséről szól. **Email-based reset**: **token must be 128+ bits**, **single-use**, **15-60 min expiry**, **HTTPS only**, **no user ID in URL**. **SMS-based**: **6 digits weak** (brute-forcible), **5-10 min expiry**, **rate limiting critical**. **Password change**: **re-authentication required**, **CSRF protection**, **no user ID manipulation**. **Email change**: **MUST require re-authentication** (bypass prevention). **Common vulnerabilities**: **predictable tokens** (md5(email)), **no expiry**, **reusable tokens**, **Host header injection**, **Referer leakage**, **CSRF**. **Defense**: **secrets.token_urlsafe(32)**, **single-use + expiry**, **rate limiting**, **Referrer-Policy: no-referrer**, **CSRF tokens**!
