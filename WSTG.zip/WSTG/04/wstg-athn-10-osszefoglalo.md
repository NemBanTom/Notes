# WSTG-ATHN-10: Weaker Authentication in Alternative Channel Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy **alternative authentication channels** (mobile site, desktop app, call center) **weaker authentication**-t használhatnak mint a **primary channel**, így **easier attack vector**-ként szolgálhatnak. **Mobile site HTTP** vs **main site HTTPS**, vagy **weaker password recovery** mobile-on mind **security bypass** lehetőségek.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM különböző authentication method-ok (password vs MFA)! Ez **different channel-ek** (web vs mobile vs app) authentication strength-jének összehasonlítása.

---

## Mi a cél?

**Alternative channels** azonosítása és gyengeségei:
- Identify all authentication channels
- Compare security measures across channels
- Identify weaker channels
- Test for bypasses via alternative channels

---

## Alternative Channels Példák

### Web-Based Channels:
```
- Standard website: www.example.com
- Mobile website: m.example.com
- Accessibility site: accessible.example.com
- Country-specific: uk.example.com, de.example.com
- Language variants: en.example.com, es.example.com
- Partner sites: partner.example.com
- Development/staging: dev.example.com, staging.example.com
```

---

### Application-Based Channels:
```
- Mobile app (iOS/Android)
- Desktop application
- Tablet app
- Smart TV app
- Smart watch app
- Browser extension
```

---

### Non-Digital Channels:
```
- Call center operators
- Interactive Voice Response (IVR)
- Phone tree systems
- SMS helpline
- Email support
```

---

## Common Weaknesses

### Weakness #1: **HTTP vs HTTPS**

**Primary:**
```
https://www.example.com/login
→ TLS encrypted, secure
```

**Mobile:**
```
http://m.example.com/login
→ No encryption!
→ Credentials sent in plaintext!
```

→ **CRITICAL!** Attack mobile channel!

---

### Weakness #2: **Weaker Password Reset**

**Primary:**
```
www.example.com/reset
- 128-bit token
- 30 min expiry
- Rate limiting: 3 attempts/hour
- Email verification
```

**Mobile:**
```
m.example.com/reset
- 6-digit token
- No expiry
- No rate limiting
- SMS only (SIM swapping vulnerable)
```

→ **HIGH!** Mobile easier to attack!

---

### Weakness #3: **Missing MFA**

**Primary:**
```
www.example.com/login
→ Username + Password + TOTP (MFA required)
```

**Mobile App:**
```
MobileApp login
→ Username + Password (NO MFA!)
```

→ **HIGH!** MFA bypassed via mobile!

---

### Weakness #4: **Weaker Call Center Authentication**

**Website:**
```
Login requires:
- Username
- Password
- TOTP code
```

**Call Center:**
```
Identity verification:
- Date of birth
- Last 4 digits of SSN
- Mother's maiden name
```

→ **MEDIUM!** Social engineering easier!

---

### Weakness #5: **Session Sharing**

**Scenario:**
```
1. Login on www.example.com (strong auth)
2. Session cookie: domain=.example.com
3. Access m.example.com (weak auth)
4. Same session valid!
5. m.example.com has weaker password reset
6. Attacker uses m.example.com to compromise account
```

→ Weak channel undermines strong channel!

---

## Testing Methodology

### Step 1: **Identify Primary Mechanism**

**Test primary website:**
```
URL: https://www.example.com

Authentication features:
✓ Login (HTTPS, MFA)
✓ Register (email verification)
✓ Password reset (secure token, 30 min expiry)
✓ Password change (re-authentication required)
✓ Logout (session invalidation)
```

**Document all security measures!**

---

### Step 2: **Discover Alternative Channels**

#### Method A: **Website Content**

**Check:**
```
- Home page (mobile app links)
- Contact Us (phone numbers, email)
- Help/FAQ (alternative access methods)
- T&Cs (mentions of mobile app, etc.)
- Privacy policy (data processing channels)
- robots.txt (hidden paths)
- sitemap.xml (all pages)
```

---

#### Method B: **Search Subdomains**

```bash
# Subdomain enumeration
amass enum -d example.com

# Common mobile subdomains
curl https://m.example.com
curl https://mobile.example.com
curl https://app.example.com
```

---

#### Method C: **Search Proxy Logs**

```bash
# Search for mobile-related strings
grep -i "mobile\|android\|iphone\|ipad" proxy_logs.txt

# Search for auth-related paths
grep -i "auth\|sso\|login\|signin" proxy_logs.txt
```

---

#### Method D: **App Store Search**

```
Search App Store: "Example Company"
Search Google Play: "Example Company"

Found:
- Example Mobile App (iOS)
- Example Business App (Android)
```

---

#### Method E: **Google Dorking**

```
site:example.com "mobile"
site:example.com "app download"
site:example.com inurl:mobile
site:example.com inurl:m.
```

---

### Step 3: **Enumerate Authentication Functions**

**Create comparison matrix:**

| Feature | Primary Website | Mobile Site | Mobile App | Call Center |
|---------|----------------|-------------|------------|-------------|
| **Register** | ✓ (email verify) | ✓ (SMS only) | ✓ (in-app) | ✗ |
| **Login** | ✓ (HTTPS + MFA) | ✓ (HTTP!) | ✓ (no MFA!) | ✓ (DOB + SSN) |
| **Logout** | ✓ | ✗ | ✓ | N/A |
| **Password Reset** | ✓ (128-bit, 30min) | ✓ (6-digit!) | ✓ (email) | ✓ (operator sets) |
| **Password Change** | ✓ (re-auth) | ✗ | ✓ (no re-auth!) | ✗ |
| **MFA Enroll** | ✓ | ✗ | ✗ | ✗ |

**Findings:**
- Mobile site: HTTP (no TLS!)
- Mobile app: No MFA requirement
- Mobile site: 6-digit reset token (weak!)
- Mobile app: Password change without re-auth
- Call center: DOB + SSN (social engineering!)

---

### Step 4: **Test Weakest Channel**

**Target:** Mobile site (weakest)

```bash
# Test HTTP (plaintext credentials)
curl -v http://m.example.com/login \
  -d "username=victim&password=test"

# Check if credentials in plaintext
# → YES! HTTP = CRITICAL!

# Test password reset
curl -X POST http://m.example.com/reset \
  -d "phone=+1234567890"

# Received SMS: 123456 (6 digits)

# Brute-force
for token in {000000..999999}; do
  curl -X POST http://m.example.com/verify-reset \
    -d "phone=+1234567890&token=$token&new_password=Hacked123"
done

# If no rate limiting:
# → Account compromise via mobile channel!
```

---

## Attack Scenarios

### Scenario #1: **HTTP Mobile Site**

**Setup:**
```
Primary: https://www.example.com (HTTPS)
Mobile: http://m.example.com (HTTP!)
Shared accounts: YES
```

**Attack:**
```
1. Attacker sets up WiFi hotspot (coffee shop, airport)
2. Victim connects to hotspot
3. Victim accesses m.example.com (HTTP)
4. Attacker intercepts traffic (MITM)
5. Credentials captured in plaintext
6. Attacker logs into www.example.com
```

→ **CRITICAL!** HTTP mobile = credential theft!

---

### Scenario #2: **Weaker Password Reset**

**Setup:**
```
Primary: 128-bit token, 30 min expiry
Mobile: 6-digit token, no expiry, no rate limit
```

**Attack:**
```
1. Attacker triggers reset on mobile: m.example.com/reset
2. Victim receives SMS: 123456
3. Attacker brute-forces: 000000-999999
4. No rate limiting → Success!
5. Password reset via mobile
6. Attacker logs into primary site
```

→ **HIGH!** Weak channel = account takeover!

---

### Scenario #3: **MFA Bypass**

**Setup:**
```
Primary: MFA required
Mobile App: MFA NOT required
```

**Attack:**
```
1. Attacker obtains username/password (phishing, breach)
2. Cannot login on primary (MFA blocks)
3. Uses mobile app instead
4. No MFA challenge!
5. Access granted
```

→ **HIGH!** Mobile app bypasses MFA!

---

### Scenario #4: **Call Center Social Engineering**

**Setup:**
```
Website: Password + MFA
Call Center: DOB + Last 4 SSN
```

**Attack:**
```
1. Attacker researches victim (Facebook: DOB)
2. Obtains SSN from data breach
3. Calls support: "I forgot my password"
4. Provides DOB + SSN
5. Operator resets password
6. Attacker logs in
```

→ **MEDIUM!** Call center = weak link!

---

## Comprehensive Testing Checklist

### Discovery:
```
☐ Enumerate all website variants (m., mobile., app.)
☐ Check for mobile apps (iOS, Android)
☐ Check for desktop applications
☐ Identify call center / IVR
☐ Search for partner sites (SSO)
☐ Check staging/dev sites
```

---

### Channel Comparison:
```
☐ Compare TLS usage (HTTPS vs HTTP)
☐ Compare MFA requirements
☐ Compare password reset mechanisms
☐ Compare session management
☐ Compare authentication factors
☐ Compare rate limiting
☐ Compare password policies
```

---

### Testing:
```
☐ Test weakest channel first
☐ Verify if accounts shared across channels
☐ Test password reset on each channel
☐ Test MFA on each channel
☐ Test session sharing
☐ Test for privilege escalation via weaker channel
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs/Módszer |
|-------|-----------------|
| Find mobile site | `curl http://m.example.com` |
| Check HTTPS | `curl -I http://m.example.com` (301 redirect?) |
| Subdomain enum | `amass enum -d example.com` |
| App search | Search App Store / Google Play |
| Test mobile reset | `curl -X POST http://m.example.com/reset` |
| Compare features | Create matrix table |

---

## Fontos Toolok

### Discovery:
- **amass** - Subdomain enumeration
- **Sublist3r** - Subdomain finder
- **Google** - Dorking

### Testing:
- **curl** - HTTP testing
- **Burp Suite** - Proxy & testing
- **Mobile device** - App testing

---

## Védelem (Remediation)

### 1. **Consistent Security Policy Across Channels:**

```
ALL channels must enforce:
✓ HTTPS (TLS 1.2+)
✓ MFA requirement
✓ Strong password reset (128-bit token, expiry)
✓ Rate limiting
✓ Same password policy
✓ Re-authentication for critical actions
```

---

### 2. **Enforce HTTPS on All Channels:**

**Primary:**
```
https://www.example.com ✓
```

**Mobile:**
```
http://m.example.com ✗

MUST redirect:
http://m.example.com → https://m.example.com
```

**Implementation:**
```apache
# Apache: Redirect HTTP to HTTPS
<VirtualHost *:80>
    ServerName m.example.com
    Redirect permanent / https://m.example.com/
</VirtualHost>
```

---

### 3. **MFA on All Channels:**

```python
# ALL login endpoints must enforce MFA
@app.route('/login', methods=['POST'])
def login():
    user = authenticate(username, password)
    
    if user:
        # MFA required on ALL channels!
        if not user.mfa_enabled:
            return "MFA enrollment required", 403
        
        # Send MFA challenge
        send_mfa_challenge(user)
        return redirect('/verify-mfa')
```

---

### 4. **Consistent Password Reset:**

```python
# Same reset mechanism across ALL channels
def create_reset_token():
    # 128-bit token
    token = secrets.token_urlsafe(32)
    
    # 30 min expiry
    expires = datetime.now() + timedelta(minutes=30)
    
    return token, expires

# Use on web, mobile, app, everywhere!
```

---

### 5. **No Session Sharing Across Security Levels:**

```python
# If channels have different security:
# DON'T share sessions!

# Primary (high security):
session_cookie = {
    'domain': 'www.example.com',  # Specific subdomain
    'secure': True,
    'httponly': True,
    'samesite': 'Strict'
}

# Mobile (if weaker, separate sessions):
mobile_session = {
    'domain': 'm.example.com',  # Different subdomain
    # ... separate session management
}
```

---

### 6. **Call Center Security:**

```
Call Center Authentication:
✓ Same factors as website
✓ Knowledge-based questions
✓ Callback to registered phone
✓ Require customer service PIN
✓ Record all interactions
✓ Escalate sensitive changes to higher tier
```

---

## Fontos Megjegyzések

✅ **ALL channels** must have **equal security**  
✅ **HTTPS** on mobile site mandatory  
✅ **MFA** required on all channels  
✅ **Consistent** password reset across channels  
✅ **Same** password policy everywhere  
✅ **No session sharing** across security levels  
❌ **HTTP mobile site** = credential theft!  
❌ **No MFA on app** = MFA bypass!  
❌ **6-digit reset token** on mobile = weak!  
⚠️ **Call center** = social engineering risk!  
⚠️ **Staging sites** may have weak auth!  
⚠️ **Partner SSO** = shared vulnerability!

---

**Összefoglalva:** Ez a fejezet az **alternative authentication channels** gyengeségeinek teszteléséről szól. **Multiple channels** (www, m., mobile app, call center) **different security levels**-t használhatnak. **Common weaknesses**: **mobile site HTTP** (plaintext credentials), **mobile app no MFA** (MFA bypass), **6-digit SMS reset** on mobile (brute-forcible), **call center DOB+SSN** (social engineering). **Attack**: **identify weakest channel** → **exploit weakness** → **compromise account** → **access via primary**. **Testing**: **enumerate all channels** (subdomains, apps, call center), **compare authentication** (create matrix), **test weakest first**. **Defense**: **consistent security policy** across ALL channels - **HTTPS**, **MFA**, **strong password reset**, **rate limiting**, **same password policy** everywhere!
