# WSTG-ATHN-11: Multi-Factor Authentication (MFA) Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **MFA (Multi-Factor Authentication)** implementációk **weakness-ei** és **bypass**-ai lehetővé teszik az **authentication bypass**-t. **Weak OTP**, **MFA not enforced**, **recovery code** weakness, vagy **IP-based bypass** mind **second factor** megkerülését jelentik.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános authentication testing! Ez specifikusan **MFA implementation** weakness-ek - **second factor** security, **bypass lehetőségek**, **recovery mechanisms**.

---

## Mi a cél?

**MFA** vulnerability-k azonosítása:
- MFA bypass methods
- Weak OTP implementation
- Recovery code weakness
- IP-based bypass
- Certificate validation issues

---

## MFA Types (Authentication Factors)

| Factor | Examples |
|--------|----------|
| **Something You Know** | Password, PIN, security question |
| **Something You Have** | TOTP app, SMS, email, certificate, smartcard |
| **Something You Are** | Fingerprint, face recognition, iris scan |
| **Somewhere You Are** | IP address, geolocation |

**TRUE MFA:** At least **2 different factors**!

**NOT MFA:** Password + PIN (both "something you know")

---

## Common MFA Bypass Methods

### Bypass #1: **Direct Access After Step 1**
### Bypass #2: **MFA Not Enforced on All Endpoints**
### Bypass #3: **IP-Based Bypass (X-Forwarded-For)**
### Bypass #4: **Weak Recovery Codes**
### Bypass #5: **OIDC Flow Tampering**

---

## Bypass #1: Direct Access After Step 1

### Concept:
Complete **step 1** (username + password) → **directly access** application **without** step 2 (MFA).

---

### Attack:

```bash
# Step 1: Login with password
curl -X POST /login \
  -d "username=victim&password=Pass123" \
  -c cookies.txt

# Response: Redirect to /mfa-verify

# Step 2: Skip MFA, direct access to app
curl /dashboard -b cookies.txt

# If 200 OK:
# → MFA bypass! Direct access without MFA!
```

---

**Secure implementation:**
```
Session after step 1: partial_auth=true, mfa_verified=false
Application checks: if (!mfa_verified) → reject
Only after MFA: mfa_verified=true → access granted
```

---

## Bypass #2: MFA Not Enforced on All Endpoints

### Concept:
**Main login** requires MFA, but **API/mobile endpoints** don't.

---

### Attack:

```bash
# Web login: MFA required
curl -X POST /web/login \
  -d "username=victim&password=Pass"
# → Requires MFA code

# API login: NO MFA?
curl -X POST /api/login \
  -d "username=victim&password=Pass"
# → 200 OK, access granted WITHOUT MFA!
```

---

**Test all endpoints:**
- Web interface
- Mobile API
- Desktop app
- Legacy endpoints
- Debug/test endpoints

---

## Bypass #3: IP-Based Bypass (X-Forwarded-For)

### Concept:
**Trusted IP** ranges skip MFA. **Spoof** IP with **X-Forwarded-For** header.

---

### Attack:

```bash
# Normal request: MFA required
curl -X POST /login \
  -d "username=victim&password=Pass"
# → Requires MFA

# Spoofed IP (from trusted range)
curl -X POST /login \
  -H "X-Forwarded-For: 192.168.1.100" \
  -d "username=victim&password=Pass"

# If 192.168.1.0/24 is trusted:
# → MFA skipped! Access granted!
```

---

**Vulnerable code:**
```python
# BAD! Trusts X-Forwarded-For
client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)

if client_ip in TRUSTED_IPS:
    # Skip MFA
    return login_success()
```

---

## Bypass #4: Weak Recovery Codes

### Concept:
**Recovery codes** allow MFA bypass if **weak** or **reusable**.

---

### Weak Implementation:

```
Recovery codes:
123456
234567
345678
...
```

**Issues:**
- Sequential (predictable!)
- 6 digits only (1M combinations)
- Reusable (no single-use enforcement)

---

### Attack:

```bash
# Brute-force recovery codes
for code in {000000..999999}; do
  curl -X POST /mfa-verify \
    -d "username=victim&recovery_code=$code"
done

# If no rate limiting:
# → Code found! MFA bypassed!
```

---

**Secure implementation:**
```python
# Generate recovery codes
recovery_codes = []
for i in range(10):
    code = secrets.token_hex(8)  # 16 hex chars
    recovery_codes.append(code)

# Example: a3f7d9e2b4c8f1a6

# Store hashed
# Mark as used after first use
# Rate limit verification attempts
```

---

## Bypass #5: OIDC Flow Tampering

### Concept:
**Azure B2C** or similar with **multiple flows**, some **without MFA**.

---

### Attack:

```bash
# Normal flow with MFA
https://login.example.com/authorize?
  client_id=abc123&
  redirect_uri=https://app.com/callback&
  policy=B2C_1_SignInWithMFA
                    ↑ With MFA

# Tamper flow name
https://login.example.com/authorize?
  client_id=abc123&
  redirect_uri=https://app.com/callback&
  policy=B2C_1_SignIn
                    ↑ Without MFA?

# Try variations:
B2C_1_SignInWithoutMFA
B2C_1_SignUpOrSignIn
B2C_1_PasswordReset
```

**If different flow without MFA exists:**
→ **MFA bypass!**

---

## OTP (One-Time Password) Testing

### TOTP (Time-Based OTP):

**Concept:**
6-digit code, valid for **30 seconds**.

---

### Vulnerability #1: **Multiple Valid Codes**

**Weak implementation:**
```
Accept codes:
- Previous code (−30s)
- Current code
- Next code (+30s)
- Next+1 code (+60s)
- Next+2 code (+90s)

Total: 5 valid codes at once!
```

---

**Brute-force success rate:**

| Valid Codes | Success after 1h | Success after 4h | Success after 24h |
|-------------|------------------|------------------|-------------------|
| 1 | 4% | 13% | 58% |
| 3 | 10% | 35% | 92% |
| 5 | 16% | 51% | **99%** |

→ **More valid codes** = **easier brute-force**!

---

### Vulnerability #2: **No Rate Limiting**

```bash
# Brute-force 6-digit TOTP
for code in {000000..999999}; do
  curl -X POST /mfa-verify \
    -d "username=victim&otp=$code"
done

# 1,000,000 attempts
# At 10 req/sec = ~28 hours

# If 5 codes valid at once:
# → 99% success rate in 24 hours!
```

---

**Defense:**
```
Rate limiting:
- 5 attempts per account per hour
- Account lockout after 10 failures
- IP-based rate limiting
```

---

### SMS/Email OTP Testing:

**Vulnerabilities:**

**1. Short Code (6 digits):**
```
Code: 123456
Combinations: 1,000,000
→ Brute-forcible!
```

**2. No Expiry:**
```
Code sent: 10:00 AM
Still valid: 11:00 PM (13 hours later!)
→ Long attack window!
```

**3. Multiple Codes Valid:**
```
Request code 1: 123456
Request code 2: 234567
Both valid!
→ Can't lock out by requesting new codes
```

**4. Reusable:**
```
Use code: 123456
Use again: 123456
→ Still works!
```

---

## MFA Management Vulnerabilities

### Vulnerability #1: **Disable MFA Without Re-Auth**

```bash
# Logged in, disable MFA
curl -X POST /settings/disable-mfa \
  -H "Cookie: session=abc123"

# No password required!
# → MFA disabled!
```

**Secure:** Require password to disable MFA

---

### Vulnerability #2: **CSRF on MFA Disable**

**Attack page:**
```html
<form action="https://victim.com/disable-mfa" method="POST">
  <input type="hidden" name="confirm" value="yes">
</form>
<script>document.forms[0].submit();</script>
```

**Victim visits page:**
→ MFA disabled via CSRF!

---

### Vulnerability #3: **IDOR - Disable Other User's MFA**

```bash
# Disable own MFA (user_id=123)
POST /api/mfa/disable
{
  "user_id": "123"
}

# Modify to admin (user_id=1)
POST /api/mfa/disable
{
  "user_id": "1"  ← Admin!
}

# If no authorization check:
# → Admin's MFA disabled!
```

---

## Certificate Authentication Testing

### Test #1: **CA Restrictions**

```bash
# Check accepted CAs
openssl s_client -connect example.com:443

# Output:
Acceptable client certificate CA names
CN = Example Org Root CA

# Can we use different CA?
# Create self-signed cert with same CN
# → Bypass?
```

---

### Test #2: **Certificate Reuse**

```
Certificate issued to: Alice (alice@company.com)

Attack:
1. Obtain Alice's certificate
2. Use on Bob's account (bob@company.com)
3. If successful → No user binding!
```

---

## Comprehensive Testing Checklist

### MFA Bypass:
```
☐ Direct access after step 1 (skip MFA page)
☐ MFA enforced on all endpoints (web, API, mobile)?
☐ X-Forwarded-For IP spoofing bypass
☐ Debug headers bypass (X-Debug, X-Internal)
☐ OIDC flow tampering
☐ Federated login without MFA
```

---

### OTP Testing:
```
☐ OTP length (6 digits = weak)
☐ OTP validity period (30s vs hours)
☐ Multiple valid codes at once?
☐ OTP reusable?
☐ Rate limiting on verification
☐ Account lockout after failures
```

---

### Recovery:
```
☐ Recovery code length (8+ hex chars)
☐ Recovery code single-use
☐ Recovery code rate limiting
☐ MFA reset process as strong as MFA
☐ Security questions bypass
```

---

### Management:
```
☐ Re-authentication to disable MFA
☐ CSRF protection on MFA settings
☐ IDOR on MFA management
☐ Notification on MFA changes
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Skip MFA page | `/dashboard` after step 1 |
| IP spoofing | `-H "X-Forwarded-For: 192.168.1.1"` |
| API endpoint | `curl /api/login` (no MFA?) |
| TOTP brute-force | Loop 000000-999999 |
| Recovery code | Loop codes, check rate limit |
| OIDC tampering | Modify `policy` parameter |

---

## Védelem (Remediation)

### 1. **Enforce MFA on ALL Endpoints:**

```python
# Middleware: Check MFA on every request
@app.before_request
def check_mfa():
    if request.endpoint in PROTECTED_ENDPOINTS:
        if not session.get('mfa_verified'):
            return redirect('/mfa-verify')
```

---

### 2. **Proper Session Management:**

```python
# After password
session['partial_auth'] = True
session['mfa_verified'] = False

# After MFA
session['mfa_verified'] = True
session['partial_auth'] = False

# Check before app access
if not session.get('mfa_verified'):
    abort(403)
```

---

### 3. **Secure OTP Implementation:**

```python
# TOTP validation
def verify_totp(user, code):
    totp = pyotp.TOTP(user.totp_secret)
    
    # Accept only current code (NOT previous/next)
    return totp.verify(code, valid_window=0)
```

---

### 4. **Rate Limiting:**

```python
@limiter.limit("5 per hour")
def verify_mfa():
    # Max 5 attempts per hour
    ...
```

---

### 5. **Secure Recovery Codes:**

```python
# Generate
recovery_codes = [secrets.token_hex(8) for _ in range(10)]

# Store hashed
for code in recovery_codes:
    hash_and_store(code, user_id, used=False)

# Verify
def verify_recovery_code(user_id, code):
    stored = get_recovery_code(hash(code))
    
    if not stored or stored.used:
        return False
    
    # Mark as used
    mark_used(stored)
    return True
```

---

## Fontos Megjegyzések

✅ **MFA on ALL endpoints** (web, API, mobile)  
✅ **Session: mfa_verified** flag required  
✅ **TOTP: valid_window=0** (only current code)  
✅ **Rate limiting** (5 attempts/hour)  
✅ **Recovery codes: 128+ bits**, single-use  
✅ **Re-auth to disable** MFA  
✅ **CSRF protection** on MFA settings  
❌ **Direct access** after step 1 = bypass!  
❌ **X-Forwarded-For** trust = IP spoofing!  
❌ **6-digit recovery** = brute-forcible!  
❌ **5 valid TOTP codes** = 99% crack rate!  
⚠️ **API without MFA** = major bypass!  
⚠️ **No rate limiting** = brute-force vulnerable!

---

**Összefoglalva:** Ez a fejezet az **MFA (Multi-Factor Authentication)** teszteléséről szól. **TRUE MFA** = **2 different factors** (password + TOTP, NOT password + PIN). **Common bypasses**: **direct access** after step 1 (skip MFA page), **API without MFA**, **X-Forwarded-For** IP spoofing, **weak recovery codes** (6 digits), **OIDC flow tampering**. **TOTP weakness**: **multiple valid codes** (5 codes = 99% brute-force success in 24h), **no rate limiting**, **reusable codes**. **Defense**: **MFA on ALL endpoints**, **session mfa_verified flag**, **valid_window=0** (only current TOTP), **rate limiting** (5/hour), **recovery codes 128+ bits + single-use**, **re-auth to disable MFA**, **CSRF protection**!
