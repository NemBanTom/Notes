# WSTG-AUTHZ-02: Authorization Schema Bypass Tesztelése

## Mi a fejezet lényege?

Ez a fejezet arról szól, hogy az **authorization schema** (hozzáférési jogosultságok) **weak implementation**-je lehetővé teszi az **unauthorized access**-t. **Vertical privilege escalation** (user→admin), **horizontal access** (user A→user B data), vagy **unauthenticated access** mind **broken access control** példák.

⚠️ **NE KEVERD ÖSSZE:** Ez NEM authentication bypass! Ez **authorization** - **már bejelentkezett** user **unauthorized resource**-hoz fér hozzá vagy **unauthorized action**-t hajt végre.

---

## Mi a cél?

**Authorization bypass** vulnerability-k:
- Unauthenticated access (no login required)
- Horizontal access (user A → user B data)
- Vertical escalation (user → admin)
- Forced browsing (direct URL access)

---

## 3 Típus Authorization Bypass

### 1. **Unauthenticated Access** (No login)
### 2. **Horizontal Bypass** (Same role, different user)
### 3. **Vertical Escalation** (Higher privilege)

---

## 1. Unauthenticated Access

### Concept:
**Protected resource** accessible **without login**.

---

### Forced Browsing:

**Scenario:**
```
Login page: https://example.com/login
After login: https://example.com/dashboard
```

**Attack:**
```bash
# Try direct access without login
curl https://example.com/dashboard

# If 200 OK with dashboard content:
# → CRITICAL! No authentication required!
```

---

### Common Targets:

```
/admin
/admin/panel
/admin/users
/dashboard
/profile
/settings
/api/users
/api/admin/logs
/reports/financial
/upload
```

---

### Testing:

```bash
# Test protected URLs
curl -I https://example.com/admin

# Expected: 302 redirect to /login or 401/403
# Vulnerable: 200 OK

# Test with logout first
curl https://example.com/logout
curl https://example.com/admin
# If accessible → No auth check!
```

---

## 2. Horizontal Bypass (IDOR)

### Concept:
**User A** accesses **User B**'s data (same privilege level).

---

### Example:

**User A (ID=123):**
```
https://example.com/profile?user_id=123
→ Shows User A's profile (correct)
```

**Attack:**
```
https://example.com/profile?user_id=456
→ Shows User B's profile (VULNERABLE!)
```

→ **IDOR** (Insecure Direct Object Reference)

---

### Testing:

**Step 1 - Create two accounts:**
```
User A: alice@test.com (ID=100)
User B: bob@test.com (ID=101)
```

---

**Step 2 - Login as User A:**
```bash
curl -X POST /login \
  -d "email=alice@test.com&password=Pass123" \
  -c alice_cookies.txt
```

---

**Step 3 - Access own data:**
```bash
curl -b alice_cookies.txt \
  https://example.com/api/profile/100

Response:
{
  "id": 100,
  "name": "Alice",
  "email": "alice@test.com"
}
```

---

**Step 4 - Try accessing User B's data:**
```bash
curl -b alice_cookies.txt \
  https://example.com/api/profile/101

# If successful:
{
  "id": 101,
  "name": "Bob",
  "email": "bob@test.com"  ← User B's data!
}

→ CRITICAL! Horizontal bypass!
```

---

### Common IDOR Parameters:

```
user_id=
account_id=
profile_id=
order_id=
invoice_id=
document_id=
file_id=
message_id=
```

---

### Attack Variations:

```bash
# Numeric IDs
/api/user/123 → /api/user/124

# UUIDs
/api/user/abc-123-def → /api/user/xyz-789-ghi

# Usernames
/profile/alice → /profile/bob

# Email-based
/account?email=alice@test.com → /account?email=bob@test.com
```

---

## 3. Vertical Privilege Escalation

### Concept:
**Regular user** accesses **admin functions**.

---

### Example:

**Admin function:**
```
POST /admin/addUser HTTP/1.1

userID=newadmin&role=admin&group=administrators
```

**Attack as regular user:**
```bash
# Login as regular user
curl -X POST /login \
  -d "email=user@test.com&password=Pass" \
  -c user_cookies.txt

# Try admin function
curl -X POST /admin/addUser \
  -b user_cookies.txt \
  -d "userID=hacker&role=admin&group=administrators"

# If successful:
# → CRITICAL! Vertical privilege escalation!
```

---

### Common Admin Functions:

```
/admin/users (list users)
/admin/addUser (create user)
/admin/deleteUser (delete user)
/admin/settings (change settings)
/admin/logs (view logs)
/api/admin/backup (download backup)
/api/admin/config (modify config)
```

---

### Testing:

```bash
# Map admin functions (as admin)
# Then test access as regular user

# Admin URLs to test:
for url in /admin /admin/users /admin/settings /admin/logs; do
  curl -b user_cookies.txt https://example.com$url
done

# If any return 200 OK:
# → Vertical escalation vulnerability!
```

---

## Special Header Bypass

### X-Original-URL / X-Rewrite-URL:

**Concept:**
**Frontend** blocks `/admin`, but **backend** trusts special headers.

---

### Attack:

**Step 1 - Normal request (blocked):**
```bash
curl https://example.com/admin

# Response: 403 Forbidden
```

---

**Step 2 - Bypass with X-Original-URL:**
```bash
curl https://example.com/ \
  -H "X-Original-URL: /admin"

# If 200 OK:
# → Bypass successful!
```

---

**Step 3 - Verify with non-existent resource:**
```bash
curl https://example.com/ \
  -H "X-Original-URL: /doesnotexist"

# If 404 Not Found:
# → Confirms server honors X-Original-URL header
```

---

### X-Forwarded-For (IP-Based Bypass):

**Concept:**
Admin panel only accessible from **localhost** or **internal IP**.

---

**Attack:**
```bash
# Normal request (blocked)
curl https://example.com/admin

# Response: 403 Forbidden (not from allowed IP)

# Spoof IP
curl https://example.com/admin \
  -H "X-Forwarded-For: 127.0.0.1"

# If 200 OK:
# → IP-based bypass!
```

---

**Other headers to try:**
```
X-Forwarded-For: 127.0.0.1
X-Forward-For: 127.0.0.1
X-Remote-IP: 127.0.0.1
X-Originating-IP: 127.0.0.1
X-Remote-Addr: 127.0.0.1
X-Client-IP: 127.0.0.1
```

**IPs to test:**
```
127.0.0.1
localhost
10.0.0.1 (RFC1918)
172.16.0.1 (RFC1918)
192.168.1.1 (RFC1918)
```

---

## Role-Based Testing

### Scenario:
Application has **multiple roles**: Admin, Manager, User.

---

### Testing Matrix:

| Function | Admin | Manager | User |
|----------|-------|---------|------|
| View Users | ✓ | ✓ | ✗ |
| Add User | ✓ | ✗ | ✗ |
| Delete User | ✓ | ✗ | ✗ |
| View Logs | ✓ | ✓ | ✗ |
| Modify Settings | ✓ | ✗ | ✗ |

---

### Test as each role:

```bash
# Test as User (lowest privilege)
# Try all functions marked ✗

# Expected: 403 Forbidden
# Vulnerable: 200 OK (unauthorized access!)
```

---

## Comprehensive Testing Checklist

### Unauthenticated Access:
```
☐ List all protected URLs (map as authenticated user)
☐ Logout
☐ Try accessing each URL without authentication
☐ Check response codes (200=vulnerable, 401/403=secure)
☐ Test with incognito/private browser
☐ Test API endpoints separately
```

---

### Horizontal Bypass (IDOR):
```
☐ Create two accounts (same role)
☐ Identify resources with IDs (user_id, order_id, etc.)
☐ Access User A's resource as User A (baseline)
☐ Change ID to User B's ID
☐ Verify if User B's data accessible
☐ Test with sequential IDs (1, 2, 3, ...)
☐ Test with UUIDs, usernames, emails
```

---

### Vertical Escalation:
```
☐ Map admin functions (as admin)
☐ Login as regular user
☐ Try accessing admin URLs
☐ Try admin API endpoints
☐ Test with different HTTP methods (GET, POST, PUT, DELETE)
☐ Check for role parameter manipulation
```

---

### Special Headers:
```
☐ Test X-Original-URL header
☐ Test X-Rewrite-URL header
☐ Test X-Forwarded-For with 127.0.0.1
☐ Test other proxy headers
☐ Try with port numbers (127.0.0.1:80)
```

---

## Gyakorlati Cheat Sheet

| Teszt | Parancs |
|-------|---------|
| Forced browsing | `curl /admin` (no cookies) |
| IDOR | Change `user_id=123` to `user_id=456` |
| Vertical escalation | `curl /admin/addUser` (user session) |
| X-Original-URL | `curl / -H "X-Original-URL: /admin"` |
| X-Forwarded-For | `curl /admin -H "X-Forwarded-For: 127.0.0.1"` |

---

## Fontos Toolok

### Manual:
- **curl** - Command line testing
- **Burp Suite** - Intercept & modify
- **Browser DevTools** - Manual testing

### Automated:
- **ZAP Access Control Testing** - Addon
- **Burp Autorize** - Extension
- **Burp AuthMatrix** - Extension

---

## Védelem (Remediation)

### 1. **Server-Side Authorization Checks:**

```python
@app.route('/admin/users')
def admin_users():
    # Check authentication
    if not session.get('user_id'):
        return redirect('/login')
    
    # Check authorization
    user = get_user(session['user_id'])
    if user.role != 'admin':
        abort(403, "Forbidden")
    
    # Proceed with admin function
    return render_template('admin_users.html')
```

---

### 2. **Object-Level Authorization:**

```python
@app.route('/api/profile/<int:user_id>')
def get_profile(user_id):
    current_user_id = session.get('user_id')
    
    # Verify user can only access own profile
    if current_user_id != user_id:
        # Unless admin
        user = get_user(current_user_id)
        if user.role != 'admin':
            abort(403, "Unauthorized")
    
    profile = get_profile_by_id(user_id)
    return jsonify(profile)
```

---

### 3. **Indirect Object References:**

```python
# BAD: Direct ID exposure
@app.route('/document/<int:doc_id>')

# GOOD: Use mapping/token
@app.route('/document/<token>')
def get_document(token):
    # Map token to actual doc_id + verify ownership
    mapping = get_mapping(token, session['user_id'])
    if not mapping:
        abort(404)
    
    doc = get_document(mapping.doc_id)
    return doc
```

---

### 4. **Whitelist Allowed Actions:**

```python
ROLE_PERMISSIONS = {
    'admin': ['view_users', 'add_user', 'delete_user', 'view_logs'],
    'manager': ['view_users', 'view_logs'],
    'user': []
}

def check_permission(user_role, action):
    if action not in ROLE_PERMISSIONS.get(user_role, []):
        abort(403, "Permission denied")
```

---

### 5. **Ignore Untrusted Headers:**

```python
# DON'T trust proxy headers without validation
# BAD:
client_ip = request.headers.get('X-Forwarded-For')

# GOOD: Only trust if behind known proxy
if request.remote_addr in TRUSTED_PROXIES:
    client_ip = request.headers.get('X-Forwarded-For')
else:
    client_ip = request.remote_addr
```

---

## Real-World Example

### Scenario: **Facebook Graph API IDOR (2013)**

**Vulnerability:**
```
GET /me/permissions
→ Returns current user's permissions

GET /<user_id>/permissions
→ Returns ANY user's permissions (should be restricted!)
```

**Impact:** Access tokens and permissions of any user!

---

## Fontos Megjegyzések

✅ **Server-side authorization** EVERY request  
✅ **Object-level checks** (verify ownership)  
✅ **Indirect references** (tokens, not IDs)  
✅ **Role-based permissions** (whitelist)  
✅ **Ignore untrusted headers** (X-Forwarded-For)  
❌ **Direct IDs** exposed = IDOR!  
❌ **No auth check** = forced browsing!  
❌ **Trust X-Forwarded-For** = IP bypass!  
⚠️ **Logout doesn't invalidate** = session active!  
⚠️ **X-Original-URL** = frontend bypass!  
⚠️ **IDOR** = most common authorization bug!

---

**Összefoglalva:** Ez a fejezet az **authorization bypass** teszteléséről szól. **Három típus**: **(1) Unauthenticated** = `/admin` no login (forced browsing), **(2) Horizontal** = User A → User B data (IDOR: `user_id=123` → `user_id=456`), **(3) Vertical** = user → admin functions (`/admin/addUser` as regular user). **Special bypasses**: **X-Original-URL** header (frontend bypass), **X-Forwarded-For: 127.0.0.1** (IP-based bypass). **Defense**: **server-side authorization** every request, **object-level checks** (verify ownership), **indirect references** (tokens not IDs), **role-based whitelist**, **DON'T trust** X-Forwarded-For! **IDOR** = leggyakoribb authorization vulnerability!
