# WSTG-AUTHZ-03: Privilege Escalation Tesztelése

## Mi a fejezet lényege?

A **privilege escalation** azt jelenti, hogy egy user **magasabb jogosultságot** szerez, mint amije kellene. **Vertical escalation** = user→admin, **horizontal escalation** = userA→userB data. **Parameter manipulation** (role=admin), **hidden field** tampering, vagy **session hijacking** mind privilege escalation módszerek.

---

## Testing Módszerek

### 1. Role/Privilege Manipulation

#### User Group Manipulation:

**Request:**
```http
POST /user/viewOrder.jsp HTTP/1.1
Host: www.example.com

groupID=grp001&orderID=0001
```

**Attack:**
```bash
# Original user in grp002
# Try accessing grp001 data
curl -X POST /user/viewOrder.jsp \
  -b "session=user_grp002_session" \
  -d "groupID=grp001&orderID=0001"

# If successful → privilege escalation!
```

---

#### User Profile Manipulation:

**HTML response after login:**
```html
<form name="autoriz" method="POST" action="visual.jsp">
  <input type="hidden" name="profile" value="User">
  <body onload="document.forms.autoriz.submit()">
</form>
```

**Attack with Burp:**
```
Intercept POST to visual.jsp
Change: profile=User
To: profile=SysAdmin

Forward request
→ Became admin?
```

---

#### Condition Value Manipulation:

**Server response:**
```
@0`1`3`3``0`UC`1`Status`OK`SEC`5`1`0`ResultSet`0`PVValid`-1`0`0`
```

**PVValid=-1** = error condition

**Attack:**
```
Change PVValid from -1 to 0
→ Bypass error check
→ Authentication as admin?
```

---

### 2. Banking Site Role Testing

**Role hierarchy:**
```
Administrator: Full Control + Delete
Manager: Modify, Add, Read
Staff: Read, Modify
Customer: Read Only
```

---

**Admin function:**
```http
POST /account/deleteEvent HTTP/1.1
Cookie: SessionID=ADMIN_SESSION

EventID=1000001
```

**Response:**
```json
{"message": "Event was deleted"}
```

---

**Attack as Customer:**
```bash
# Login as customer
curl -X POST /login -d "user=customer&pass=Pass123" -c customer.txt

# Try admin function
curl -X POST /account/deleteEvent \
  -b customer.txt \
  -d "EventID=1000002"

# If response: {"message": "Event was deleted"}
# → CRITICAL! Customer can delete events!
```

---

**Attack as Staff:**
```bash
# Staff should only Read+Modify
# Try Manager function (Add)

curl -X POST /account/addEvent \
  -b staff_session.txt \
  -d "eventName=Test&eventDate=2024-01-01"

# If successful → Staff escalated to Manager!
```

---

### 3. Vertical Escalation Testing

**Setup:**
```
Create two accounts:
- admin@test.com (Administrator role)
- user@test.com (Customer role)
```

---

**Step 1 - Map admin functions:**
```bash
# Login as admin
curl -X POST /login -d "email=admin@test.com&pass=Admin123" -c admin.txt

# Map admin URLs
curl -b admin.txt https://example.com/admin
curl -b admin.txt https://example.com/admin/users
curl -b admin.txt https://example.com/admin/settings
curl -b admin.txt https://example.com/admin/logs
```

---

**Step 2 - Test as regular user:**
```bash
# Login as user
curl -X POST /login -d "email=user@test.com&pass=User123" -c user.txt

# Try admin URLs
curl -b user.txt https://example.com/admin
curl -b user.txt https://example.com/admin/users

# If any return 200 OK with admin content:
# → Vertical privilege escalation!
```

---

### 4. Session Token Swapping

**Concept:** Use higher privilege session token in lower privilege context.

---

**Test:**
```bash
# Get admin session token
curl -X POST /login -d "email=admin@test.com&pass=Admin" -c admin.txt
cat admin.txt | grep SessionID
# SessionID=abc123admin

# Get user session token
curl -X POST /login -d "email=user@test.com&pass=User" -c user.txt
cat user.txt | grep SessionID
# SessionID=xyz789user

# Use admin token in user context
curl https://example.com/user/profile \
  -H "Cookie: SessionID=abc123admin"

# Check if admin data/functions exposed in user profile
```

---

### 5. Parameter Injection Testing

#### Role Parameter:

**Registration:**
```bash
# Normal registration
curl -X POST /register \
  -d "username=test&password=Pass123&email=test@test.com"

# Try injecting role
curl -X POST /register \
  -d "username=admin2&password=Pass123&email=admin2@test.com&role=admin"

# Login and check privileges
```

---

#### Cookie Manipulation:

**Normal cookie:**
```
Cookie: user=john; role=customer
```

**Attack:**
```bash
curl https://example.com/dashboard \
  -H "Cookie: user=john; role=admin"

# If admin dashboard displayed → escalation!
```

---

### 6. JWT Role Manipulation

**JWT payload:**
```json
{
  "sub": "user@test.com",
  "role": "user",
  "iat": 1234567890
}
```

**Attack:**
```bash
# Decode JWT
echo "eyJ..." | base64 -d

# Modify role: "user" → "admin"
# Re-encode (if no signature verification)

# Test with modified JWT
curl https://example.com/admin \
  -H "Authorization: Bearer modified_jwt"
```

---

### 7. IP Address Manipulation

**Scenario:** Admin access only from specific IP.

**Attack:**
```bash
# Normal request (blocked)
curl https://example.com/admin
# 403 Forbidden

# Spoof trusted IP
curl https://example.com/admin \
  -H "X-Forwarded-For: 192.168.1.100"

# If trusted IP → access granted
```

---

### 8. URL Traversal

**Bypass authorization checks:**

```bash
# Direct access (checked)
curl https://example.com/admin/users
# 403 Forbidden

# URL traversal
curl https://example.com/./admin/users
curl https://example.com/../admin/users
curl https://example.com/admin/../admin/users

# URL encoding
curl https://example.com/%61dmin/users  # %61 = 'a'
curl https://example.com/admin%2fusers  # %2f = '/'
```

---

### 9. GUI vs Function Authorization

**Common vulnerability:** Authorization check only in GUI.

**Test:**
```bash
# GUI blocks button for regular users
# But underlying function doesn't check!

# User sees: [View] button only
# Admin sees: [View] [Edit] [Delete] buttons

# Direct API call as user:
curl -X DELETE /api/users/123 \
  -b user_session.txt

# If successful → GUI-only authorization!
```

---

### 10. WhiteBox - Partial URL Match

**Vulnerable code:**
```python
# BAD: Only checks start of URL
if request.path.startswith('/admin'):
    check_admin()

# Bypass:
# /admin%20 (trailing space)
# /admin. (trailing dot)
# /admin/ (with slash)
```

**Test:**
```bash
curl https://example.com/admin%20
curl https://example.com/admin.
curl https://example.com/admin/../admin
```

---

## Gyakorlati Attack Scenarios

### Scenario #1: E-commerce Price Manipulation

**Normal checkout:**
```http
POST /checkout HTTP/1.1

productID=123&price=100.00&quantity=1
```

**Attack:**
```bash
# Modify price
curl -X POST /checkout \
  -d "productID=123&price=1.00&quantity=1"

# If order succeeds with $1 price → escalation!
```

---

### Scenario #2: Banking Transfer Limit

**Normal transfer (customer limit $1000):**
```http
POST /transfer HTTP/1.1

fromAccount=123&toAccount=456&amount=1000.00
```

**Attack:**
```bash
# Try exceeding limit
curl -X POST /transfer \
  -b customer_session.txt \
  -d "fromAccount=123&toAccount=456&amount=50000.00"

# If successful → privilege escalation!
```

---

### Scenario #3: Discount Code Creation

**Admin creates discount:**
```http
POST /admin/createDiscount HTTP/1.1
Cookie: admin_session

code=SAVE50&discount=50&expiryDate=2024-12-31
```

**Attack as user:**
```bash
curl -X POST /admin/createDiscount \
  -b user_session.txt \
  -d "code=FREESTUFF&discount=100&expiryDate=2030-12-31"

# If successful → user created 100% discount!
```

---

## Testing Matrix Example

| Function | Admin | Manager | Staff | Customer | Test Result |
|----------|-------|---------|-------|----------|-------------|
| View Users | ✓ | ✓ | ✗ | ✗ | Staff: ✗ Pass |
| Add User | ✓ | ✓ | ✗ | ✗ | Staff: ✓ FAIL! |
| Delete User | ✓ | ✗ | ✗ | ✗ | Manager: ✗ Pass |
| View Logs | ✓ | ✓ | ✗ | ✗ | Customer: ✓ FAIL! |

**Result:** 2 privilege escalation vulnerabilities found!

---

## Fontos Toolok

- **Burp Suite** - Intercept & modify requests
- **ZAP** - Automated privilege testing
- **curl** - Command line testing
- **jwt.io** - JWT manipulation

---

## Fontos Megjegyzések

✅ **Test EVERY role** against higher privilege functions  
✅ **Parameter manipulation** first test  
✅ **Session swapping** reveals escalation  
✅ **JWT role claims** often not validated  
❌ **Hidden fields** easily modified (profile=admin)  
❌ **GUI-only** authorization = function vulnerable!  
⚠️ **URL encoding** bypasses partial match!  
⚠️ **IP headers** easily spoofed!

---

**Összefoglalva:** **Privilege escalation** = user higher privilege than allowed. **Vertical** = user→admin, **horizontal** = userA→userB. **Testing**: parameter manipulation (role=admin, groupID=grp001), hidden field tampering (profile=SysAdmin), session swapping (use admin token), JWT role modification, IP spoofing (X-Forwarded-For), URL traversal (/admin%20). **Common mistake**: authorization csak GUI-ban, function nincs védve! **Attack**: map admin functions → test as lower privilege user → check for 200 OK responses!
