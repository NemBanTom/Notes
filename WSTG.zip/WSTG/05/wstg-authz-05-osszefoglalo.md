# WSTG-AUTHZ-05: OAuth Weaknesses Tesztelése

## Mi a fejezet lényege?

Az **OAuth 2.0** authorization framework, ahol **weak implementation** vagy **deprecated flow-k** használata **unauthorized access**-t tesz lehetővé. **Implicit Flow** (deprecated), **ROPC** (password átadás), vagy **missing PKCE** mind **security weakness**-ek. **Credential leakage** URL-ben (token in referrer), **client secret exposure**, vagy **authorization code replay** gyakori OAuth vulnerability-k.

---

## OAuth Grant Types

### Recommended:
- ✅ **Authorization Code + PKCE** (public clients)
- ✅ **Authorization Code** (confidential clients)
- ✅ **Client Credentials** (machine-to-machine)

### Deprecated (OAuth 2.1):
- ❌ **Implicit Flow** (token in URL)
- ❌ **ROPC** (Resource Owner Password Credentials)

---

## Testing Deprecated Flows

### 1. Implicit Flow Detection

**Request:**
```http
GET /authorize?
  client_id=abc123
  &response_type=token
  &redirect_uri=https://client.com/callback
  &scope=openid%20profile
  &state=xyz
```

**Key:** `response_type=token` = **Implicit Flow!**

---

**Response:**
```http
HTTP/1.1 302 Found
Location: https://client.com/callback#
  access_token=eyJhbGc...
  &token_type=Bearer
  &expires_in=3600
```

**Token in URL fragment!** → Vulnerable to leakage!

---

**Testing:**
```bash
# Check authorization request
curl -I "https://as.example.com/authorize?response_type=token&..."

# If response_type=token → Implicit Flow (deprecated!)
```

---

### 2. ROPC Flow Detection

**Token request:**
```http
POST /oauth/token HTTP/1.1
Host: as.example.com

{
  "grant_type": "password",
  "username": "user@example.com",
  "password": "UserPassword123",
  "client_id": "abc123"
}
```

**Key:** `grant_type=password` = **ROPC!**

**Problem:** Client handles user credentials directly!

---

**Testing:**
```bash
# Try ROPC flow
curl -X POST https://as.example.com/oauth/token \
  -H "Content-Type: application/json" \
  -d '{
    "grant_type": "password",
    "username": "test@test.com",
    "password": "Pass123",
    "client_id": "test_client"
  }'

# If successful → ROPC enabled (deprecated!)
```

---

## Testing Missing PKCE

### Authorization Code WITHOUT PKCE:

**Authorization request:**
```http
GET /authorize?
  response_type=code
  &client_id=public_client
  &redirect_uri=https://app.com/callback
  &scope=openid
  &state=random123
```

**Missing:** `code_challenge` parameter!

---

**Attack scenario:**
```
1. Attacker intercepts authorization code
2. Replays code to token endpoint
3. Gets access token (no PKCE verification!)
```

---

**Testing:**
```bash
# Check if PKCE required
# Authorization request without code_challenge:
curl -I "https://as.example.com/authorize?\
response_type=code&\
client_id=public_client&\
redirect_uri=https://app.com/callback&\
state=xyz"

# If accepted (returns code) → Missing PKCE!
```

---

### Authorization Code WITH PKCE:

**Authorization request:**
```http
GET /authorize?
  response_type=code
  &client_id=public_client
  &redirect_uri=https://app.com/callback
  &code_challenge=E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM
  &code_challenge_method=S256
  &state=xyz
```

**Present:** `code_challenge` + `code_challenge_method`

---

**Token exchange:**
```http
POST /oauth/token HTTP/1.1

{
  "grant_type": "authorization_code",
  "code": "auth_code_123",
  "code_verifier": "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk",
  "client_id": "public_client",
  "redirect_uri": "https://app.com/callback"
}
```

**Includes:** `code_verifier`

---

## Client Credentials Misuse

### Legitimate use (machine-to-machine):
```bash
curl -X POST https://as.example.com/oauth/token \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "service_a",
    "client_secret": "secret123",
    "grant_type": "client_credentials"
  }'

# Returns: access_token for service-to-service
```

---

### Misuse (public client with client_credentials):

**Problem:** Public client (SPA, mobile) shouldn't have `client_secret`!

**Testing:**
```bash
# Check if public client uses client_credentials
# (e.g., inspect mobile app traffic)

# If mobile app sends:
{
  "client_id": "mobile_app",
  "client_secret": "hardcoded_secret",
  "grant_type": "client_credentials"
}

# → Secret exposed in client! (decompile app)
```

---

## Credential Leakage Testing

### 1. Token in URL Fragment

**Implicit Flow response:**
```
https://client.com/callback#
  access_token=eyJhbGc...
  &token_type=Bearer
```

**Leakage vectors:**
- Browser history
- Referrer header (if external resources)
- Server logs (if fragment sent)
- Browser extensions

---

**Testing:**
```bash
# Step through OAuth flow with Burp
# Look for tokens in URL

# Check if page loads external resources:
curl -s https://client.com/callback | grep -o 'src="http[^"]*"'

# If external resources exist:
# → Token leaked in Referer header!
```

---

### 2. Authorization Code in Referrer

**Callback URL:**
```
https://client.com/callback?code=auth_code_123&state=xyz
```

**If page includes:**
```html
<img src="https://analytics.com/pixel.gif">
```

**Request to analytics:**
```http
GET /pixel.gif HTTP/1.1
Host: analytics.com
Referer: https://client.com/callback?code=auth_code_123&state=xyz
```

**Authorization code leaked!**

---

**Testing:**
```bash
# Intercept callback page
# Check for external resources

curl -s "https://client.com/callback?code=test&state=xyz" | \
  grep -E '(src|href)="https?://[^"]+"'

# External domains found → potential leakage!
```

---

### 3. PKCE Parameters in Logs

**Authorization URL:**
```
/authorize?
  code_challenge=E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM
```

**Less critical** (code_challenge is hashed), but:
- `code_verifier` should never be in URL
- Only in POST to /token endpoint

---

**Testing:**
```bash
# Check if code_verifier in URL (should be in POST body!)
# Intercept token exchange

# GOOD:
POST /token
Body: code_verifier=xyz

# BAD:
GET /token?code_verifier=xyz  # NEVER!
```

---

## Referrer-Policy Testing

**Check headers:**
```bash
curl -I https://client.com/callback

# Look for:
Referrer-Policy: no-referrer
# OR
Referrer-Policy: strict-origin
```

**If missing or weak:**
```
Referrer-Policy: unsafe-url  # BAD! Sends full URL
```

---

**Test HTML meta:**
```bash
curl -s https://client.com/callback | grep referrer

# Check for:
<meta name="referrer" content="no-referrer">
```

---

## Practical Testing Workflow

### Step 1: Identify OAuth Implementation

```bash
# Trigger login flow
# Observe authorization request

# Check parameters:
# - response_type=?
# - code_challenge present?
# - grant_type in token request?
```

---

### Step 2: Classify Flow Type

**Authorization request indicators:**
```
response_type=token → Implicit Flow (deprecated!)
response_type=code (no code_challenge) → Auth Code (weak for public)
response_type=code + code_challenge → Auth Code + PKCE ✓
```

**Token request indicators:**
```
grant_type=password → ROPC (deprecated!)
grant_type=client_credentials → Check if appropriate
grant_type=authorization_code → Check PKCE
```

---

### Step 3: Test Credential Leakage

```bash
# 1. Capture OAuth flow in Burp
# 2. Check for tokens/codes in URLs
# 3. Identify external resources
# 4. Check Referrer headers
# 5. Verify Referrer-Policy
```

---

### Step 4: Test Authorization Code Replay

```bash
# Capture authorization code
code=xyz123

# Try using twice:
curl -X POST /oauth/token \
  -d "grant_type=authorization_code&code=xyz123&..."

# First time: success
# Second time: should fail!
# If succeeds twice → code replay vulnerability!
```

---

## Attack Scenarios

### Scenario #1: Implicit Flow Token Leakage

```
1. User logs in via OAuth Implicit Flow
2. Redirect: https://app.com/callback#access_token=eyJ...
3. Page includes: <img src="https://tracker.com/pixel">
4. Browser sends:
   GET /pixel HTTP/1.1
   Referer: https://app.com/callback#access_token=eyJ...
5. Tracker logs access token!
```

---

### Scenario #2: Missing PKCE Code Interception

```
1. Victim initiates OAuth flow (no PKCE)
2. Authorization request intercepted (public WiFi)
3. Callback: https://app.com/callback?code=abc123
4. Attacker captures code
5. Attacker exchanges code for token (no PKCE check)
6. Account compromise!
```

---

### Scenario #3: Client Secret in Mobile App

```
1. Decompile mobile APK
2. Find hardcoded:
   client_id=mobile_app
   client_secret=hardcoded_secret_123
3. Use credentials:
   curl -X POST /oauth/token \
     -d "client_id=mobile_app&client_secret=hardcoded_secret_123&grant_type=client_credentials"
4. Get access token!
```

---

## Fontos Toolok

- **Burp Suite** - Intercept OAuth flows
- **ZAP** - OAuth testing
- **EsPReSSO** - Burp extension for OAuth
- **jwt.io** - Decode JWT tokens

---

## Fontos Megjegyzések

✅ **Auth Code + PKCE** for public clients  
✅ **POST body** for secrets (not URL)  
✅ **Referrer-Policy: no-referrer**  
✅ **Code single-use** only  
❌ **Implicit Flow** deprecated!  
❌ **response_type=token** = leakage risk!  
❌ **grant_type=password** = ROPC deprecated!  
⚠️ **Client secret** in public client = exposed!  
⚠️ **Token in URL** = referrer leakage!  

---

**Összefoglalva:** **OAuth testing** = identify flow type + test weaknesses. **Deprecated flows**: **Implicit** (`response_type=token`), **ROPC** (`grant_type=password`). **Missing PKCE** for public clients = code interception vulnerability. **Credential leakage**: token in URL fragment → referrer header → external analytics. **Testing**: intercept OAuth flow with Burp → check `response_type` + `grant_type` → verify PKCE (`code_challenge`) → test external resources for referrer leakage → check Referrer-Policy header!
